# 章节目录
#
# 章节数据集中放在这里。新增章节时，复制一个 chapter_catalog 项目，
# 将 number、title、summary 和 choices 改成新内容即可。

default chapter_directory_selected = 0
default chapter_directory_scale = 1.0

init python:
    chapter_catalog = [
        {
            "number": 1,
            "title": "初入汴京大学",
            "summary": "新生报到、选择床位，并在校园里结识牵绕、室友与小莱。",
            "choices": [
                "是否接受牵绕的帮助",
                "如何回应牵绕关于校园与专业的提问",
                "选择宿舍床位",
                "是否主动与室友交流",
                "是否邀请小莱拼桌吃饭",
                "是否陪小莱前往图书馆",
            ],
        },
        {
            "number": 2,
            "title": "第二章：待续",
            "summary": "后续剧情筹备中。选择次数暂按第一章规划。",
            "choices": ["选择一", "选择二", "选择三", "选择四", "选择五", "选择六"],
        },
        {
            "number": 3,
            "title": "第三章：待续",
            "summary": "后续剧情筹备中。选择次数暂按第一章规划。",
            "choices": ["选择一", "选择二", "选择三", "选择四", "选择五", "选择六"],
        },
        {
            "number": 4,
            "title": "第四章：待续",
            "summary": "后续剧情筹备中。选择次数暂按第一章规划。",
            "choices": ["选择一", "选择二", "选择三", "选择四", "选择五", "选择六"],
        },
        {
            "number": 5,
            "title": "第五章：待续",
            "summary": "后续剧情筹备中。选择次数暂按第一章规划。",
            "choices": ["选择一", "选择二", "选择三", "选择四", "选择五", "选择六"],
        },
        {
            "number": 6,
            "title": "第六章：待续",
            "summary": "后续剧情筹备中。选择次数暂按第一章规划。",
            "choices": ["选择一", "选择二", "选择三", "选择四", "选择五", "选择六"],
        },
    ]

transform directory_content_zoom:
    zoom chapter_directory_scale

screen chapter_directory():
    tag menu
    modal True

    add Solid("#f7f3f0")

    frame:
        xfill True
        yfill True
        background Solid("#f7f3f0")
        padding (55, 35)

        vbox:
            spacing 18

            hbox:
                xfill True
                text "章节目录" size 48 color "#5b4a46"
                null width 60
                text "缩放" size 24 color "#8b7771" yalign 0.5
                bar value FieldValue(store, "chapter_directory_scale", range=0.6, offset=0.75, style="directory_zoom_bar") xsize 220 yalign 0.5
                text "[chapter_directory_scale:.2f]x" size 22 color "#8b7771" xsize 90 yalign 0.5
                textbutton "返回" action Return() xalign 1.0

            text "拖动下方内容可浏览更多章节与选择节点" size 22 color "#9a8780"

            viewport:
                xfill True
                yfill True
                draggable True
                mousewheel True
                scrollbars "horizontal"
                xinitial 0.0

                hbox:
                    at directory_content_zoom
                    spacing 35
                    xsize (len(chapter_catalog) * 350 + 35)
                    ysize 650

                    for index, chapter in enumerate(chapter_catalog):
                        button:
                            xsize 315
                            ysize 570
                            action SetVariable("chapter_directory_selected", index)
                            background Solid("#ffffff")
                            hover_background Solid("#fff0ee")
                            selected_background Solid("#f6c6c0")
                            padding (25, 24)

                            vbox:
                                spacing 14
                                text "第 [chapter['number']] 章" size 28 color "#c36f68"
                                text chapter["title"] size 30 color "#5b4a46" min_width 260
                                null height 8
                                text chapter["summary"] size 21 color "#806f6a" xmaximum 260
                                null height 8
                                text "选择节点" size 23 color "#c36f68"
                                for choice in chapter["choices"]:
                                    text "· [choice]" size 20 color "#806f6a" xmaximum 260

            hbox:
                spacing 14
                textbutton "缩小" action SetVariable("chapter_directory_scale", max(0.75, chapter_directory_scale - 0.05))
                textbutton "恢复大小" action SetVariable("chapter_directory_scale", 1.0)
                textbutton "放大" action SetVariable("chapter_directory_scale", min(1.35, chapter_directory_scale + 0.05))

style directory_zoom_bar is slider
style directory_zoom_bar:
    ysize 24
