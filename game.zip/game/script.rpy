﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。

default player_name = ""
default player_gender = ""
default player_college = ""
default player_major = ""
default player_affection = 0
default qianrao_affection = 0

style name_entry is input:
    color "#000000"
    caret "#000000"
    background None
    ysize 36

init python:
    def position_web_name_input():
        if not renpy.emscripten:
            return

        import emscripten

        game_width = config.screen_width
        game_height = config.screen_height
        panel_height = 242
        input_top_offset = 40 + 34 + 20
        input_left_offset = int((game_width - game_width * 0.63) / 2) + 40
        input_width = int(game_width * 0.63) - 80

        script = """
        (() => {
            const canvas = document.getElementById("canvas");
            const inputDiv = document.getElementById("inputDiv");
            const inputForm = document.getElementById("inputForm");
            const inputPrompt = document.getElementById("inputPrompt");
            const inputText = document.getElementById("inputText");
            const bounds = canvas.getBoundingClientRect();
            const scale = Math.min(bounds.width / __GAME_WIDTH__, bounds.height / __GAME_HEIGHT__);
            const contentLeft = bounds.left + (bounds.width - __GAME_WIDTH__ * scale) / 2;
            const contentTop = bounds.top + (bounds.height - __GAME_HEIGHT__ * scale) / 2;

            inputDiv.style.position = "fixed";
            inputDiv.style.top = (contentTop + (__GAME_HEIGHT__ / 2 - __PANEL_HEIGHT__ / 2 + __INPUT_TOP_OFFSET__) * scale) + "px";
            inputDiv.style.left = (contentLeft + __INPUT_LEFT_OFFSET__ * scale) + "px";
            inputDiv.style.right = "auto";
            inputDiv.style.width = (__INPUT_WIDTH__ * scale) + "px";
            inputDiv.style.minWidth = "0";
            inputDiv.style.margin = "0";
            inputDiv.style.padding = "0";
            inputDiv.style.background = "transparent";
            inputDiv.style.borderRadius = "0";
            inputDiv.style.zIndex = "10";

            inputForm.style.width = "100%";
            inputForm.style.display = "flex";
            inputForm.style.flexDirection = "column";
            inputForm.style.alignItems = "stretch";
            inputForm.style.margin = "0";
            inputPrompt.style.display = "none";

            inputText.style.boxSizing = "border-box";
            inputText.style.display = "block";
            inputText.style.width = "100%";
            inputText.style.height = (36 * scale) + "px";
            inputText.style.margin = "0";
            inputText.style.padding = "0 " + (6 * scale) + "px";
            inputText.style.border = "1px solid #888";
            inputText.style.borderRadius = "0";
            inputText.style.background = "#ffffff";
            inputText.style.color = "#000000";
            inputText.style.caretColor = "#000000";
            inputText.style.opacity = "1";
            inputText.style.fontSize = (28 * scale) + "px";
            inputText.style.fontFamily = "Microsoft YaHei, sans-serif";
            inputText.style.outline = "none";

            let submitButton = document.getElementById("inputSubmit");
            if (!submitButton) {
                submitButton = document.createElement("button");
                submitButton.id = "inputSubmit";
                submitButton.type = "submit";
                submitButton.textContent = "确定";
                inputForm.appendChild(submitButton);
            }

            submitButton.style.alignSelf = "center";
            submitButton.style.minHeight = (44 * scale) + "px";
            submitButton.style.marginTop = (10 * scale) + "px";
            submitButton.style.padding = "0 " + (12 * scale) + "px";
            submitButton.style.border = "0";
            submitButton.style.borderRadius = "0";
            submitButton.style.background = "transparent";
            submitButton.style.color = "#777777";
            submitButton.style.fontSize = (24 * scale) + "px";
            submitButton.style.fontFamily = "Microsoft YaHei, sans-serif";
            submitButton.style.cursor = "pointer";
            submitButton.style.zIndex = "11";
        })();
        """
        script = script.replace("__GAME_WIDTH__", str(game_width))
        script = script.replace("__GAME_HEIGHT__", str(game_height))
        script = script.replace("__PANEL_HEIGHT__", str(panel_height))
        script = script.replace("__INPUT_TOP_OFFSET__", str(input_top_offset))
        script = script.replace("__INPUT_LEFT_OFFSET__", str(input_left_offset))
        script = script.replace("__INPUT_WIDTH__", str(input_width))
        emscripten.run_script(script)

    def reset_web_name_input():
        if not renpy.emscripten:
            return

        import emscripten

        emscripten.run_script("""
            ["inputDiv", "inputForm", "inputPrompt", "inputText"].forEach((id) => {
                document.getElementById(id).removeAttribute("style");
            });
            document.getElementById("inputSubmit")?.remove();
        """)

screen ask_name_screen(web=False):
    modal True
    add "images/jq/bg/village.webp" xysize (config.screen_width, config.screen_height)
    frame:
        xalign 0.5
        yalign 0.5
        xsize int(config.screen_width * 0.63)
        padding (40, 40, 40, 40)
        background Solid("#FFFFFFEE")
        has vbox spacing 20:
            text "请输入你的名字：" size 28 color "#000000" xalign 0.5
            fixed:
                xfill True
                ysize 36

                add Solid("#FFFFFF") xysize (int(config.screen_width * 0.63) - 80, 36)

                if not web:
                    input:
                        value VariableInputValue("player_name")
                        style "name_entry"
                        xfill True

            if web:
                null height 54
            else:
                textbutton "确定" action Return(True) xalign 0.5
default xiaolai_affection = 0
default limichen_affection = 0
default liyu_affection = 0
default jiangfeng_affection = 0
default xiemin_affection = 0
default huaixiaoshi_affection = 0
default lingchen_affection = 0
default special_lm_triggered = False
default limichen_important_choice = ""
default special_ly_triggered = False
default special_xl_triggered = False
default special_lc_triggered = False
default special_xm_triggered = False
default special_jf_triggered = False
default special_hx_triggered = False
default special_q_triggered = False
default hx_shared_novel_origin = False
default hx_novel_delayed = False
default limichen_shared_piano_past = False
default qianrao_admitted_identity = False
default ly_important_flag = ""
default performed_with_ly = False
default participated_in_show = False
default affection_synced_total = 0
default affection_target = "好心的学长"
default affection_change = ""
default q_display_name = "？"
default roommate_display = ""
define config.default_text_cps = 30
define q = Character("[q_display_name]")
# 兄妹角色：黎陌尘（哥哥）与黎妤（妹妹）
#
# 说明（开发者注释）：
# - 二人为血缘亲兄妹，仅相差一岁，家庭条件宽裕，父母支持两人各自从事艺术。
# - 性格：黎陌尘沉静内敛，专注于钢琴与小提琴；黎妤外向跳脱，主攻水彩与插画。
# - 设定细节：黎陌尘就读音乐系（钢琴、小提琴），性格温和，常在琴房练习；
#   黎妤为美术系新生，随性散漫但创作热情高涨，两人互为彼此的依靠与灵感来源。
# - 寝室分开，两栋宿舍楼，平时互相奔赴见面，常在校园长椅互相慰藉创作瓶颈。

# 显示名与角色对象
default lm_display_name = "黎陌尘"
default ly_display_name = "黎妤"
default xl_display_name = "小莱"
default lc_display_name = "凌晨"
default xm_display_name = "谢旻"
default jf_display_name = "江枫"
default hx_display_name = "怀小柿"

default fd_display_name = "辅导员"

default girl_display_name = "女生"
default girl_one_display_name = "女生1"
default girl_two_display_name = "女生2"

default jg_display_name = "教官"
default fq_display_name = "父亲"
default mq_display_name = "母亲"
default pp_display_name = "陈婆婆"
default lb_display_name = "老板"


define lm = Character("[lm_display_name]")
define ly = Character("[ly_display_name]")
define xl = Character("[xl_display_name]")
define lc = Character("[lc_display_name]")
define xm = Character("[xm_display_name]")
define jf = Character("[jf_display_name]")
define hx = Character("[hx_display_name]")

define fd = Character("[fd_display_name]")
define jg = Character("[jg_display_name]")

define girl = Character("[girl_display_name]")
define girl_one = Character("[girl_one_display_name]")
define girl_two = Character("[girl_two_display_name]")

define fq = Character("[fq_display_name]")
define mq = Character("[mq_display_name]")
define pp = Character("[pp_display_name]")
define lb = Character("[lb_display_name]")

init python:
    def change_affection(amount, target):
        """同步保留旧总值，并将变化写入指定角色。"""
        affection_values = {
            "牵绕": "qianrao_affection",
            "小莱": "xiaolai_affection",
            "黎陌尘": "limichen_affection",
            "黎妤": "liyu_affection",
            "江枫": "jiangfeng_affection",
            "谢旻": "xiemin_affection",
            "怀小柿": "huaixiaoshi_affection",
            "凌晨": "lingchen_affection",
        }
        variable_name = affection_values.get(target)
        if variable_name:
            current_value = getattr(store, variable_name)
            setattr(store, variable_name, max(0, min(300, current_value + amount)))
        store.player_affection += amount

    def sync_affection():
        """将旧的总好感度增量同步到当前提示对应的角色。"""
        delta = store.player_affection - store.affection_synced_total
        if delta == 0:
            return
        affection_values = {
            "牵绕": "qianrao_affection",
            "小莱": "xiaolai_affection",
            "黎陌尘": "limichen_affection",
            "黎妤": "liyu_affection",
            "江枫": "jiangfeng_affection",
            "谢旻": "xiemin_affection",
            "怀小柿": "huaixiaoshi_affection",
            "凌晨": "lingchen_affection",
        }
        variable_name = affection_values.get(store.affection_target)
        if variable_name:
            current_value = getattr(store, variable_name)
            setattr(store, variable_name, max(0, min(300, current_value + delta)))
        store.affection_synced_total = store.player_affection

# ——————————————————————————————————————————————————————————————————————————
image bg black = "images/jq/bg/black.webp"

image bg road = "images/jq/bg/road.webp"

image bg video_shooting_one = "images/jq/bg/video_shooting_one.webp"
image bg video_shooting_two = "images/jq/bg/video_shooting_two.webp"

image bg old_camera = "images/jq/bg/old_camera.webp"

image bg sweet = "images/jq/bg/sweet.webp"
image bg village = "images/jq/bg/village.webp"
image bg desk = "images/jq/bg/desk.webp"

image bg dorm_bed = "images/jq/bg/dorm_bed.webp"
image bg dorm_bed_made = "images/jq/bg/dorm_bed_made.webp"

image bg dorm_desk_books = "images/jq/bg/dorm_desk_books.webp"
image bg dorm_wind = "images/jq/bg/dorm_wind.webp"

image bg dorm_hall = "images/jq/bg/dorm_hall.webp"
image bg dorm_interior = "images/jq/bg/dorm_interior.webp"

image bg dorm_hall_luggage = "images/jq/bg/dorm_hall_luggage.webp"
image bg open_suitcase = "images/jq/bg/open_suitcase.webp"

image bg dorm_morning = "images/jq/bg/dorm_morning.webp"
image bg dorm_afternoon = "images/jq/bg/dorm_afternoon.webp"
image bg dorm_evening = "images/jq/bg/dorm_evening.webp"

image bg dorm_downstairs_morning = "images/jq/bg/dorm_downstairs_morning.webp"
image bg dorm_downstairs_evening = "images/jq/bg/dorm_downstairs_evening.webp"

image bg desk_turn_on = "images/jq/bg/desk_turn_on.webp"
image bg desk_turn_off = "images/jq/bg/desk_turn_off.webp"

image bg canteen_road = "images/jq/bg/canteen_road.webp"
image bg canteen = "images/jq/bg/canteen.webp"
image bg canteen_desk = "images/jq/bg/canteen_desk.webp"

image bg library_front_morning = "images/jq/bg/library_front_morning.webp"
image bg library_front_evening = "images/jq/bg/library_front_evening.webp"

image bg shaded_path = "images/jq/bg/shaded_path.webp"
image bg shaded_path_evening = "images/jq/bg/shaded_path_evening.webp"
image bg shaded_path_night = "images/jq/bg/shaded_path_night.png"

image bg teaching_building_morning = "images/jq/bg/teaching_building_morning.webp"
image bg teaching_building_dusk = "images/jq/bg/teaching_building_dusk.webp"
image bg teaching_building_corridor = "images/jq/bg/teaching_building_corridor.webp"
image bg teaching_building_corridor_evening = "images/jq/bg/teaching_building_corridor_evening.webp"
image bg classroom = "images/jq/bg/classroom.webp"
image bg stairs_evening = "images/jq/bg/stairs_evening.webp"

image bg tennis_court = "images/jq/bg/tennis_court.webp"
image bg playground = "images/jq/bg/playground.webp"
image bg playground_stand_evening = "images/jq/bg/playground_stand_evening.webp"
image bg playground_new_camera = "images/jq/bg/playground_new_camera.webp"

image bg clinic = "images/jq/bg/clinic.webp"
image bg clinic_water = "images/jq/bg/clinic_water.webp"

image bg behind_scenes = "images/jq/bg/behind_scenes.webp"

image bg barbecue = "images/jq/bg/barbecue.webp"
image bg clink = "images/jq/bg/clink.webp"

image bg piano_room_morning = "images/jq/bg/piano_room_morning.webp"
image bg piano_room_evening = "images/jq/bg/piano_room_evening.webp"
image bg guitar_practice_room = "images/jq/bg/guitar_practice_room.webp"

image bg lakeside = "images/jq/bg/lakeside.webp"
image bg lakeside_spring = "images/jq/bg/lakeside_spring.webp"

image bg lecture = "images/jq/bg/lecture.webp"

image bg team_building = "images/jq/bg/team_building.webp"

image bg locust_tree_old = "images/jq/bg/locust_tree_old.webp"
image bg courtyard_old = "images/jq/bg/courtyard_old.webp"
image bg courtyard_new = "images/jq/bg/courtyard_new.webp"
image bg ridge_field = "images/jq/bg/ridge_field.webp"

image bg concert_hall = "images/jq/bg/concert_hall.webp"
image bg concert_hall_people = "images/jq/bg/concert_hall_people.webp"
image bg concert_hall_doorway = "images/jq/bg/concert_hall_doorway.webp"

image bg pagoda_tree = "images/jq/bg/pagoda_tree.webp"

image bg train_station = "images/jq/bg/train_station.webp"
image bg train_station_evening = "images/jq/bg/train_station_evening.webp"
image bg train_station_coin = "images/jq/bg/train_station_coin.webp"
image bg train_internal = "images/jq/bg/train_internal.webp"
image bg train_internal_evening = "images/jq/bg/train_internal_evening.webp"

image bg road_dusk = "images/jq/bg/road_dusk.webp"

image bg old_music_store = "images/jq/bg/old_music_store.webp"
image bg old_music_store_photograph = "images/jq/bg/old_music_store_photograph.webp"

image bg youth_hostel_evening = "images/jq/bg/youth_hostel_evening.webp"
image bg youth_hostel_window_evening = "images/jq/bg/youth_hostel_window_evening.webp"
image bg hotel_north = "images/jq/bg/hotel_north.webp"

image bg southern_town = "images/jq/bg/southern_town.webp"

image bg jiuzhen_morning = "images/jq/bg/jiuzhen_morning.webp"
image bg jiuzhen_evening = "images/jq/bg/jiuzhen_evening.webp"

image bg new_city = "images/jq/bg/new_city.webp"

image bg exit_gate = "images/jq/bg/exit_gate.webp"

image bg another_city_morning = "images/jq/bg/another_city_morning.webp"
image bg another_city_evening = "images/jq/bg/another_city_evening.webp"

image bg coastal_city = "images/jq/bg/coastal_city.webp"

image bg bookstore = "images/jq/bg/bookstore.webp"


# ——————————————————————————————————————————————————————————————————————————
# 牵绕
image bg chujian_q = "images/jq/q/chujian_q.webp"

image bg walk_q = "images/jq/q/walk_q.webp"
image bg walk_turn_q = "images/jq/q/walk_turn_q.webp"
image bg walk_winter_q = "images/jq/q/walk_winter_q.webp"

image bg turn_q = "images/jq/q/turn_q.webp"

image bg Photograph_q = "images/jq/q/Photograph_q.webp"
image bg Photograph_two_q = "images/jq/q/Photograph_two_q.webp"
image bg Photograph_three_q = "images/jq/q/Photograph_three_q.webp"

image bg dorm_hall_luggage_q = "images/jq/q/dorm_hall_luggage_q.webp"

image bg tennis_over_q = "images/jq/q/tennis_over_q.webp"
image bg look_photos_q = "images/jq/q/look_photos_q.webp"
image bg turn_head_side_q = "images/jq/q/turn_head_side_q.webp"
image bg intersection_q = "images/jq/q/intersection_q.webp"

image bg behind_scenes_q = "images/jq/q/behind_scenes_q.webp"
image bg shaded_path_q = "images/jq/q/shaded_path_q.webp"
image bg shaded_path_autumn_q = "images/jq/q/shaded_path_autumn_q.webp"

image bg lecture_q = "images/jq/q/lecture_q.webp"
image bg viewfinder_q = "images/jq/q/viewfinder_q.webp"
image bg team_building_q = "images/jq/q/team_building_q.webp"
image bg water_supply_room_q = "images/jq/q/water_supply_room_q.webp"
image bg stairs_evening_q = "images/jq/q/stairs_evening_q.webp"

image bg pagoda_tree_one_q = "images/jq/q/pagoda_tree_one_q.webp"
image bg pagoda_tree_two_q = "images/jq/q/pagoda_tree_two_q.webp"
image bg pagoda_tree_three_q = "images/jq/q/pagoda_tree_three_q.webp"

image bg teaching_block_tt1_q = "images/jq/q/teaching_block_tt1_q.webp"
image bg teaching_block_tt2_q = "images/jq/q/teaching_block_tt2_q.webp"

image bg tennis_q = "images/jq/q/tennis_q.webp"
image bg tennis_instruction_q = "images/jq/q/tennis_instruction_q.webp"
image bg tennis_court_one_q = "images/jq/q/tennis_court_one_q.webp"
image bg tennis_court_two_q = "images/jq/q/tennis_court_two_q.webp"
image bg tennis_court_three_q = "images/jq/q/tennis_court_three_q.webp"
image bg tennis_court_five_q = "images/jq/q/tennis_court_five_q.webp"
image bg tennis_court_six_q = "images/jq/q/tennis_court_six_q.webp"
image bg tennis_court_nine_q = "images/jq/q/tennis_court_nine_q.webp"

image bg train_one_q = "images/jq/q/train_one_q.webp"
image bg train_two_q = "images/jq/q/train_two_q.webp"
image bg train_three_q = "images/jq/q/train_three_q.webp"

image bg southern_town_q = "images/jq/q/southern_town_q.webp"

image bg village_q = "images/jq/q/village_q.webp"
image bg village_photograph_q = "images/jq/q/village_photograph_q.webp"


# ——————————————————————————————————————————————————————————————————————————
# 黎陌尘
image bg chujian_lm = "images/jq/lm/chujian_lm.webp"
image bg leave_dorm_lm = "images/jq/lm/leave_dorm_lm.webp"

image bg classroom_lm = "images/jq/lm/classroom_lm.webp"
image bg canteen_lm = "images/jq/lm/canteen_lm.webp"
image bg military_training_lm = "images/jq/lm/military_training_lm.webp"
image bg backstage_lm = "images/jq/lm/backstage_lm.webp"

image bg piano_room_morning_lm = "images/jq/lm/piano_room_morning_lm.png"
image bg piano_room_evening_lm = "images/jq/lm/piano_room_evening_lm.png"
image bg piano_room_evening_two_lm = "images/jq/lm/piano_room_evening_two_lm.webp"
image bg piano_room_evening_cone_back_lm = "images/jq/lm/piano_room_evening_cone_back_lm.webp"
image bg piano_room_album_lm = "images/jq/lm/piano_room_album_lm.webp"

image bg piano_room_spring_one_lm = "images/jq/lm/piano_room_spring_one_lm.webp"
image bg piano_room_spring_two_lm = "images/jq/lm/piano_room_spring_two_lm.webp"
image bg piano_room_spring_three_lm = "images/jq/lm/piano_room_spring_three_lm.webp"
image bg piano_room_spring_four_lm = "images/jq/lm/piano_room_spring_four_lm.webp"
image bg piano_room_winter_lm = "images/jq/lm/piano_room_winter_lm.webp"

image bg piano_one_lm = "images/jq/lm/piano_one_lm.webp"
image bg piano_two_lm = "images/jq/lm/piano_two_lm.webp"
image bg piano_three_lm = "images/jq/lm/piano_three_lm.webp"

image bg shaded_path_lm = "images/jq/lm/shaded_path_lm.webp"
image bg shaded_path_come_back_lm = "images/jq/lm/shaded_path_come_back_lm.webp"

image bg library_lm = "images/jq/lm/library_lm.webp"
image bg library_rise_lm = "images/jq/lm/library_rise_lm.webp"

image bg team_building_lm = "images/jq/lm/team_building_lm.webp"

image bg concert_hall_one_lm = "images/jq/lm/concert_hall_one_lm.webp"
image bg concert_hall_two_lm = "images/jq/lm/concert_hall_two_lm.webp"
image bg concert_hall_three_lm = "images/jq/lm/concert_hall_three_lm.webp"
image bg concert_hall_four_lm = "images/jq/lm/concert_hall_four_lm.webp"
image bg concert_hall_five_lm = "images/jq/lm/concert_hall_five_lm.webp"

image bg leave_taking_one_lm = "images/jq/lm/leave_taking_one_lm.webp"
image bg leave_taking_two_lm = "images/jq/lm/leave_taking_two_lm.webp"
image bg leave_taking_three_lm = "images/jq/lm/leave_taking_three_lm.webp"

image bg train_one_lm = "images/jq/lm/train_one_lm.webp"
image bg train_two_lm = "images/jq/lm/train_two_lm.webp"
image bg train_three_lm = "images/jq/lm/train_three_lm.webp"
image bg train_four_lm = "images/jq/lm/train_four_lm.webp"

image bg empty_music_room = "images/jq/lm/empty_music_room.webp"
image bg street_lm = "images/jq/lm/street_lm.webp"

image bg exit_gate_lm = "images/jq/lm/exit_gate_lm.webp"
image bg exit_gate_one_lm = "images/jq/lm/exit_gate_one_lm.webp"
image bg exit_gate_two_lm = "images/jq/lm/exit_gate_two_lm.webp"


# ——————————————————————————————————————————————————————————————————————————
# 黎妤
image bg chujian_ly = "images/jq/ly/chujian_ly.webp"
image bg camera_ly = "images/jq/ly/camera_ly.webp"
image bg take_camera_ly = "images/jq/ly/take_camera_ly.webp"

image bg dorm_balcony_phone_ly = "images/jq/ly/dorm_balcony_phone_ly.webp"
image bg turnaround_ly = "images/jq/ly/turnaround_ly.webp"
image bg quiet_ly = "images/jq/ly/quiet_ly.webp"

image bg go_out_one_ly = "images/jq/ly/go_out_one_ly.webp"
image bg go_out_two_ly = "images/jq/ly/go_out_two_ly.webp"

image bg sketch_ly = "images/jq/ly/sketch_ly.webp"
image bg candy_ly = "images/jq/ly/candy_ly.webp"
image bg sitdown_talk_ly = "images/jq/ly/sitdown_talk_ly.webp"
image bg eat_candy_ly = "images/jq/ly/eat_candy_ly.webp"

image bg classroom_ly = "images/jq/ly/classroom_ly.webp"
image bg canteen_ly = "images/jq/ly/canteen_ly.webp"

image bg backstage_ly = "images/jq/ly/backstage_ly.webp"
image bg backstage_nervous_ly = "images/jq/ly/backstage_nervous_ly.webp"

image bg stage_ly = "images/jq/ly/stage_ly.webp"

image bg painting_ly = "images/jq/ly/painting_ly.webp"
image bg wall_ly = "images/jq/ly/wall_ly.webp"
image bg wall_girl_ly = "images/jq/ly/wall_girl_ly.webp"
image bg wall_girl_photographer_ly = "images/jq/ly/wall_girl_photographer_ly.webp"

image bg phone_ly = "images/jq/ly/phone_ly.webp"

image bg lakeside_ly = "images/jq/ly/lakeside_ly.webp"
image bg lakeside_sad_ly = "images/jq/ly/lakeside_sad_ly.webp"
image bg lakeside_daze_ly = "images/jq/ly/lakeside_daze_ly.webp"
image bg sketch_drawing_ly = "images/jq/ly/sketch_drawing_ly.webp"
image bg sketch_two_ly = "images/jq/ly/sketch_two_ly.webp"
image bg sketch_three_ly = "images/jq/ly/sketch_three_ly.webp"

image bg teaching_building_corridor_ly = "images/jq/ly/teaching_building_corridor_ly.webp"
image bg team_building_ly = "images/jq/ly/team_building_ly.webp"
image bg dorm_bed_ly = "images/jq/ly/dorm_bed_ly.webp"
image bg dorm_bed_hold_book_ly = "images/jq/ly/dorm_bed_hold_book_ly.webp"
image bg dorm_sketch_one_ly = "images/jq/ly/dorm_sketch_one_ly.webp"
image bg dorm_sketch_two_ly = "images/jq/ly/dorm_sketch_two_ly.webp"

image bg bench_ly = "images/jq/ly/bench_ly.webp"
image bg bench_vast_ly = "images/jq/ly/bench_vast_ly.webp"
image bg bench_sad_ly = "images/jq/ly/bench_sad_ly.webp"
image bg bench_tired_ly = "images/jq/ly/bench_tired_ly.webp"
image bg bench_relax_ly = "images/jq/ly/bench_relax_ly.webp"

image bg leave_taking_one_ly = "images/jq/ly/leave_taking_one_ly.webp"
image bg leave_taking_two_ly = "images/jq/ly/leave_taking_two_ly.webp"
image bg leave_taking_three_ly = "images/jq/ly/leave_taking_three_ly.webp"

image bg train_one_ly = "images/jq/ly/train_one_ly.webp"
image bg train_two_ly = "images/jq/ly/train_two_ly.webp"
image bg train_three_ly = "images/jq/ly/train_three_ly.webp"
image bg train_four_ly = "images/jq/ly/train_four_ly.webp"
image bg train_five_ly = "images/jq/ly/train_five_ly.webp"
image bg train_draw_ly = "images/jq/ly/train_draw_ly.webp"

image bg exit_gate_ly ="images/jq/ly/exit_gate_ly.webp"

image bg art_exhibition_ly = "images/jq/ly/art_exhibition_ly.webp"
image bg art_exhibition_photograph_ly = "images/jq/ly/art_exhibition_photograph_ly.webp"
image bg art_exhibition_photograph_one_ly = "images/jq/ly/art_exhibition_photograph_one_ly.webp"

image bg photo_ly = "images/jq/ly/photo_ly.webp"

image bg dorm_desk_books_ly = "images/jq/ly/dorm_desk_books_ly.webp"


# ——————————————————————————————————————————————————————————————————————————
# 小莱
image bg chujian_xl = "images/jq/xl/chujian_xl.webp"
image bg rice_xl = "images/jq/xl/rice_xl.webp"
image bg clinic_xl = "images/jq/xl/clinic_xl.webp"
image bg library_window_look_up_xl = "images/jq/xl/library_window_look_up_xl.webp"
image bg exit_gate_xl = "images/jq/xl/exit_gate_xl.webp"


# ——————————————————————————————————————————————————————————————————————————
# 凌晨
image bg classroom_lc = "images/jq/lc/classroom_lc.webp"
image bg canteen_lc = "images/jq/lc/canteen_lc.webp"

image bg library_lc = "images/jq/lc/library_lc.webp"
image bg library_two_lc = "images/jq/lc/library_two_lc.webp"

image bg behind_scenes_lc = "images/jq/lc/behind_scenes_lc.webp"

image bg new_courtyard_one_lc = "images/jq/lc/new_courtyard_one_lc.webp"
image bg new_courtyard_two_lc = "images/jq/lc/new_courtyard_two_lc.webp"
image bg new_courtyard_three_lc = "images/jq/lc/new_courtyard_three_lc.webp"

image bg exit_gate_lc = "images/jq/lc/exit_gate_lc.webp"


# ——————————————————————————————————————————————————————————————————————————
# 谢旻
image bg chujian_xm = "images/jq/xm/chujian_xm.webp"
image bg smile_xm = "images/jq/xm/smile_xm.webp"
image bg canteen_xm = "images/jq/xm/canteen_xm.webp"
image bg exit_gate_xm = "images/jq/xm/exit_gate_xm.webp"


# ——————————————————————————————————————————————————————————————————————————
# 江枫
image bg chujian_jf = "images/jq/jf/chujian_jf.webp"
image bg talk_turn_jf= "images/jq/jf/talk_turn_jf.webp"
image bg talk_jf = "images/jq/jf/talk_jf.webp"
image bg sitdown_talk_jf = "images/jq/jf/sitdown_talk_jf.webp"
image bg classroom_jf = "images/jq/jf/classroom_jf.webp"
image bg canteen_jf = "images/jq/jf/canteen_jf.webp"

image bg backstage_jf = "images/jq/jf/backstage_jf.webp"
image bg stage_jf = "images/jq/jf/stage_jf.webp"

image bg dorm_door_frame_jf = "images/jq/jf/dorm_door_frame_jf.webp"
image bg exit_gate_jf ="images/jq/jf/exit_gate_jf.webp"


# ——————————————————————————————————————————————————————————————————————————
# 怀小柿
image bg chujian_hx = "images/jq/hx/chujian_hx.webp"
image bg computer_hx = "images/jq/hx/computer_hx.webp"

image bg sitdown_talk_hx = "images/jq/hx/sitdown_talk_hx.webp"

image bg canteen_hx = "images/jq/hx/canteen_hx.webp"
image bg canteen_two_hx = "images/jq/hx/canteen_two_hx.webp"
image bg canteen_three_hx = "images/jq/hx/canteen_three_hx.webp"
image bg canteen_four_hx = "images/jq/hx/canteen_four_hx.webp"

image bg playground_hx = "images/jq/hx/playground_hx.webp"
image bg dorm_door_hx = "images/jq/hx/dorm_door_hx.webp"

image bg hand_notebook_hx = "images/jq/hx/hand_notebook_hx.webp"
image bg line_art_hx = "images/jq/hx/line_art_hx.webp"
image bg hold_note_hx = "images/jq/hx/hold_note_hx.webp"

image bg sit_down_hx = "images/jq/hx/sit_down_hx.webp"
image bg sit_down_two_hx = "images/jq/hx/sit_down_two_hx.webp"

image bg library_hx = "images/jq/hx/library_hx.webp"
image bg tieshoelaces_hx = "images/jq/hx/tieshoelaces_hx.webp"
image bg leave_dorm_hx = "images/jq/hx/leave_dorm_hx.webp"

image bg dorm_one_hx = "images/jq/hx/dorm_one_hx.webp"
image bg dorm_two_hx = "images/jq/hx/dorm_two_hx.webp"
image bg dorm_three_hx = "images/jq/hx/dorm_three_hx.webp"
image bg dorm_four_hx = "images/jq/hx/dorm_four_hx.webp"
image bg dorm_five_hx = "images/jq/hx/dorm_five_hx.webp"
image bg dorm_six_hx = "images/jq/hx/dorm_six_hx.webp"

image bg team_building_hx = "images/jq/hx/team_building_hx.webp"

image bg balcony_one_hx = "images/jq/hx/balcony_one_hx.webp"
image bg balcony_two_hx = "images/jq/hx/balcony_two_hx.webp"
image bg balcony_three_hx = "images/jq/hx/balcony_three_hx.webp"
image bg balcony_four_hx = "images/jq/hx/balcony_four_hx.webp"

image bg leave_taking_one_hx = "images/jq/hx/leave_taking_one_hx.webp"
image bg leave_taking_two_hx = "images/jq/hx/leave_taking_two_hx.webp"
image bg leave_taking_three_hx = "images/jq/hx/leave_taking_three_hx.webp"
image bg leave_taking_four_hx = "images/jq/hx/leave_taking_four_hx.webp"
image bg leave_taking_five_hx = "images/jq/hx/leave_taking_five_hx.webp"

image bg exit_gate_hx = "images/jq/hx/exit_gate_hx.webp"



# ——————————————————————————————————————————————————————————————————————————
# 多人
image bg canteen_manypeople = "images/jq/others/canteen_manypeople.webp"

image bg stage_jf_xm = "images/jq/others/stage_jf_xm.webp"
image bg backstage_jf_xm = "images/jq/others/backstage_jf_xm.webp"
image bg guitar_jf_xm = "images/jq/others/guitar_jf_xm.webp"

image bg dorm_jf_hx = "images/jq/others/dorm_jf_hx.webp"

# ——————————————————————————————————————————————————————————————————————————
# 别人
image bg classroom_fd = "images/jq/others/classroom_fd.webp"
image bg office_fd = "images/jq/others/office_fd.webp"

image bg canteen_girl = "images/jq/others/canteen_girl.webp"
image bg canteen_camera_girl = "images/jq/others/canteen_camera_girl.webp"

# ——————————————————————————————————————————————————————————————————————————

transform bg_top:
    xalign 0.5
    yalign 0.5
    xysize (config.screen_width, config.screen_height)
    fit "contain"

style affection_change_frame:
    background Solid("#ffc0cb")
    # Ren'Py 样式不支持 `xradius` / `yradius`。
    # 若要圆角，请使用带透明通道的圆角 PNG 或者用 Frame 图片作为背景。
    # 目前使用纯色背景；如需我可以为你生成圆角 PNG 并替换此处。

screen affection_change():
    if affection_change != "":
        $ sync_affection()
        frame:
            if affection_change.startswith("+"):
                background Solid("#ffc0cb")
            else:
                background Solid("#add8e6")
            xalign 0.98
            yalign 0.08
            padding (12, 10)
            text "[affection_target] 好感 [affection_change]" color "#ffffff" size 32 font "SourceHanSansLite.ttf"

transform welcome_notice_image:
    xalign 0.5
    yalign 0.5

screen welcome_notice():
    modal True
    zorder 100

    add Solid("#ffffff")
    add "images/jq/warmprompt.webp" at welcome_notice_image
    text "阅读完后单击继续":
        xalign 0.5
        yalign 0.9
        color "#222222"
        size 32
        font "SourceHanSansLite.ttf"

    button:
        xfill True
        yfill True
        action Return()
        background None


# 游戏在此开始。

label start:

    call screen welcome_notice
    scene bg village
    if renpy.emscripten:
        $ position_web_name_input()
        show screen ask_name_screen(True)
        $ player_name = renpy.input("", default=player_name, length=32)
        hide screen ask_name_screen
        $ reset_web_name_input()
    else:
        call screen ask_name_screen
    if not player_name:
        $ player_name = "玩家"
    $ player_name = player_name.strip()
    if player_name == "":
        $ player_name = "玩家"

    $ renpy.block_rollback()
    "好的，欢迎 [player_name]。"

    # 这里保留给你自己修改性别分支。
    # 你可以在这里按需要设置 player_gender、roommate_display 与 affection_target。
    # 例如：
    # $ player_gender = "女"
    # $ roommate_display = ly_display_name
    # $ affection_target = ly_display_name

    play music "music/日常 轻快 悠闲 放松吉他.MP3" fadein 1.0

    # ————————————————————————————————————————第一章————————————————————————————————————————
    # 认识
    scene bg old_camera at bg_top
    "车轮碾过初秋的城市，车窗半降，温热的风把街声一阵阵送进车厢。汴京大学的校门还在前方。"
    "你靠在窗边，手里捧着一台旧款便携相机。机身被你握了很多年，边角磨得温润发亮，快门键上的漆已经掉了一小块。你读的是文学系，却总觉得镜头比纸页更能替人留住一瞬。"

    scene bg video_shooting_one at bg_top
    "你举起相机，取景框里是一个骑车的少年。他单手扶把，另一只手举着手机在笑，后座绑着一摞新买的书，最上面那本被风吹得翻开了几页。"
    "你按下快门。清脆的一声响，被风带走。"

    scene bg old_camera at bg_top
    "你低头翻看预览，嘴角不自觉地扬了扬。这台相机是父亲给你的，八岁那年，你们一家从老家桃溪村搬到汴京。搬家那天，父亲把相机塞进你手里，说："
    fq "你以后会遇到很多人。能记住一个是一个。"
    "从那以后，你走到哪里就拍到哪里：卖早点的老人掀开蒸笼，公交站的女孩把耳机分给同伴，晚霞落在旧楼晾衣杆上。"

    scene bg video_shooting_two at bg_top
    "车子驶入老街区。窗外的行道树枝叶繁茂，一个提着菜篮的老人正侧头朝路边笑。你不知道他在笑什么，但你觉得，这个瞬间很好看。"
    "快门又响了一次。"

    scene bg road at bg_top
    "导航语音响起，距离汴京大学正门越来越近。你把相机收进包里，掌心在机身上轻轻按了一下，像在跟老朋友打招呼。"
    "你把相机收进包里，拇指摩挲了一下磨亮的机身。文学系的四年会遇见什么人、写下什么故事，你还不知道；但你想把那些认真生活的身影留下来。"
  
    # 场景：使用“甜水巷正面”作为校门与走向报到处的背景。
    scene bg sweet at bg_top
    "初秋的汴京还裹着盛夏的余温，澄澈的蓝天万里无云，暖融融的阳光铺满整座百年校园。古朴恢弘的校门砖石纹路清晰，鎏金的 “汴京大学” 四字牌匾在阳光下熠熠生辉。校门两侧香樟树枝繁叶茂，细碎光斑簌簌落在往来新生与家长身上。"
    
    # 场景切换：到报到台时替换为“新生报到桌面”。
    scene bg desk at bg_top
    "今日是新生报到，校门口人声鼎沸，拖着行李箱的新生络绎不绝。你拖着沉重行李箱，办完入学手续，站在校门口犯难。"
    "一道清冽又带几分散漫的少年声线从身侧传来。"

    scene bg chujian_q at bg_top
    $ affection_target = "牵绕"
    $ q_display_name = "？"
    q "新生？看你站这儿半天了，箱子沉得抬不动？"
    "你转头看去，少年身形挺拔，T 恤袖口随意卷到手肘，一只手插在裤袋，另一只手拎着一瓶冰水，眉眼带着看热闹似的笑意。他走上前，低头瞥了眼你的行李箱，又扫过你肩头鼓鼓囊囊的相机包。"
    
    q "堂堂准大学生，体能这么拉垮。"
    "嘴上嫌弃着，他已经握住行李箱的拉杆。冰水被他塞过来，瓶身冷得你一激灵。指尖擦过你掌心时，他的手停在半空一瞬，短得像被风吹断的蝉鸣。"
    "等他收回手，已经重新插回裤袋，脸上又是那副没睡醒的散漫。"
    q "拿着。别杵着发呆了，看你可怜，顺路帮你搬一趟。哪个宿舍的？"

    menu:
        "接过冰水，让他帮忙":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = "牵绕"
            show screen affection_change
            player_name "太谢谢你了！我刚刚正发愁搬不动，麻烦你啦～"
            $ affection_change = ""
            q "用不着这么客气，我就是刚好路过，顺手的事。再说了，你要是在这儿卡半天，堵着路影响别人进出，那才叫麻烦。"
            
        "摇头，自己拖箱子":
            $ player_affection += 3
            $ affection_change = "+3"
            $ affection_target = "牵绕"
            show screen affection_change
            player_name "不用了，我自己可以慢慢搬，谢谢学长。"
            $ affection_change = ""
            q "硬撑什么啊？这箱子轮子都快被你拖得冒烟了，你确定自己能搞定？别到时候半路摔了东西，更麻烦。"
    $ renpy.block_rollback()

    scene bg walk_q at bg_top
    "九月的风轻轻拂过校园，带着香樟的清爽气息。路上随处可见结伴而行的新生和忙碌的志愿者，阳光温柔洒落，将两人的影子拉得长长。"
    "好心的学长拖着你的行李箱，步伐不紧不慢，始终保持着能让你轻松跟上的速度。他身姿挺拔，走路姿态松弛随意，周身是少年独有的清爽利落。"
    
    scene bg walk_turn_q at bg_top
    q "你是今年的新生？哪个专业的？第一次来汴京大学？"

    menu:
        "顺着聊下去":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = "牵绕"
            show screen affection_change
            player_name "是啊，我是新生，第一次来这边，对校园还不太熟悉。"
            $ affection_change = ""
            q "难怪看你一脸茫然。没事，这学校不大，逛两天就熟了。"
        
        "只给一句简短回应":
            $ player_affection -= 3
            $ affection_change = "-3"
            $ affection_target = "牵绕"
            show screen affection_change
            player_name "嗯，差不多。"
            $ affection_change = ""
            q "行吧，不爱说话就算了。"
            "过于简短的回答截断了话题。牵绕脚步慢了半拍，偏过脸轻轻啧了一声，之后只管拖着行李往前走。"
    $ renpy.block_rollback()

    $ q_display_name = "牵绕"
    q "对了，正式介绍一下，我叫牵绕，大二计算机系。"
    player_name "我是[player_name]。"
    
    "路上，牵绕目光扫过你肩头鼓鼓囊囊的相机包，眼里生出几分好奇。"
    q "你还带了相机？很喜欢拍照？"
    player_name "我是一名摄影爱好者，平时喜欢拍点人啊景啊什么的。"

    scene bg turn_q at bg_top
    "牵绕侧过头看向你，树叶间漏下的光斑在他脸侧一晃一晃。他捏了捏空掉的冰水瓶，嘴角带着散漫的笑意。"
    q "挺好的，记录生活挺有意思。"

    "牵绕顿了顿，稍稍挠了挠后脑勺，语气带着一点试探。"
    q "对了……方便的话，能不能帮我拍一张？"
    player_name "可以是可以，不过……这个相机有点老了，像素……你懂的。"

    "牵绕摆了摆手，偏开脸，语气仍旧满不在乎。"
    q "没事，就用这个相机吧，重在记录，不用追求多精良的画质。"

    "你们在香樟树下停住。光斑落在地面和他的肩头，像一片晃动的金色水面。你取下相机，拨动转盘调好参数，擦过镜头边缘后望向取景框。"

    "少年站在树下，手还插在裤袋里，听见快门声也没看镜头，只把视线落向路边。你按下快门，清脆的声音截住一片摇晃的树影。"
    q "谢了，回头请你吃饭。"

    scene bg dorm_downstairs_morning at bg_top
    "一路走走聊聊，穿过林荫道、绕过操场、路过错落的教学楼，二十分钟左右，你们顺利抵达新生宿舍楼楼下。"

    scene bg dorm_hall at bg_top
    "浅米色的宿舍楼整洁干净，楼道窗口敞开，偶尔能听到楼内新生收拾行李的说话声。"

    scene bg dorm_hall_luggage at bg_top
    "牵绕停下脚步，将行李箱稳稳放在宿舍门口的走廊边，抬手随意拍了拍箱身沾染的薄灰，动作自然又松弛。"

    scene bg dorm_hall_luggage_q at bg_top
    q "到地方了，你的宿舍就在这儿。箱子给你放好了，剩下的就得靠你自己收拾了。提醒你一句，新生宿舍东西多，别乱七八糟堆一堆，回头找东西找不到又瞎着急。"
    q "我先走了，还有事。"
    "他转身走了两步，忽然停下来。"
    q "……以后在学校碰到麻烦，别硬扛。"
    "他说这句话的时候，没有回头。"
    q "实在搞不定再说。"
    "然后他走了。这次没有停。"
    player_name "欸，学长，你等一下。刚刚帮你拍的照片，我想修完之后发给你，方便加个微信吗？"

    "牵绕手里的钥匙转了半圈，脚步停住。他很快掏出手机调出二维码。"

    q "行啊，差点忘了。修好了记得发我。"

    "你们互相添加了微信好友。"
    q "直接叫我牵绕就好，学长太见外。好了，我走了，有需要微信联系我。"

    scene bg dorm_hall at bg_top
    "牵绕的身影彻底消失在楼梯拐角，楼道里只剩远处新生说笑的细碎声响。"
    "你站在宿舍门前，指尖攥紧宿舍钥匙。金属冰凉的触感驱散少许一路奔波的燥热。钥匙插进锁孔，转动时发出细微的咔嗒声。你推开门，木门向内荡开，发出一声很轻的吱呀。"

    scene bg dorm_interior at bg_top
    "整间宿舍完整铺展在眼前。标准四人寝。墙面刷着柔和的米白色乳胶漆，左右两侧两两对称摆放四套上床下桌一体式家具，浅原木色柜体干净崭新，还残留着轻微的新木料气息。"
    "此刻其余三张床位全都空着，没有任何行李与生活用品。只有靠窗边的床位采光最好，整片午后的阳光完整地落在桌面上，把原木色的桌板照得发暖。"
    "你拖着行李箱走进去，随手将房门轻轻合上，隔绝楼道嘈杂。目光扫过四张空床位，你心底默默做出选择。"

    menu:
        "此处不影响剧情发展。"
        "选择窗边采光最好的床位":
            "你径直走到靠窗那套上床下桌旁。桌面被阳光晒得微暖，你抬手轻轻抚过光滑的木面，指尖能感觉到木纹的细腻。"
            "你拉开椅子坐下，视线越过阳台落地窗，能看到楼下几棵香樟树的树冠。头顶是你的床，床板干净崭新，还残留着轻微的新木料气息。"
            "这里光线充足，往后看书、伏案写字都会格外舒服。就定在这里了。"
        "选择靠门相对安静的床位":
            "你避开吵闹的窗边，走到靠近房门一侧的床位。此处远离阳台风口，往来走动的人也不易打扰。你伸手按了按桌面，木面凉而平滑。"
            "你拉开椅子坐下，视线正对着房门。有人进来，你会第一时间知道。"
            "头顶是你的床，床板干净崭新，和书桌连成一体。安静私密，更合心意。"
    $ renpy.block_rollback()
    
    scene bg open_suitcase at bg_top
    "你选好床位，把课本立上书架，衣物折进柜子，洗漱包放到桌角。"

    scene bg dorm_bed at bg_top
    "你从箱底拖出床垫和床单，踩着梯子把床垫举上床板，再沿着边缘一点点铺平。"
    
    scene bg dorm_bed_made at bg_top
    "你抖开床单，四角对齐床沿，反复拉扯抚平褶皱。床单是母亲买的，鹅黄色，洗过一次，摸起来很软。最后你叠好薄被，整齐摆放在床头内侧。"

    scene bg dorm_interior at bg_top
    "收拾到一半，你直起身。书架上的书是自己挑的，衣柜里的衣服是自己叠的，床单虽是母亲买的，却由你亲手铺平。桌上的相机也不会再被谁收进抽屉。"
    "午后的光落在桌面，水杯、毛巾和相机各自占着位置。你坐下来，拇指摩挲机身边缘，胸口那点漂浮的心绪终于有了落脚处。"

    scene bg dorm_wind at bg_top
    "窗外的风再次吹进来，翻动书架上书页一角。安静的寝室里，只剩下你独自整理物品的细碎动静。"
    "你坐在自己的书桌前，将照片传入电脑，修整刚刚给牵绕拍下的那张照片。"
    
    scene bg Photograph_q at bg_top
    "屏幕上，牵绕站在香樟树下，阳光从叶缝落在他肩上。你放大照片，看见他右手攥着拉杆，指节发白。你调了调亮部，却没有修掉这个细节。"
    "楼道里断断续续传来其他新生走动、搬东西的声响。午后柔和的阳光透过阳台落地窗铺满地面，安静的寝室里只有窗外隐约的风声。"
    "你保存好照片，靠在椅背上，闭上眼睛。头顶是你的床，床板崭新，还带着一点新木料的气息。"
    "门锁传来轻微的钥匙转动声，“咔嗒”一声轻响，宿舍门被人从外面推开。"

    scene bg chujian_lm at bg_top
    "宿舍门被完全推开，一个身形清瘦高挑的男生率先跨进门内。他一手拎着沉重的大号美术行李箱，另一只手虚扶在门框边，像是怕门反弹撞到人。"
    "他穿着简单的白色衬衫，袖口挽到小臂，露出一截线条干净的手腕。眉眼温和干净，头发剪得整齐，整个人有一种很安静的斯文气。"
    "他的目光在宿舍里扫了一圈，看到你，微微颔首。"

    "他先把箱子放到书桌旁的地面上，才开口。"
    lm "你好，我是黎妤的哥哥，黎陌尘。"

    "他的声音不高，语速不快，每个字都咬得很清楚。"
    lm "过来帮她搬行李。放好东西马上就走，不会久留。"

    "他拎着行李箱走到靠阳台那套上床下桌旁。他先把箱子放在书桌旁边的地面上，没有直接搁在桌面上——像是怕箱子底的灰蹭脏桌板。"
    "你注意到他的手指——修长，干净，指腹有薄茧。你闻到一点很淡的松香气息。那是练琴的人身上常有的味道。"
    
    scene bg chujian_ly at bg_top
    "黎妤从黎陌尘身后的走廊走进寝室。她扎着高马尾，几缕碎发从耳后逃出来，贴在额角。宽松的浅杏色工装外套上沾了一小块颜料，她自己大概没注意到。"
    "她身上斜挎着一个巨大的帆布画包，包身塞满画笔、水彩盘与速写本，拉链只拉了一半，一支炭笔从缝隙里探出头来。怀里还抱着一摞厚重画纸，另一只手推着装满美术用品的小拉杆箱。"
    "她朝你笑了笑，带着一点歉意。"

    ly "不好意思呀，我哥帮我搬大件，贸然进来吓到你了。"
    
    "她把画纸往桌上一放，腾出手朝你挥了挥。"

    ly "你好，我是黎妤，之后四年的室友。"

    "你停下修图的动作，转头看向她，报出自己的名字。"
    
    player_name "你好，我是[player_name]。"

    "黎妤轻快点头，推着小行李箱走向靠阳台的空位。她随手把沉重画包往桌上一放，画袋里的炭笔、调色管哗啦滑出来散了半桌。她抬手抹了把额角薄汗，完全没管那堆东西。"
    ly "路上报到的人太多，耽误了不少时间。我还以为这间寝室暂时只有我一个人。"

    scene bg quiet_ly at bg_top
    "她弯腰拉开行李箱，往外翻出一堆画册、空白素描本、成套水彩颜料，东西随手往桌面、床沿堆放，毫无条理。你看着那堆颜料，忽然觉得，这个人大概从来不会把东西整整齐齐地收好。"

    scene bg leave_dorm_lm at bg_top
    "一旁的黎陌尘安静帮她把沉重画板立在墙角放稳，他蹲下身，把画板靠在墙边，调整了一下角度，确认不会倒，才站起来。"
    "他转头看向黎妤，语气平淡，但语速比刚才慢了一点。"
    
    lm "画板放这儿了。颜料别堆在书桌边上，晚上从梯子下来会碰掉。"
    "黎妤头也不回地应了一声。"
    ly "知道啦知道啦。"

    "黎陌尘看了她一眼，没再说什么。他转头礼貌地朝你颔首示意。"

    lm "东西我帮她放到这里就先走了。你们慢慢收拾。"

    "说完他转身离开宿舍，轻轻带上房门。门合上的声音很轻。这个人连关门都在照顾别人的耳朵。"

    scene bg camera_ly at bg_top
    "她视线扫过你收拾整齐的书桌，目光落在桌面上摊开的相机上，眼里露出好奇。"
    ly "哇，这是你的相机吗？"
    "你点了点头。"
    ly "看起来好专业啊，你是不是很喜欢摄影呀？"
    player_name "还好啦，就是平时比较喜欢随手记录身边的人和风景。"
    ly "好羡慕啊！我一直觉得用镜头定格瞬间是一件很浪漫的事。"
    "她凑近一步，眼睛亮晶晶的。"
    ly "对啦，我可以看看你的作品吗？"
    menu:
        ly "对啦，我可以看看你的作品吗？"
        "当然可以。":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = "黎妤"
            show screen affection_change
            player_name "当然可以。"
            $ affection_change = ""
            "你拿起相机，点开相册，随意调出几张平日里拍下的照片——街边的落日、街头的路人，还有报到路上拍到的校园光景——递到黎妤面前。"
            scene bg take_camera_ly at bg_top
            "黎妤凑上脑袋，看得十分认真。第一张翻到第二张时，她的手指停在半空；看到第三张，她忽然“啊”了一声。"

            ly "这张——"
            "她指着屏幕上那张报到路上拍的校门口。照片里，一个女生正（dian jiao）帮同伴整理衣领，旁边一个男生拖着箱子回头喊人。"
            ly "这个女生我认识！她是我高中同学！"
            "她抬起头看你，眼睛比刚才更亮。"
            ly "你什么时候拍的？我怎么没看到你？"
            player_name "就……路过的时候随手拍的。"
            ly "随手拍都这么好看？"
            "她低头又看了一遍，指尖悬在屏幕上方，克制住想要触碰的冲动，生怕误触删掉照片。"
            ly "你很擅长捕捉别人身上鲜活的感觉。"
            "她看完相册，恋恋不舍地把视线从相机屏幕挪开。"
            ly "好看呀，你的技术真的很厉害！！！"
            "黎妤看完相册，把相机还给你。两个人顺势拉开话匣子，话题越聊越宽。"
        "抱歉，我不太想分享。":
            player_name "抱歉，我不太想分享。"
            "你把相机收回，点开电脑，继续修整刚才拍的照片。"
            ly "没关系啦，我理解的。"
            "她看着你专注修图的样子，轻轻叹了口气。"
            ly "我也不太会拍照啦，只是喜欢欣赏别人拍的照片。"
    $ renpy.block_rollback()

    play music "music/Chill Coffee Groove 舒缓.MP3" fadein 1.0
    "你们互相聊起各自的专业。你说起自己选择这个专业的缘由，还有对摄影这份爱好的执念。黎妤也兴致勃勃地和你讲起美术系的日常，说起水彩、插画，滔滔不绝。"
    "聊到兴起，她忽然想起什么，指了指门口。"

    ly "对了，我哥是音乐系的。会好多乐器，钢琴、小提琴都弹得很好。"
    "她语气里带着一点炫耀，又带着一点无奈。"
    ly "不过他平时没事就闷头写曲子，性格比我安静好多。有时候我跟他说话，他要过好几秒才反应过来。"
    "她顿了顿，补了一句。"
    ly "但他写的轻音乐特别好听。特别适合画画的时候当背景音。"
    "她说这句话的时候，语气比刚才认真了一点。"
    ly "等之后有空我可以分享给你听听。"

    "一来一回，寝室里气氛轻松热络，两个人越聊越投机，几乎快要忘了时间。就在你们聊得正投入的时候，黎妤的手机忽然叮咚响了起来。屏幕上跳出备注“哥”的来电。"
    "铃声骤然打断了你们的闲谈。黎妤的手停在半空，这才发现窗外天色已经变了。"

    ly "哎呀！坏了，光顾着跟你聊天，我完全忘记我这边行李还没收拾妥当。"

    scene bg dorm_balcony_phone_ly at bg_top
    "她对你点点头表示歉意，去阳台接起电话。"

    ly "喂，哥？"
    ly "还没有收拾完呢，刚才和新室友聊得太投入，耽搁好久啦。"
    ly "晚饭就去食堂吃吧。吃完我本来还想去湖边写生的"
    ly "知道啦，我很快搞定！晚点联系你。"

    "简短说完，黎妤挂断电话，转头有些不好意思地看向你。"

    ly "不好意思呀，聊得太上头把正事抛到脑后了。我得赶紧把这些画材、行李箱整理归置好。咱们先聊到这里，等收拾完有空我们再接着唠！"
    
    scene bg quiet_ly at bg_top
    "你对她笑了笑，表示理解。她转过身，重新埋头处理散落在桌面、书桌旁地面的一堆画册与颜料。黎妤收拾了许久，才勉强把各类画材大致归拢到书桌书架。画纸整齐堆叠在书桌旁的置物架上，只是桌面依旧散落着几支画笔。"
    "她直起身揉了揉发酸的胳膊，转头看向你。"
    
    scene bg turnaround_ly at bg_top
    ly "之后寝室有什么需要互相帮忙的地方，都可以直接说。我平时画画会弄得满手颜料，尽量不弄脏公共区域。要是我画画弄得太晚，动静会尽量放轻，不打扰你们休息。"
    
    player_name "我很多时候会出门采风，或许我们会很合得来。"

    scene bg go_out_one_ly at bg_top
    "黎妤走到自己的床位旁，弯腰收拾起随身的背包，把速写本、几支画笔一一塞进去。"
    ly "我等会儿要下楼找我哥去食堂吃饭啦。你晚饭打算怎么解决？要是食堂人特别多的话，注意避开高峰，别饿着肚子。"
    player_name "我打算自己随便出去吃点，逛逛校园再回宿舍。"

    scene bg go_out_two_ly at bg_top
    "黎妤点点头，把背包带子挎到肩上。"
    ly "那行，那我先走咯。外面傍晚风有点凉，你出门也多留意一点。回来之后我们再接着聊天。"
    "说完，黎妤挥了挥手，便拎着背包走出寝室，房门被轻轻带上。"

    scene bg dorm_interior at bg_top
    "黎妤离开后，宿舍只剩画笔滚过桌面的细响。你看了一眼仍亮着的相机屏幕，校门口那张照片还停在那里。"

    scene bg dorm_interior at bg_top
    "你将p好的照片发给牵绕后，起身准备出门觅食。"

    scene bg teaching_building_dusk at bg_top
    "路过教学楼的时候，听到一阵钢琴声从二楼窗户飘出来。你抬头看了一眼。二楼琴房的灯亮着。"
    "你本来打算走，脚步却在台阶边慢了半拍。琴声是一支没听过的曲子，旋律舒展，尾音贴着夜风落下来。"
    "弹完之后，琴房安静了几秒。然后又开始弹第二遍。"
    menu:
        "琴声从亮灯的窗户里传来，你准备："
        "停下来听完":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            "你站在楼下，听完了两遍。你拿出相机，对着亮灯的窗户拍了一张。"
            $ affection_change = ""
            "你不知道那是谁。但你记住了那个窗户的位置。"
        "直接走":
            "你走了。琴声在你身后越来越远。"
    $ renpy.block_rollback()

    scene bg canteen_road at bg_top
    "你走出宿舍楼，沿着林荫道向食堂方向前行。夕阳的（yu hui）洒在校园小径上，映照出拉长的影子。你走得不快，偶尔停下来拍两张被夕阳照亮的树叶。"

    scene bg canteen at bg_top
    "食堂门口人流拥挤。你排队打完饭菜，找了一处空位，将餐盘放在桌上，正准备坐下。你的视野里突然出现一个女生。"

    scene bg chujian_xl at bg_top
    "她站在你桌边，怀里抱着几本厚重的书，书脊上贴着图书馆的标签。齐肩的浅棕软发垂在脸颊两侧，几缕碎发贴在白皙的耳廓边。"
    "眉眼生得清淡柔和，长长的睫毛微微垂落，肤色偏白，一身素色浅灰连衣裙衬得整个人气质安静斯文。"
    "她看到你，手指在书脊上停了一瞬，随即露出一丝浅浅的笑意。"

    xl "[player_name]，真巧，你也过来吃晚饭。"
    player_name "欸，你是小莱？好巧啊，居然能遇见你。"
    "你隐约记得高中时她总是坐在教室最后一排靠窗的位置。你们没说过几句话。"
    "她点了点头，目光扫了一眼你对面空着的座位，又看了看怀里的书。"
    xl "这里位置还空着，请问我可以坐在这里和你拼桌吗？"
    
    menu:
        "要不要和她一起拼桌？"
        "同意拼桌":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = xl_display_name
            show screen affection_change
            xl "那我先把书放这儿占一下位置，麻烦你稍等我片刻，我去打饭，很快就回来。"
            $ affection_change = ""

            "说完她转身走向打餐窗口。你坐在座位上等她，目光落在那摞书上面。封皮大多是历史相关的典籍，还有几本薄薄的学术随笔。其中一本的书脊上贴着一张小小的便签，上面写着几个字，但距离太远，你看不清。"
            "没过多久，小莱端着餐盘走回来。餐盘里菜式简单清淡，一份青菜、一份豆腐、一小碗汤。几缕被晚风吹乱的发丝贴在她的额前，她抬手，指尖轻轻把碎发捋到耳后。"
            
            scene bg rice_xl at bg_top
            "小莱把餐盘轻轻放在桌上，拉开椅子坐下。晚饭的氛围安安静静，食堂嘈杂人声远远隔在四周。"
            
            xl "今天报到跑来跑去，折腾一天，你宿舍那边都收拾妥当了吗？"
            player_name "差不多收拾完了，今天刚认识我的室友，大家性格都各不相同。"

            "小莱指尖轻轻摩挲着餐盘边缘，语气温和。"

            xl "能遇到相处得来的室友会轻松很多。我住另外一栋宿舍楼，我的室友今天还没有过来，今天一整天基本都是我一个人在各处跑手续。"
            "她目光无意间扫过你身侧斜放的相机包，眼里露出一丝好奇。"
            xl "看你背着相机包，报到路上应该拍了不少校园景色吧。汴京大学的傍晚风景很不错。"
            player_name "嗯，路过好看的地方就随手拍几张记录一下。"

            "小莱没有继续追问，只抿了一口汤。拿勺子的手指微微发颤，幅度很小，却没逃过你的视线。你把问题留在了心里。"
            "等各自吃完，小莱起身，将桌面自己产生的垃圾简单收拾干净。"
            
            xl "谢谢你愿意让我拼桌，我还要回宿舍整理今天领到的教材，就先不继续逗留啦。"
            
            "你们简单道别。你想起背包里的相机，索性打算趁着傍晚柔和的暮色，一个人出去校园采风。"

        "委婉拒绝":
            $ player_affection += 3
            $ affection_change = "+3"
            $ affection_target = xl_display_name
            show screen affection_change
            player_name "不好意思，我想一个人安静吃晚饭。"
            $ affection_change = ""

            "小莱神色没有失落，只是礼貌地点点头。"
            xl "没关系，那我另外找位置。"
            scene bg canteen_desk at bg_top
            "她抱着书本，转身走向食堂其他空位。她走得很慢，书有点沉，她换了一次手。你看着她的背影，忽然注意到她走路时右脚似乎比左脚轻一点。"
            "你独自吃完晚饭，想起背包里的相机，索性打算趁着傍晚柔和的暮色，一个人出去校园采风。"
    $ renpy.block_rollback()
    
    scene bg teaching_building_dusk at bg_top
    "夕阳把校园的树木、教学楼的轮廓染上一层暖橘色调。你挎着相机包，漫无目的地在校园各处闲逛。遇到好看的光影、路过晚风吹拂的香樟林，你便停下脚步举起相机，将一幕幕傍晚独有的校园景致拍摄下来。"
    "走到湖边时，你停下来。湖面被夕阳照得发亮，岸边有几个学生在拍照，还有一个人坐在长椅上写生。"

    scene bg sketch_ly at bg_top
    "你举起相机，取景框里是一个女生的侧影。她伏在速写本上，铅笔沿着纸面快速移动。你按下快门，看了一眼预览。"
    "照片里，马尾和湖面的余光重叠在一起。你认出那是黎妤。她画得太专注，你不想走过去打断。"
    "你站在远处又拍了一张，一张远景，一张侧影。随后把相机收进包里，沿着亮起的路灯往宿舍方向走。"

    # ————————————————————————————————————————————————————————————————————————
    play music "music/黄昏海岸线.MP3" fadein 1.0

    scene bg desk_turn_on at bg_top
    "你走回女生寝室，轻轻推开宿舍门，寝室灯火明亮，屋内暖光柔和。"

    scene bg chujian_jf at bg_top
    "宿舍坐着两位女生，靠门那套上床下桌旁，一个女生正低头翻看手里的书本。她坐姿端正，脊背挺直，翻页的动作不急不缓，像是在读什么重要的东西。"

    scene bg computer_hx at bg_top
    "邻近的座位上，另一个女生安静地坐着。她面前摊着一台笔记本电脑，屏幕上是密密麻麻的代码，但她的视线没有落在屏幕上，而是微微侧着头，像是在听旁边的人翻书。"
    "两个人没有高声说笑，只是低声有一搭没一搭闲聊。"

    scene bg talk_turn_jf at bg_top
    "听见推门响动，看书的那位女生立刻抬眸望过来，主动朝你轻轻点头，率先开口打招呼。"

    jf "回来啦？"
    "她合上书，站起来，朝你笑了笑。笑容很自然，像是早就准备好了要打招呼。"
    jf "我叫江枫，很高兴成为你的室友。"
    player_name "你好，我是[player_name]，很高兴认识你。"

    scene bg chujian_hx at bg_top
    "坐在一旁的另一位女生没有主动插话，只是抬眼安静看向你，浅浅弯了弯嘴角。她的目光很轻，像是不习惯被人注意到。"
    "她坐在那里，黑色长发垂在肩侧，左边的小辫子串着几颗白色珠子。你朝她点了点头，她的手指攥住袖口。"
    menu:
        "主动打招呼":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "你好，我是[player_name]。"
            $ affection_change = ""

            hx "你好，我是怀小柿。"
            "声音不大，但很清楚。说完，她又补了一个字。"
            hx "计算机系。"
            "说完，她把视线落回屏幕，手指仍攥着袖口。"

        "不打招呼":
            player_name "……"
            hx "你好，我是怀小柿，计算机系。"
            "声音不大，但很清楚。"
            "说完，她把视线落回屏幕，手指仍攥着袖口。"
            player_name "你好，我是[player_name]。"
            "她点了点头，没有再看你。但你知道，她听见了。"
    $ renpy.block_rollback()

    scene bg talk_turn_jf at bg_top
    jf "[player_name]……"
    "她歪头想了想，像是在回忆什么。"
    jf "我记得你，你发在朋友圈的照片很好看。"

    player_name "是吗？谢谢夸奖。你发在朋友圈的手工制品超级精致的。"

    jf "哈哈，谢谢你。这是我的兴趣爱好，做起来很放松。"

    scene bg desk_turn_on at bg_top
    "你对江枫有一点印象，寝室群里面发言最活跃的就是她。你笑着应声，算是正式打过照面。"
    "宿舍还没热闹多久，门外传来轻快的脚步声。"

    scene bg candy_ly at bg_top
    "门被推开，黎妤提着一大袋鼓鼓囊囊的零食走进来。袋子太重，她半拖半抱，肩膀微微歪着，马尾辫随着动作一晃一晃。她眉眼亮晶晶的，一进门就扬起明媚的笑意。"

    ly "我回来啦！校门口买了好多零食，大家一起分着吃！"

    "她把袋子往书桌上一放，袋子倒下，里面的饼干、糖果、小面包滚出来一半。她看了一眼，转身从画包侧袋里抽出一卷东西。"

    "她抖开那卷东西，是一张浅蓝色的野餐垫，边缘印着白色的小碎花，叠痕很深，一看就是经常用的。"
    ly "我本来打算周末去湖边写生用的，今天先拿来用！地上铺着坐，比搬椅子舒服。"

    "她说着，弯腰把书桌旁边的空地清出来，画材往墙角一推，野餐垫哗啦铺开。垫子不大，刚好够四个人围坐。你看见垫子上有一块浅浅的颜料印，洗过，但没洗掉。"
    "她毫不生疏地把饼干、糖果、小面包全部倒出来摊在桌面。你注意到她书桌旁边堆着的画材比出门前更乱了，但她自己好像完全不在意。"

    scene bg talk_jf at bg_top
    "江枫看了一眼黎妤手里的野餐垫，笑了。"
    jf "你还真是什么都带了啊。"

    "黎妤理直气壮。"
    ly "那当然，我可是准备周末去湖边写生的。今天先拿来用，反正地上坐着比椅子舒服。"

    scene bg sitdown_talk_jf at bg_top
    "江枫站起来，先把书桌下的插座线往旁边踢了踢，怕绊到人，然后才在垫子上坐下。她坐姿很端正，像是习惯这样坐。"

    scene bg sitdown_talk_hx at bg_top
    "怀小柿是最后一个动的。她把自己的椅子推到墙边，然后走过来，在垫子边缘坐下。她坐得很靠外，只坐了垫子的一个角，像是随时可以站起来。"

    "你坐在怀小柿和黎妤之间。零食袋子被放在垫子正中间，随手可以拿到。"
    
    scene bg sitdown_talk_ly at bg_top
    "黎妤是唯一一个把腿伸到垫子中间的人。江枫坐得端正，怀小柿抱着膝盖，你盘着腿。"

    scene bg sitdown_talk_jf at bg_top
    "江枫坐下之后，顺手把垫子中间那袋零食往自己这边拉了拉，腾出一块空地。"

    jf "来来来，都坐近一点。垫子就这么大，谁也别想躲。"

    "她说这话的时候，语气很随意，但目光在每个人脸上扫了一圈。怀小柿听到这句话的时候，往垫子中间挪了一点点。只挪了一点点。但挪了。"

    scene bg sitdown_talk_jf at bg_top
    "江枫率先打开话匣子。她坐姿端正，一只手搭在膝盖上，另一只手随手拿了一颗糖。"
    
    jf "我是音乐系的，平时最大的爱好就是唱歌，闲下来就喜欢做各种各样的手工小物件。"
    "她把糖纸剥开，但没吃，拿在手里折来折去。"

    ly "手工？你都做什么呀？"

    jf "什么都做。小摆件、纸鹤、书签，最近在试着做那种可以挂在包上的小挂件。"
    "她手里的糖纸已经被折成了一只很简陋的纸鹤。"
    jf "我家是在桃溪村那边长大的，那边山多，环境很安静。"
    "她把纸鹤放在垫子中间，推到大家面前。"
    jf "喏，见面礼。"
    
    scene bg sitdown_talk_ly at bg_top
    "黎妤立刻伸手把纸鹤拿起来，举到眼前看了半天。"
    ly "哇，你好厉害！我手残，连鞋带都系不好。"

    "江枫笑了一声。"
    jf "你画画的手，怎么可能手残。"

    "黎妤理直气壮。"
    ly "画画和折纸不一样嘛！"

    scene bg sitdown_talk_jf at bg_top
    "江枫这个人大概很习惯用动手来掩饰紧张，你猜的。"
    "江枫忽然想起什么，补了一句。"
    jf "对了，我还有个弟弟。他叫谢旻，跟我一样是音乐系的。"
    "黎妤抬起头。"
    
    ly "欸？你弟弟也考到汴京大学了？"
    jf "嗯。我们俩一块儿长大的。"
    "她说这句话的时候，语气很随意，像是在说一件再普通不过的事。"
    "但你注意到，她说“一块儿长大”的时候，手里的纸鹤折到了最后一折，停了一下。只是一下。然后她把纸鹤放在垫子中间，推到了大家面前。"
    jf "反正明天你们就见到了。"
    "她没有再多说。你识趣的也没有多问。但你注意到，坐在旁边的怀小柿，在听到‘谢旻’这个名字的时候，抬了一下眼。"
    "她看了江枫一眼。只是一眼。很快又低下了头。江枫把这一切收在眼里，却没有点破。她只是把手里第二只纸鹤放在垫子中间，然后转头看向旁边的怀小柿，语气很自然地接了一句。"
    jf "对了，小柿子，你也介绍一下自己吧。"
    
    scene bg sitdown_talk_hx at bg_top
    "怀小柿稍稍局促地攥了攥袖口。她坐在垫子最边缘，膝盖抱在怀里，整个人缩成小小的一团。"
    "她低头的时候，左侧发间那枚银色带蓝色水滴的发饰轻轻晃了一下。她的声音不大，语速偏慢，像是每个字都要先在心里过一遍。"
    
    hx "我叫怀小柿，计算机系。"
    "她停了一下。"
    hx "平时大部分时间喜欢敲代码写程序，私下也会写小说。偶尔压力大的时候，会打打游戏放松。"
    "又停了一下。"
    hx "我也是桃溪村出来的，和江枫是从小一起长大的发小。"
    "说完，她把袖口又攥紧了一点，像是完成了什么艰巨的任务。"
    
    jf "她写的小说可好看了，就是不给人看。"
    "怀小柿的耳根微微红了。"
    hx "……还没写好。"
    "黎妤凑过来，眼睛亮晶晶的。"
    ly "写什么的？科幻？悬疑？还是爱情？"
    "怀小柿翻备忘录的手停住，像是没想到会被追问。"
    hx "……都有。"
    ly "那你写好了一定要给我看！"
    "怀小柿的嘴角动了一下，视线仍落在膝盖上；黎妤追问“写什么的”时，她才抬眼看了一瞬。"
    "江枫在旁边看着这一幕，没有插话。她只是低头，把刚才那只纸鹤又折了一下，让它的翅膀更整齐一点。"
    
    scene bg eat_candy_ly at bg_top
    "黎妤咬了一口糖果，兴致勃勃接话。"

    ly "我是美术系的，主攻水彩和插画。"

    "她嚼着糖，说话有点含糊，但语气很笃定。"
    ly "一天不画画就浑身不自在，速写本几乎不离手。"
    "她指了指墙角那堆乱糟糟的画材。"
    ly "你们看那堆东西就知道了，我哥说我像在宿舍里开了个画室。"

    scene bg sitdown_talk_jf at bg_top
    "江枫看了一眼那堆画材。"
    jf "你哥也是美术系的？"
    "黎妤摇头。"
    ly "音乐系的。钢琴小提琴都弹得挺好。"
    "江枫笑了一声。"
    jf "那你哥是不是也挺闷的？"

    scene bg eat_candy_ly at bg_top
    "黎妤想了想。"
    ly "何止是闷。"
    "她顿了顿，像是想起什么，又补了一句。"
    ly "不过今天我让他帮我搬行李，他答应得挺快的。"

    # 黎陌尘本来可以去更好的学校，但是填了和黎妤在一起的大学，后面会写
    "她说这句话的时候，语气忽然轻了一点。然后她像是意识到什么，立刻把话题岔开。"
    ly "对了，我是本地人啦。你们想出去玩可以问我，我知道有很多好玩的地方！"
    "她说这句话的时候，眼睛亮亮的，像是已经在脑子里规划好了路线。"

    scene bg desk_turn_on at bg_top
    "轮到你了。你坐直了一点。"
    player_name "我是文学系的，平时专业课会读很多文学作品。"
    "你停了一下，像是在想怎么说才准确。"
    player_name "我的主要爱好是摄影。喜欢拿着相机记录身边的人和风景。"
    "黎妤立刻接话。"

    ly "对！她拍照超好看的，我今天下午看了！"

    "江枫看了你一眼，又看了看你书桌上那台旧相机。"

    jf "那你以后可以多拍拍我们。"

    "她说这话的时候语气很随意，像是随口一提。怀小柿听到这句话的时候，微微缩了一下肩膀。你和江枫都注意到了。"

    "江枫什么都没说,只是把手里那只纸鹤，轻轻放在了怀小柿的膝盖旁边。怀小柿低头看了一眼那只纸鹤，没有拿，但她的肩膀，松了一点。"
    # 怀小柿害怕被注视，害怕上台
    
    scene bg desk_turn_on at bg_top
    "气氛慢慢热络起来。四个人围坐在野餐垫上，顺着自我介绍继续闲聊。聊起各自高中的生活、家乡的风土，聊到来到汴京大学之后内心的期待与忐忑。"
    "江枫说起桃溪村的山间晚风，说起童年在老家唱歌、做手工的趣事。她说到高兴处，又拿了一张糖纸，开始折第三只纸鹤。"
    "怀小柿大多时候在一旁安静倾听，问到她的时候才会简单多说几句，偶尔会聊起写小说时构思的故事，或是吐槽游戏里遇到的奇葩队友。"
    "话依旧不多，但不再像刚刚进门那样拘谨。她抱着膝盖的姿势也慢慢松开了，改成盘腿坐着。"
    "那只纸鹤还放在她膝盖旁边。她没有拿，但也没有把它推走。黎妤叽叽喳喳讲着画室的日常，讲自己想做有温度的插画。"
    
    scene bg desk_turn_off at bg_top
    "时间一点点流逝，窗外夜色越来越浓。热闹的闲聊慢慢淡下去，奔波一整天带来的疲惫感慢慢涌上来。夜色渐深，宿舍氛围慢慢安静。"
    "黎妤第一个站起来，把野餐垫抖了抖，叠好塞回画包侧袋。她叠得很随意，边角没对齐，但也没在意。"
    "江枫把自己坐的那块地方收拾了一下，捡起掉在地上的糖纸。怀小柿默默把垫子边缘的碎屑扫到手心，扔进垃圾桶。"
    "你弯腰把自己那边垫子边角的碎屑拢了拢，顺手把滚到桌脚的一颗糖捡起来，放在黎妤桌上。"
    "之后各自收拾、简单洗漱。临关灯前，几人轻声互道晚安。"
    "你爬上梯子，躺到床上。闭上眼睛，脑海里闪过今天遇见的一张张脸。然后你睡着了。"

    # ————————————————————————————————————————————————————————————————————————
    play music "music/日常 轻快 悠闲 放松吉他.MP3" fadein 1.0

    scene bg dorm_morning at bg_top
    "第二天清晨，手机闹钟接连响起，将你们从睡梦中唤醒。天光透过阳台窗帘缝隙溜进宿舍。大家陆续起床，简单洗漱、整理仪容。"
    
    scene bg teaching_building_morning at bg_top
    "你们收拾妥当，锁好宿舍门，结伴一同朝着教学楼走去。清晨的阳光柔和明媚，校园路上已经有不少赶去上课的新生，一路上几人随意闲谈，慢慢走到教学楼教室门口。"
    
    scene bg classroom at bg_top
    "江枫抬眼朝着教室里面望了一圈，很快看见了目标。朝靠窗位置的男生扬了扬下巴。"

    scene bg chujian_xm at bg_top
    "那名男生看见江枫，也朝这边招了招手。他身形高挑，利落的短发，眉眼鲜活明亮，隔着人群都能感受到一股朝气蓬勃的气质。"

    jf "走，位置在前面，就是那边。"

    scene bg classroom at bg_top
    "你们跟着江枫走进教室，走到男生提前占好的座位跟前。这一排靠前的位置留出了四个空位，正好留给你们宿舍四人。"
    "占座的方式很“清奇”——四个座位上各放了一本书，书脊朝上，整整齐齐排成一排。最边上那本书的封面，是一张乐谱。"

    scene bg smile_xm at bg_top
    "待大家纷纷落座之后，谢旻朝你们几人颔首致意。"

    xm "你们好。江枫提前跟我说过，我把这几个前排位置给你们留出来了。"
    "说完他侧过身，抬手示意身旁的两个人。"
    xm "这两位都是我的室友。这位是黎陌尘，旁边这位是凌晨。"

    scene bg classroom_lm at bg_top
    "坐在谢旻左手边的黎陌尘身形清瘦挺拔，柔和的黑发，眉目温润，气质沉静文雅。他朝你们微微点头，没有说话。"
    # 他今天穿了一件浅灰色的薄毛衣，袖口整齐地挽着，手指安静地搭在桌面上。指腹有薄茧

    scene bg classroom_lc at bg_top
    "而靠外侧的凌晨，则是一副冷峻的模样，利落的浅冰蓝色短发，轮廓清冽，神情疏离。他靠在椅背上，不主动向外展露情绪。"
    "他的桌上放着一本书，书页间夹着一支铅笔。他翻过一页，随后合上书，像是已经读完了足够多的内容。"

    scene bg classroom_ly at bg_top
    "黎妤猛地眼睛一亮，略带几分惊喜地看向黎陌尘。"
    ly "欸？哥，你和谢旻是室友？"

    scene bg smile_xm at bg_top
    "谢旻闻言低低笑出声。"
    xm "可不是嘛，开学分配宿舍的时候看到名单，我们都觉得缘分挺奇妙的。"

    scene bg classroom_lm at bg_top
    "黎陌尘望着自家妹妹，唇角漾开一抹温和的浅笑，轻轻朝黎妤摇了摇头。"
    lm "世界有时候就是这么小。"

    "他说这句话的时候，语气很淡，但你看得出来，他其实挺高兴的。因为他摇头的时候，手指在桌面上轻轻敲了一下。那是一个很轻的动作，像是弹琴前的起手。"

    scene bg classroom at bg_top
    "距离班会开始还有一段时间，教室里的人还没有来齐。你闲来无事拿出手机打发课前的空闲时间。"
    "黎妤在旁边小声跟黎陌尘说话。谢旻偶尔插一句。江枫在翻看手里的笔记本。怀小柿坐在你旁边，安安静静地看手机。凌晨全程没有说话，只是偶尔翻一页书。"
    "你注意到，怀小柿的手机屏幕停在备忘录界面，上面有几行字，但距离太远，你没有看清。你也没有刻意去看。"
    "随着时间推移，陆续有新生走进教室，原本空旷的座位一点点被填满，教室人声慢慢变多。待到全班基本坐满、室内氛围完全热闹起来时，走廊传来沉稳的脚步声。"

    scene bg classroom_fd at bg_top
    "门口光影一动，辅导员拿着花名册和教案走进教室。喧闹的教室瞬间安静下来，所有人目光统一投向讲台，新生第一次班会，正式开场。"
    
    fd "各位新同学，大家上午好。我是本班的辅导员，接下来四年，由我负责大家的日常班级管理、学业督导和生活事宜。"
    fd "首先强调一点，大学自由不代表散漫，规矩和自律是立足校园的第一准则。很多同学会误以为大学可以放松懈怠，这是最错误的认知。"
    fd "初入新环境难免不适应，希望你们尽快调整状态，和室友和睦相处，兼顾学习与成长。愿大家在大学有所收获，不负时光。"

    scene bg classroom at bg_top
    "简短有力的收尾过后，她简单交代了后续班级群通知、资料提交、军训筹备等收尾事宜，随即宣布班会结束。"
    "全班同学陆续起身，有序收拾桌面物品。沉寂一整场的教室瞬间恢复喧闹，新生们三三两两结伴闲聊，讨论着刚刚听到的校规、学业要求和后续安排。"
    
    scene bg classroom_jf at bg_top
    "江枫收好桌上的书本，转头看向身旁几人。"
    jf "正好到饭点了，不如我们一起去食堂吃饭吧？"
    
    scene bg classroom_ly at bg_top
    ly "好呀好呀，人多吃饭还热闹一点！"
    "其余人一同附和，表示没有异议。"

    scene bg teaching_building_corridor at bg_top
    "一行七个人结伴走出教室，顺着教学楼的走廊往外走。正午的阳光明朗耀眼，校园里来往都是下课、散会的新生，一路上几人说说笑笑。"
    "江枫和谢旻走在靠前的位置。谢旻不知道说了什么，江枫抬手拍了他一下，谢旻笑着往旁边躲。躲的时候差点撞到路边的树，被江枫一把拉回来。"
    jf "看路。"
    xm "……知道了。"
    "黎妤黏在黎陌尘身侧，叽叽喳喳跟哥哥说着方才班会上的小感想。黎陌尘大多时候只是听，偶尔‘嗯’一声，但脚步一直跟着黎妤的节奏，不快不慢。"
    "怀小柿走在队伍靠内侧，话不多，大多时候安静听大家交谈。她走路的时候习惯把手插在外套口袋里，肩膀微微收着。"
    "凌晨不怎么开口，慢悠悠跟在队伍侧边。他手里还拿着那本书，但没有翻开，只是握着。你走在人群之中，耳边满是少年少女轻松的闲谈声。"

    scene bg canteen at bg_top
    "一行人结伴走进食堂，正午正是饭点高峰期，大厅人声鼎沸，餐盘碰撞声、说笑喧哗声交织在一起，满是鲜活滚烫的烟火气。"
    "几人分开汇入不同的队伍排队打餐。你排在队伍里，前面是一个正在纠结选什么菜的男生，后面是两个讨论下午去哪儿的女生。"
    "没过多久，七人端着盛好饭菜的餐盘陆续汇合，目光扫视一圈，默契走向一张宽大的长条餐桌。长桌两侧各有一排椅子，面对面摆着。"

    scene bg canteen_hx at bg_top
    "怀小柿最先坐下。她选了最里面靠墙的位置，安安静静地把餐盘放好，筷子对齐摆在餐盘边缘。"

    scene bg canteen_jf at bg_top
    "江枫坐在她旁边，顺手把包放在自己身后的椅背上。"

    scene bg canteen_xm at bg_top
    "谢旻坐在江枫另一侧，把餐盘放下之后，先把自己那碗汤推到江枫手边。"
    jf "我不喝汤。"
    xm "知道。给我自己放的。"
    "江枫看了他一眼，没说话。"

    scene bg canteen_lc at bg_top
    "凌晨最后一个落座，坐在长桌最外侧。他把餐盘放得很轻，和人群隔了一个空位。"
    "你站在桌边，坐在了怀小柿对面，餐盘轻轻搁在桌面上。怀小柿坐在你正对面，低着头。领口那枚深蓝色的蝴蝶结，随着她低头的动作微微垂下来。"

    scene bg canteen_ly at bg_top
    "黎妤一屁股坐在你旁边，拍了拍自己旁边的椅子，朝黎陌尘招手。"
    ly "哥，这边！"

    scene bg canteen_lm at bg_top
    "黎陌尘端着餐盘走过来，坐在黎妤身旁。他把餐盘放得很轻，筷子对齐摆在餐盘边缘。"

    scene bg canteen_jf at bg_top
    "刚坐稳，江枫手肘轻搭桌沿，眉眼弯起，率先看向众人打开话匣子。"
    jf "第一天开学班会开完，总算松了口气，接下来就要准备军训了，你们会不会有点紧张？"
    
    scene bg canteen_xm at bg_top
    "谢旻坐在她旁边，闻言抬头。"
    xm "还好，军训虽然累，但也是最快熟悉班级同学的机会，挺期待的。而且人多一起熬，根本不算辛苦。"

    scene bg canteen_ly at bg_top
    "黎妤坐在你旁边，咬着筷子接话。"
    ly "我倒是不怕累！就是怕太晒了，我最怕被晒黑了！不过能和大家一起军训，感觉会超级有意思。"
    "黎妤忽然转过头看你。"
    ly "[player_name]，刚刚导员提了竞选班委的事情，你打算去竞选吗？"
    player_name "我就不去竞选啦，平时上课就有的忙了。"
    player_name "话说你们打算竞选吗？"
    
    scene bg canteen_xm at bg_top
    "谢旻胳膊往江枫那边一靠，挑眉打趣，嘴角噙着促狭的笑。"
    xm "我敢打包票，我姐肯定会去。"

    scene bg canteen_jf at bg_top
    "江枫闻言抬手，轻轻拍了下谢旻的胳膊，佯作瞪了他一眼。"
    jf "你又抢我台词。"
    "姐弟俩小声嬉闹起来，胳膊互相轻轻推搡。趁着众人注意力落在他俩身上，怀小柿身子微微朝前倾过来,她坐在你正对面，隔着桌子，压着嗓子小声说话。"

    scene bg canteen_hx at bg_top
    hx "他们两个肯定会一起去竞选的，我和江枫从小到大都在一个班，每次她都会去竞选文艺委员。"
    hx "谢旻也会去竞选，不过每次他都争不过江枫，最后退一步成为学委。"
    "你望着一旁打打闹闹的姐弟二人，忍不住弯起嘴角。"

    scene bg canteen_ly at bg_top
    "这时黎妤忽然转过身子，神情一本正经，目光直直望向身侧的黎陌尘，语气郑重。"
    ly "哥。"
    "黎陌尘抬眸看向自家妹妹，眼底带着一丝疑惑，安静等着她继续往下说。"
    ly "你平时说话太少了，我觉得你应该做出一些改变。"

    scene bg canteen_lm at bg_top
    "黎陌尘嘴唇微张，一时语塞，只是轻轻嗯了一声。"
    ly "哥，你去竞选班长吧，能力越大，责任越大。"
    "黎陌尘顿住，眉头微微蹙起，无言地看着跃跃欲试的妹妹，一时间不知道该怎么回应。"

    scene bg canteen_xm at bg_top
    "正在和江枫说笑的谢旻听见对话，猛地转过头来，十分积极地跟着附和。"
    xm "就是啊陌尘，我觉得你很适合的，去试试吧。"
    
    scene bg canteen_lm at bg_top
    "黎陌尘长长呼出一口气，眼神扫过在座众人。"
    lm "………………"
    lm "你们串通好的吧。"
    "在座几人彼此对视一眼，全都心照不宣地点了点头。黎陌尘的视线落到全程沉默的凌晨身上，没想到连素来冷淡寡言的凌晨，也微微颔首表示赞同。"
    "黎陌尘无奈地抬手扶了下额头，长长叹了口气，一副认命的模样，缓缓点了点头。"
    lm "行吧，我去参加竞选。"
    
    "一句妥协落下，桌面瞬间响起细碎的笑声，方才打趣闹腾的氛围慢慢沉淀下来。"
    "窗外正午的暖阳透过食堂的玻璃窗洒落，温柔铺在餐桌与众人肩头，驱散了喧闹的浮躁，氛围变得温柔又安静。江枫撑着下巴，眼底褪去嬉闹，多了几分认真与热忱，轻声打破静谧。"
    
    scene bg canteen_jf at bg_top
    jf "说起来，我们刚好凑在一起——"
    "她话说到一半，谢旻把汤碗往她手边推了推，坐在旁边插嘴。"
    xm "姐，你那个原创歌什么时候写完？我伴奏都练好了。"
    "江枫侧头瞪了他一眼。"
    jf "还差最后一段。我总觉得副歌不够好。"
    ly "你们要表演吗？我也想上台！哥，你帮我伴奏好不好？"
    "黎陌尘坐在她另一侧，看了她一眼。"
    lm "……你先把你那幅画完。"
    "大家笑起来。"

    scene bg canteen_desk at bg_top
    "你看着他们，忽然想起自己相机里那些照片。街头的路人、校门口的新生、牵绕站在香樟树下的侧影、黎妤在湖边写生的背影。"
    "你拍过很多人，但你好像从来没有问过他们，他们的梦想是什么。"
    player_name "其实……我拍过很多人。但我好像从来没问过他们，他们的梦想是什么。"

    scene bg canteen_jf at bg_top
    "桌上安静了一秒。江枫没有看你，只是用筷子戳了戳自己碗里的青菜，语气很随意。"

    jf "我小时候想当歌手来着。"

    "她说得很轻，像是随口一提。"
    jf "后来发现唱歌好的人太多了，我就想，那至少写一首自己的歌吧。"
    "她把青菜夹起来，塞进嘴里。"
    jf "现在还在写。写了三年了，还没写完。"
    "谢旻坐在她旁边，闻言笑了一声。"

    xm "你那首歌唱给我听过，副歌挺好听的。我伴奏都练好了。"

    jf "你懂什么。"
    xm "我不懂，但我练了。"
    "江枫没接话，只把折到一半的糖纸压平，又重新折出一道棱。"

    scene bg canteen_ly at bg_top
    "黎妤坐在你旁边，咬着筷子想了想。"

    ly "我没什么大梦想。我就想画到有一天，有人看到我的画会说“这个人的画，我一看就知道是她画的”。"

    "她说完，自己先笑了，筷子在碗沿上轻轻敲了一下。"
    ly "是不是有点土？"
    lm "不土。"
    "黎陌尘坐在她另一侧，声音很轻。"

    lm "能被人认出来，已经很难了。"

    "他说这句话的时候，没有看任何人，只是把筷子整整齐齐地放回餐盘边缘。你看见，他说完这句话之后，谢旻看了他一眼，最后什么都没有说。"
    "怀小柿一直没有接话，筷子在碗里慢慢拨着饭粒，像是在数数。江枫把自己餐盘里那块没动过的排骨夹进她碗里。怀小柿的筷子碰到碗沿，发出一声清响。"

    scene bg canteen_lc at bg_top
    "凌晨忽然开口了。"

    lc "我想做一个网站。"

    "桌上几个人同时看向他。凌晨没有在意那些目光，继续说。"
    lc "一个属于我自己的网站。上面放一些……对我很重要的东西。照片、文字、有时候是一段录音。"
    "他停了一下。"
    lc "算是备忘录吧。也算是，不想忘的东西。"
    "他合上那本随身带来的书，拿起筷子继续吃饭，仿佛刚才只是报出一个网址。"

    scene bg canteen_hx at bg_top
    "怀小柿也听到了。她的筷子碰到碗沿，停在半空。"
    "然后她开口，声音很小。"

    hx "……我想写一个能让人记住的故事。"

    scene bg canteen_desk at bg_top
    "午饭结束，大家起身收拾餐盘。你忽然开口。"
    player_name "等一下。"
    "六个人同时看向你。你举起相机。"
    player_name "……我想拍一张。"
    "没有人问为什么。"
    
    scene bg canteen at bg_top
    "江枫第一个反应过来，拉着怀小柿往中间靠。谢旻从江枫旁边探出半个身子，对着镜头比了个手势。黎妤一把拽住黎陌尘的袖子，把他从边上拉进来。凌晨站在最外侧，没有动，但也没有走。"
    "你举起相机，对准他们。取景框里，六个人挤在一起。你按下快门之前，停住了。你不在里面，你也应该在里面。"

    scene bg canteen_girl at bg_top
    "你转头看了一圈。食堂里人来人往，大部分桌子都坐满了人。靠窗那桌坐着一个女生，面前放着一碗还没动几口的粥，正在低头看手机。她看起来不像是赶时间。"
    player_name "你好，能不能帮我们拍一张？"
    "她抬起头，手指在手机边缘停了一瞬，随后点了点头。你把相机递给她，简单说了一下怎么按快门。她接过相机时动作谨慎，像是很少碰这种东西。"
    
    scene bg canteen_camera_girl at bg_top
    "你跑回人群里，挤到江枫旁边。那个女生举起相机，看了一眼取景框，然后皱了一下眉。"
    girl "你们……能不能站紧凑一点？现在拍出来中间会空一块。"
    "谢旻立刻往江枫那边挤，江枫抬手推他，两个人又闹起来。"
    girl "那个……左边的同学，你能不能稍微抬一下头？"
    "她说的是怀小柿。怀小柿的肩膀缩了一下，原本要避开镜头，最后却抬起了头。"
    girl "还有最右边那位，能不能往中间靠一点？你站在外面会拍不到。"
    "她说的是凌晨。凌晨看了她一眼，先站在原处，随后往前挪了半步。不多，刚好够进入画面。"
    girl "好，就这样。看镜头。"
    "你站在人群中间，忽然发现，自己不知道该看哪里。"
    "你拍过那么多人，指导过那么多人看镜头、调整姿势、放松表情。但轮到自己站在镜头前的时候，你才发现——看镜头，原来是一件这么难的事。"
    "你也想把视线移开。旁边有人碰了碰你的胳膊，是怀小柿。她没有看你，只抬着头看向镜头。"
    "你顺着她的视线抬起头。快门声落下，照片定格。那个女生看过预览，随后走过来把相机还给你。"
    girl "拍好了。你们人挺多的，不过都拍进去了。"
    "你接过相机，道了谢。她回到自己的座位，继续低头看手机。你低头看了一眼照片。"

    scene bg canteen_manypeople at bg_top
    "照片里，七个人站得不算整齐，光线也不算完美。江枫在笑。谢旻在闹。黎妤拽着黎陌尘的袖子。黎陌尘嘴角有一个很浅的弧度。凌晨站在最外侧，往前挪了半步。怀小柿站在你旁边，抬着头。而你站在他们中间，也在看镜头。"
    "你在里面。你忽然想起父亲说的那句话。"
    fq "“你以后会遇到很多人。能记住一个是一个。”"
    "你收起相机，朝他们走过去。江枫问你拍得怎么样，你说，挺好的。"
    "你没有说出口的是——这是你第一次，把自己也拍进了照片里。"
    

    # ————————————————————————————————————————第二章————————————————————————————————————————
    play music "music/黑胶慢绪.MP3" fadein 1.0

    scene bg black at bg_top
    "………………………………………………"

    scene bg playground at bg_top
    "两周军训正式开启。站军姿、齐步走、原地转向轮番压下来，汗水很快浸透迷彩服的衣领，塑胶跑道被太阳烤得发烫。"
    "每次休息哨响，大家便挤到树荫下补水喘气。"
    "怀小柿总是安安静静坐到你的身边，抱着膝盖，小口抿着水杯里的水，很少主动搭话，只是默默陪着你一起歇着。"
    "不远处，黎妤总要凑到黎陌尘身边，晃着马尾碎碎念训练时的抱怨；黎陌尘替她拧开水瓶，偶尔应一声。"
    
    ## 军训第三天·旗手
    "军训进行到第三天，上午的训练刚刚过半。教官大步走到方队正前方站定，目光缓缓扫过一整片迷彩的人海。"
    jg "我们方队要选一个人，负责军训汇演那天的出旗。有谁自告奋勇？"
    "队伍里一下子安静下来，只剩下风卷着旗帜猎猎作响的声响。大家彼此悄悄对视，没有人愿意站出来。出旗意味着汇演全场的目光都会集中在自己身上，压力不小。教官又高声问了一遍，依旧一片沉默。"
    "辅导员见状走上前，凑近教官耳边低声交谈了几句。教官听完点了点头，锐利的视线再次扫过队列。"
    jg "黎陌尘。"

    scene bg military_training_lm at bg_top
    "听见自己的名字，黎陌尘脚步慢了半拍，随后走到旗杆下。他双手握住沉重的金属旗杆，指节很快绷得泛白。你举起相机，又把手放下，想起报到那天牵绕攥紧拉杆的手。"
    "队伍里的江枫望向旗杆，眉头蹙起，手里的水瓶也被捏紧了一下。训练结束，黎陌尘才从旗杆边走回来，黎妤立刻迎了上去。"
    
    scene bg playground at bg_top
    ly "哥，你手没事吧？握那么重的旗杆，勒得疼不疼。"
    "黎陌尘的手指在瓶身上停了停，目光落到泛红的掌根。"
    lm "……没事。"
    ly "你别什么都自己硬扛着。"
    "黎陌尘轻轻应了一声。"
    lm "……嗯。"
    "黎妤没有再多唠叨，把那瓶还没拧开的矿泉水塞进他手里，转身跑回女生队伍。"
    "黎陌尘站在原地，拇指在瓶盖上摩挲了一下，最终把水收进外套口袋。"

    ## 中暑
    scene bg playground at bg_top
    "军训中场休息的时候，你在树荫下坐下来。"

    scene bg playground_hx at bg_top
    "怀小柿坐在你旁边，抱着膝盖看手机。蝉声贴着树荫响，她把屏幕递到你面前。"
    "屏幕上是一行字。"
    hx "……你觉得，一个人写的故事，会不会有人看？"
    menu:
        "认真回答她":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "会。只要故事是真的，就会有人看。"
            $ affection_change = ""
            "她把手机收回去，屏幕按灭，拇指在手机壳边缘蹭了两下。"
        "反问她":
            $ huaixiaoshi_affection += 3
            $ affection_change = "+3"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "你在写故事？"
            $ affection_change = ""
            "她抬头看了你一眼，又摇了摇头。"
            hx "……没有。随便问问。"
            "她把手机锁屏，塞进口袋。"
    $ renpy.block_rollback()

    scene bg playground at bg_top
    "军训过半，又一个正午，教官要求全员保持一小时军姿。塑胶跑道的热气贴着小腿往上涌，汗水顺着下颌落下。"
    "你还想咬牙撑住，视线却忽然失焦，耳边的口令被拉得很远。脚下发软，身体（liang qiang）着向前倒去。"

    scene bg black at bg_top
    hx "[player_name]！你怎么了？！"
    ly "她好像站不住了！快扶住她！"

    "一只有力的手臂及时揽住你的肩膀，稳稳托住快要栽倒的你，避免你重重摔在地面。混沌之间，你分辨出那是怀小柿的声音。"

    jf "我去叫校医！操场东边有医务站！"
    "眩晕彻底吞噬感知，周遭的人声、烈日、风的声响，全部一点点褪去，世界归于一片沉沉的黑暗。"

    ## 医务室
    scene bg clinic at bg_top
    "再次睁开眼，鼻尖萦绕淡淡的消毒水味道。你躺在医务室躺椅上，头顶吊扇缓慢转动。"
    "清瘦的女生站在一旁整理药品，看见你睁眼，转头看向你。"

    scene bg clinic_xl at bg_top
    xl "你醒了，低血糖加上中暑，已经补充糖水，不要急着起身。"

    player_name "谢谢你。没想到会在这里遇见你。"
    xl "你知道的，我身体一直不好，申请了免训，所以就在这里帮忙了。这几天我一直都在，你有需要可以找我。"
    "她说着，递过来一杯温水。杯壁上凝着细小的水珠，是凉的。"
    xl "你现在感觉怎么样？"
    
    menu:
        xl "你现在感觉怎么样？"
        "和小莱聊一会儿":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = xl_display_name
            show screen affection_change
            player_name "还好，就是有点累。高中就参加过军训，但大学这边强度还是超出我的预想。"
            $ affection_change = ""
            xl "没事啦，新生都要经历这一段，熬过去就好了。慢慢来，不用逼自己太紧。"
            "小莱拉过一把椅子，在你旁边坐下，手里整理着一叠纱布。她动作很轻，指尖偶尔微微发抖。吊扇转着，窗外传来模糊的口令声。"
            "你喝完水，把杯子放回桌上，肩背终于松下来。"
            player_name "你每天都在这里吗？"
            xl "嗯。早上八点到下午五点。晚上会有人接班。"
            player_name "不会无聊吗？"
            xl "不会。"
            "她想了想，声音轻轻的。"
            xl "能帮上别人的忙，挺好的。"

        "道谢后闭眼休息":
            $ player_affection += 3
            $ affection_change = "+3"
            $ affection_target = xl_display_name
            show screen affection_change
            player_name "辛苦你了，我先安静躺一会儿。"
            $ affection_change = ""
            xl "嗯，身体不舒服随时叫我。"
            "你闭上眼睛。吊扇在头顶转着，带起一阵阵凉风。你听见小莱放轻了脚步，走到柜子边，把什么东西整整齐齐地码好。"
    $ renpy.block_rollback()

    scene bg clinic_water at bg_top
    "休息片刻，体力恢复大半。你辞别小莱，准备返回训练场。你从躺椅上坐起来，低头穿鞋的时候，看到床边的矮柜上放着一瓶水。没拧开。瓶壁上还凝着一层薄薄的水雾。"
    "你伸手拿起它。就是食堂小卖部两块五一瓶的矿泉水，瓶壁水雾蹭得掌心发凉。小莱在旁边整理药品。"

    xl "哦，那个啊。刚才你还没醒的时候，有个女生来过。"
    "你转头看她。"
    player_name "女生？"

    "小莱把一盒药放进柜子里，动作很慢。"
    xl "嗯。长头发，黑发，左边编了一根小辫子。"
    "她想了想，又补了一句。"

    xl "她在这里站了一会儿，没叫我，也没叫醒你。就是把水放在这儿，然后就走了。"

    "你拧开瓶盖。水雾蹭了满手。你想起上午站军姿时左手边那个人，想起她抱膝坐在树荫下，也想起她拧瓶盖时几乎不出声。你喝了一口，没问。"
    
    scene bg clinic at bg_top
    "你走出医务室的时候，小莱叫住你。"

    xl "对了，你那个相机……"
    "你站住，回头看她。"
    xl "上次在食堂，我看到你放在桌边的那台相机了。很旧，但保养得很好。"

    xl "你的旧相机，别丢。用久了，它会记住你拍下的一切。"

    "你拇指摩挲着相机包的边缘。小莱继续整理药品，没有再追问。"

    ## 文艺汇演报名
    scene bg playground at bg_top
    "军训尾声，班级群发来文艺汇演报名通知。江枫和谢旻报名原创曲，黎妤报名独唱；怀小柿负责后台 PPT 与音视频播放，黎陌尘作为班长协调节目和设备，凌晨则负责搬音箱、谱架等道具。"
    "怀小柿蹲在后台角落检查素材，看到你举起相机，立刻侧身避开镜头。"

    ## 汇演前夜
    scene bg dorm_evening at bg_top
    "汇演前夜，黎妤背完歌词，忽然从床上坐起来。"
    ly "我紧张。你陪我聊会儿。"
    "你放下相机，坐到她床边。"
    ly "你说，我要是唱砸了怎么办？"
    player_name "你不会唱砸。"
    ly "万一呢？"
    player_name "那我帮你把视频删了。"
    "她的手指停在被角，随后笑了。"
    ly "你这个人，怎么安慰人都这么不正经。"
    menu:
        "黎妤坐在床边，紧张地等着你的回应："
        "再陪她聊一会儿":
            $ liyu_affection += 8
            $ affection_change = "+8"
            $ affection_target = ly_display_name
            show screen affection_change
            player_name "你唱砸了我帮你删视频。你唱好了我帮你拍照片。怎么都不亏。"
            $ affection_change = ""

            "她想了想，躺回床上。"
            ly "行吧。那我尽量唱好一点。"
            "她把被子拉到下巴，过了几秒又补了一句。"
            ly "……你拍照的时候，记得把我拍好看点。"
            player_name "嗯。"
            "她翻了个身，把被子拉到下巴。"
            ly "晚安。"
        "催她早点睡":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            player_name "早点睡，明天嗓子哑了更唱不好。"
            $ affection_change = ""
            ly "……你说得对。"
            "她躺下，把被子拉过头顶，声音闷闷地。"
            ly "那你明天记得拍我。"

    ## 汇演当天·后台
    scene bg behind_scenes at bg_top
    "汇演如期到来。在前一天，谢旻特意找到你，语气带着几分恳切，希望你可以作为临时摄影师，帮他们记录下汇演的现场画面，留下一份属于军训的纪念。你欣然答应下来。"
    "后台人来人往，道具磕碰声和低声交谈交织在一起。你挎着相机穿梭其间，记录下汇演前的花絮。"
    
    scene bg backstage_ly at bg_top
    "黎妤正对着化妆镜整理衣领与鬓角的碎发，嘴唇无声翕动，嘴里反复默念着歌词。念到一半脑子突然卡壳，她眉头微微皱起，慌忙掏出手机，对照屏幕上的歌词确认段落。"
    "你抓住这个瞬间抬起相机，正要按下快门，她敏锐察觉到镜头的存在，飞快抬眼望向你，俏皮地比出一个手势，示意你不要拍下自己的窘态。"
    
    scene bg backstage_jf at bg_top
    "不远处，江枫正低头调试吉他琴弦，指尖反复拨动试音。谢旻站在一旁，伸手稳稳扶住琴身，配合她调整。"
    jf "等会儿可别弹错。"
    xm "这话该我对你说，你别唱错就好。"

    scene bg backstage_lm at bg_top
    "幕布的阴影之下，黎陌尘静静立在那里，目光望向舞台方向。即使没有乐器在手，他的手指依旧在身侧无意识轻轻敲击，那是属于他的习惯，如同弹奏乐器之前的起手动作。"
    "你举起相机对准他。他敏锐感知到镜头，转过头望向你的方向。你没有放下相机，他也没有刻意躲闪，两个人就这样安静对视短短两秒。"
    "他摇了摇头，唇角松开一点。那点笑意很浅，像琴键按下后还没散尽的余音。"
    "你稳稳按下快门。"

    scene bg backstage_nervous_ly at bg_top
    "节目顺序向前推进，距离黎妤的独唱越来越近。后台角落里，怀小柿抱着膝盖检查 PPT，看到镜头便把身子藏到屏幕后；凌晨搬完音箱，从你身边侧过，让出拍摄的位置。"
    "她站在幕布的边缘，隔着一道布帘望向台下黑压压的观众席，双手攥紧又松开，一遍一遍做着深呼吸平复内心的忐忑。你举着相机捕捉下这个画面，她倏然转头看向站在一旁的你。"
    ly "我要是忘词了怎么办？"
    player_name "那就即兴。"
    ly "即兴？！我哪会即兴！"
    player_name "那你就像平时在宿舍唱那样，把它当成KTV。"

    "黎妤攥紧的手指松开，紧绷的神色慢慢放松，忍不住笑出声。"

    ly "KTV好啊，KTV我熟。"

    scene bg stage_ly at bg_top
    "她深吸一口气，迈步走上舞台。聚光灯骤然亮起，完整笼罩住她的身影。黎妤先是缓缓环视一圈台下，随后轻轻闭上双眼。前奏缓缓流淌响起，她开口唱出第一句，音色平稳安定，连后台忙碌的工作人员都不由得安静下来。"
    "你举着相机，透过取景框凝视台上的人。唱到副歌段落，明亮的灯光落在黎妤的脸庞，她依旧闭着眼，嘴角噙着真切的笑意，此刻的她褪去平日里跳脱贪玩的模样，满是对歌唱这件事的认真。"
    "你按下快门，定格下这动人的一幕。"

    scene bg backstage_jf_xm at bg_top
    "很快便轮到江枫与谢旻的节目。江枫将吉他递到谢旻手中。"
    jf  "别弹错。"
    xm "你别唱错。"
    "你再次举起相机。江枫把吉他交给谢旻，转身走向舞台中央，途中侧头望了一眼侧台。谢旻没有抬头，嘴角却悄悄上扬。你按下快门。"
    
    scene bg stage_jf at bg_top
    "聚光灯分别打向舞台中央与侧台。江枫站在舞台正中放声歌唱，谢旻坐在侧台进行伴奏。温柔绵长的旋律响起，歌词写满少年独有的滚烫热忱。偌大的场馆渐渐归于安静，所有人都沉浸在乐曲之中。"
    "一曲终了。雷鸣般的掌声轰然响起。你将镜头对准二人。"

    scene bg stage_jf_xm at bg_top
    "舞台上，江枫唱到最后一句；侧台的谢旻，手指还停在琴弦上。掌声响起，江枫侧头望向他，谢旻没有抬头，嘴角仍带着笑意。你没有拍全景，只把镜头对准他们之间那一小段距离，按下快门。"
    
    ## 汇演之后
    play music "music/黄昏海岸线.MP3" fadein 1.2

    scene bg behind_scenes at bg_top
    "喧闹的人群渐渐四散离场，演员、工作人员陆续收拾舞台道具，后台慢慢归于安静。你留在原地，坐在角落，一张张翻看相机里刚刚拍下的汇演花絮。"
    "舞台灯光残留的暖意还隐隐浮现在照片画面里，黎妤的投入、黎陌尘沉静的侧影，还有江枫与谢旻那一张定格住默契瞬间的照片，每一张都留存着今晚独有的温度。"
    "你正翻看相机里的照片，身后有人开口。"

    q "拍得怎么样？"
    scene bg behind_scenes_q at bg_top
    "你转头。牵绕站在后台入口，一只手插在裤袋里，歪头看你。"
    player_name "你怎么在这？"
    q "路过。"
    "他说完自己先笑了一下。路过路过跑到后台来，这个理由显然站不住脚。"
    q "给我看看。"
    "你把相机递给他。他翻了几张，停在一张江枫谢旻的舞台照上。"
    q "这张不错。"
    "他把相机还给你，转身准备离开。"
    "但他走了两步，又停下来。"
    q "……晚上烧烤，你去吗？"
    "他低头扫了一眼手机屏幕。"
    q "校门口那家。听说你们班今晚有人请客。"
    player_name "去。"
    q "哦。"
    "说完，牵绕便径直迈步，朝着后台出口走去。"

    scene bg behind_scenes at bg_top
    "后台大部分人已经走得差不多，四周渐渐安静。"
    "你站在原地，目送牵绕的背影彻底消失在后台出口。"
    "就在他脚步声彻底走远之后，储物书架的阴影里，飘来一声压抑的咳嗽。"
    "声音不算大，但在安静的后台格外清晰。那音色你很熟悉，是凌晨。"
    "看样子汇演结束之后，他并没有跟着大部队一起离开，独自待在那片灯光昏暗的储物区。"
    "你有些意外。刚才你和牵绕在后台入口说话的时候，那边一直没有任何动静。像是刻意等到牵绕走了，他才出声。"

    menu:
        "舞台照还停在相机屏幕上，你准备怎么做？"
        "循着咳嗽声，过去找凌晨聊聊":
            $ lingchen_affection += 3
            $ affection_change = "+3"
            $ affection_target = lc_display_name
            show screen affection_change
            scene bg behind_scenes_lc at bg_top
            "你没有立刻离开，起身，循着方才传来咳嗽的声响，从旁边另一排储物书架绕过去。后台的储物区灯光偏暗，凌晨正坐在书架边的桌前，笔记本电脑摆在桌面上。"
            $ affection_change = ""

            "你走近的时候，他没有合上电脑。屏幕就那样亮着——是那个他一直在维护的回忆网站，屏幕上铺着大量实拍旧照，很多取景，全都是陈婆婆家的老院子。"
            "看见这些熟悉的院落景象，记忆一下子被拽回遥远的童年。陈婆婆坐在屋檐下摇着蒲扇的模样浮现在你的脑海。随之冒出来埋藏心底的一个疑惑，那个常常被陈婆婆唤作乳名的邻家男孩。"
            "儿时很多面孔依旧朦胧，但这份疑惑在心底越来越清晰。"

            "你走近，在他桌边停下。"
            "凌晨没有合上电脑，也没有抬头。"
            "他偏过头，手背抵住嘴唇，又压着咳了两声。耳机线从桌沿垂落，轻轻晃了晃。"
            "等咳嗽平复下去，他才抬眼看你。手指停在触控板边缘，安静等着你先开口。"

            player_name "这个网站存了好多陈婆婆家院子的照片。"
            lc "这是我的老家。"
            player_name "我的老家也在桃溪村。看到这些照片，我心里一直有个疑问。"
            player_name "……你，是不是就是陈二牛？"

            "空气安静片刻。凌晨肩膀微微绷紧，目光避开你的眼睛，没有立刻答话。"
            lc "那是只有奶奶才会叫我的乳名。"
            lc "高考结束之后，我就改叫凌晨了。大学里，几乎没有人知道这个旧名字。"
            "算是确认了你的猜想。记忆里那个常常待在陈婆婆院子中的少年，轮廓慢慢和眼前的凌晨重合。"

            player_name "难怪看见你总觉得眼熟。"
            player_name "网站的旧相片里面，还经常出现另一个男孩子，名叫刘二狗。"
            player_name "我记得小时候，我们三个总是一起在陈婆婆院子里玩。"
            player_name "后来发生了什么？"

            "凌晨耳尖泛起一层淡淡的绯色。他把视线移向小道的尽头，伸手把散落在外的耳机线一圈一圈，慢慢缠绕收拢。"

            lc "你记得的那些，是你还在村里的时候。"
            lc "那时候我们三个确实天天混在一起。"
            "全部缠好之后，他才缓缓开口，语气克制，刻意回避关键现实对应关系。"
            lc "但真正的事，都是在你走之后。"
            lc "那段过往，你没有亲身经历。"
            lc "在这里，我不想谈论关于他的任何事。"

            player_name "等一下，可以麻烦你告诉我他现在在哪里吗？"

            "凌晨抿了抿唇，短暂的沉默过后，只吐出最客观、不带多余情绪的客观事实，不肯再多吐露半分私人恩怨。"
            lc "汴京大学，计算机系，大二。"

            "他仅仅给出了学校和院系，不肯透露这个人的名字，也不愿多说半句他们之间的过节。"
            "一团沉甸甸的疑云就此落在你的心底。你知道刘二狗就在这所校园里面，和你身处同一所大学，可你完全不知道他是谁、长什么模样。谜底被蒙上一层厚厚的雾。"
            "看得出来，无论你再怎么追问，他都不打算在嘈杂的汇演后台，撕开这道旧日的伤疤。"

            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            "你清楚继续纠缠也不会得到更多内情，便不再揪住这个沉重的话题不放。"
            $ affection_change = ""

            "临走之前，你想起刚才那几声咳嗽，回头看了他一眼。"
            player_name "你……是不是身体不太舒服？记得吃药。"
            "凌晨看了你两秒，没有解释，也没有否认。"
            "他垂下眼，把桌上的耳机收进电脑包侧袋，动作很慢。"
            lc "……嗯。"
            "你转身离开，动身前去赴晚上的烧烤聚餐。"

        "目送牵绕离开，直接动身赶去聚餐":
            $ qianrao_affection += 3
            $ affection_change = "+3"
            $ affection_target = q_display_name
            show screen affection_change
            "你站在原地，目送牵绕的背影彻底消失在后台出口。低头瞥了一眼相机，屏幕仍旧停留在刚刚那张江枫、谢旻的舞台合照。"
            $ affection_change = ""
            "储物区那边传来一声很轻的咳嗽。你朝那个方向看了一眼，灯光昏暗，看不清人。"
            "你犹豫了一下，还是没有过去。"
            "你把照片简单浏览完毕，收好相机，独自动身，赶往烧烤的集合地点。"
    $ renpy.block_rollback()

    scene bg black at bg_top
    "……………………………………………………"

    scene bg desk_turn_on at bg_top
    "回到宿舍之后，屋里只开着桌面一盏小台灯，光线柔和昏黄。你把相机连上电脑，将一整天拍下的全部素材导入硬盘。"
    "鼠标滑动，你回看江枫和谢旻的舞台照片。思索片刻，你把这张原图直接发给谢旻，没有附带文字。手机沉寂几分钟，屏幕弹出谢旻的回复。"
    xm "谢谢。"
    "第二条消息紧跟着弹出来，字句格外认真。"
    xm "这张照片，能不能别删。"
    player_name "好。"

    scene bg dorm_morning at bg_top
    "第二天清晨，你还没有完全睡醒，手机就接连震动起来。寝室七人群消息疯狂刷屏。你揉着眼睛点亮屏幕，是黎妤接连发来的好几条消息。"

    ly "你们看！"
    ly "江枫谢旻上学校官号了！"
    ly "评论好多人！有人说求完整版！"

    "你点开推送链接，是汴京大学官方公众号刚发出的汇演纪实推文，标题写着 ——《军训文艺汇演｜一首原创，惊艳全场》。"

    scene bg stage_jf_xm at bg_top
    "推文头图恰好就是你昨晚拍下的照片：江枫站在舞台中央，谢旻坐在侧台，二人隔着一段距离相望。推文末尾署名：摄影：[player_name]。"
    
    scene bg dorm_morning at bg_top
    "评论区已经热闹沸腾，一条条留言不停刷新，有人感慨 “这是什么神仙姐弟组合”，不少听众在底下追问歌曲名字，还有人夸赞侧台弹琴的谢旻气质出众。你向下划动聊天窗口，群里谢旻敲出一个字。"

    xm "靠。"
    jf "嗯。"
    "群聊短暂陷入几秒安静，紧接着黎妤又兴冲冲冒泡。"
    ly "你们火了！"
    hx "？"
    "凌晨全程没有发言。"
    lm "恭喜。"

    "你静静浏览着群内对话，没有打字参与讨论。江枫、谢旻二人，此后也没有再在群里继续说话。"

    scene bg dorm_afternoon at bg_top
    "到了下午，你正坐在书桌前整理今天新拍摄的相片，宿舍房门被人轻轻推开。江枫站在门框位置，并没有迈步走进房间，身子半留在门外。"

    scene bg dorm_door_frame_jf at bg_top
    jf "那张舞台的照片，是你拍的？"
    player_name "嗯。"
    "她的目光落在电脑屏幕，缩略图里还留着那张舞台照片。"
    jf "……拍得挺好的。"
    "话音落下，她便转身离开。"

    scene bg dorm_afternoon at bg_top
    "她转身离去时，唇角带着一点笑意，弧度和照片里谢旻嘴角的弧度出奇相像。"

    ## 烧烤
    scene bg dorm_evening at bg_top
    "夜幕缓缓笼罩校园，群聊再次弹出消息，是江枫发来的。"
    jf "今晚我请客。校外那家烧烤店，大家一起过来。"
    "谢旻几乎是秒回消息。"
    xm "终于轮到你请客了。"
    jf "呵。"

    scene bg teaching_building_dusk at bg_top
    "傍晚时分，七个人在校门口汇合，一同走向校外的烧烤店。晚风带走训练后的疲惫，路灯把一行人的影子拉得很长。"
    
    scene bg barbecue at bg_top
    "烧烤店门外支着木桌。大家把两张桌子拼在一起，围坐成一圈，炭火香气从烤炉里漫出来。"
    "江枫把菜单递给怀小柿。她的手指在菜单边缘停了停，最后只点了一串烤玉米。黎妤拿着菜单一口气勾选一大堆吃食。"
    xm "你点这么多，吃得完吗？"
    ly "吃不完的话，就交给你帮我消灭掉！"
    "黎陌尘把桌上散落的水杯一个个摆正。凌晨坐在最外侧，翻着菜单。你坐在人群中间，把相机收进椅子内侧。"
    
    scene bg clink at bg_top
    "江枫拿起面前的玻璃杯，轻轻抬高。"
    jf "来，我们碰一个。敬我们顺利熬过军训。"
    "七只玻璃杯彼此相碰，发出一串清脆的叮当响声。你举起杯子，挨个儿和在座的每一个人碰杯。"
    "炭火噼啪，油滴落下去，冒起一小股白烟。你坐下来，把相机收进椅子内侧，没有拿出来。"

    # ————————————————————————————————————————第三章————————————————————————————————————————
    play music "music/日常 轻快 悠闲 放松吉他.MP3" fadein 1.0

    scene bg black at bg_top
    "……………………………………"

    # 教学楼早晨
    scene bg teaching_building_morning at bg_top
    "军训落幕，校园回到日常。食堂窗口换了新甜品，课表偶尔空出一节，深夜群里也会跳出一句“还有人没睡吗”。"
    "江枫和谢旻运营起“枫与旻”，首条内容用了你拍的舞台照，配上原创曲片段，并在文案里备注了摄影师。"
    "关注者很快涨起来。你把几条留言截图存进相册，却没有回复，只把照片继续分门别类存进硬盘。"
    "加了微信之后，牵绕从来没有主动给你发过消息。但你每次发朋友圈，他都是第一个点赞的。"
    "你发新照片，他点赞。你发食堂的菜，他点赞。你深夜发一句‘好累’，他没有点赞。第二天早上，你收到他发来的一条消息。"
    q "昨天那么晚还不睡。"
    "你把手机扣在桌上，屏幕暗下去。第二天早上，那条消息还在对话框最上面。"

    scene bg desk_turn_off at bg_top
    "某天晚上，宿舍只剩键盘细碎的敲击声。怀小柿坐在床上写东西，手机屏幕的光映在她脸上。你抬眼时，她的手指正停在屏幕上。察觉到你的视线，她立刻把手机扣下。"

    scene bg dorm_desk_books at bg_top
    "你没有问。但第二天，你发现她书桌上多了一本速写本。封面是桃溪村的风景。"
    "你走过去看了一眼，没有翻。"
    "你记得那天晚上她把手机扣下时的动作。那不是慌张，是习惯。"
    "你正准备走开。身后传来脚步声。"

    scene bg dorm_door_hx at bg_top
    "怀小柿从外面回来，看到你站在她桌前。她的脚步慢了半拍。"
    "她看了一眼桌上的速写本，又看了看你。"
    "你退后一步，给她让出位置。"
    "她没有走过去。"
    "她站在原地，手攥着帆布包的带子。过了两秒，她松开带子，走到桌前，把速写本拿起来。"

    scene bg hand_notebook_hx at bg_top
    "然后她把速写本递向你。"

    hx "……你想看吗？"
    "她的声音很轻，眼睛没有看你，落在速写本的封面上。"

    menu:
        "怀小柿主动把速写本递过来。"
        "接过来，翻开":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            "你接过速写本。她的手指在封面上停了一下，然后松开。"
            $ affection_change = ""

            "你翻开。"
            scene bg line_art_hx at bg_top
            "里面是手绘的桃溪村地图，每一处都标了小字。老槐树、陈婆婆的院子、村东的小河、田埂上的石桥。你的手指停在老槐树的位置。那棵树，你也记得。"
            "你继续往后翻。"
            "画不多，每张都只勾了轮廓，没有上色。但每一张的角落都写着一行小字。"
            "“怕忘记，所以画下来。”"

            scene bg dorm_door_hx at bg_top
            "你把速写本合上，还给她。"
            player_name "画得很好。"

            scene bg hold_note_hx at bg_top
            "她接过速写本，抱在胸前。视线落在封面那棵老槐树上。她没有说谢谢。但她把速写本放回桌上时，是正面朝上放的。"
        "摇摇头，说等她想给你看的时候再看":
            $ huaixiaoshi_affection += 3
            $ affection_change = "+3"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "……不用。等你想给我看的时候再说。"
            $ affection_change = ""

            "她愣了一下。手还举在半空，拿着速写本。"
            "过了一会儿，她把速写本收回去，放回桌上。"
            hx "……嗯。"
            scene bg sit_down_hx at bg_top
            "她坐下来，翻开速写本，拿起笔。"
            "但她没有画。她只是用笔尖在纸的角落点了一下，又点了一下。"
            "你回到自己的桌前坐下。过了一会儿，你听到后面传来很轻的翻页声。"
            "然后是很轻的落笔声。"
    $ renpy.block_rollback()

    scene bg dorm_morning at bg_top
    "课表空出一页，你准备把时间交给谁？"

    menu:
        "去琴房找黎陌尘":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg piano_room_morning at bg_top
            "你走到琴房门口。门虚掩着，里面传出钢琴声。"
            $ affection_change = ""

            scene bg piano_room_morning_lm at bg_top
            "你推门进去。黎陌尘坐在琴凳上，看到你，没有停。你坐在旁边的椅子上，听他弹完一整首曲子。"
            "弹完之后，他转头看你。"
            lm "……你怎么来了？"
            player_name "路过。"
            "他看了你几秒，指尖在琴键边缘停住。"
            lm "那再听一首。"
            "他把谱纸翻到新的一页，没有写字，只在纸上画了一道小节线，随后重新把手放到琴键上。"
        "和黎妤去湖边写生":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change

            scene bg lakeside at bg_top
            "你陪黎妤去湖边写生。她画画，你拍照。"
            $ affection_change = ""
            
            scene bg lakeside_ly at bg_top
            "她画到一半，忽然把速写本转过来给你看。"
            ly "你看，像不像你？"
            "画的是一个举着相机的人。侧脸。"
            player_name "……你怎么知道是我？"
            ly "因为只有你拍照的时候会歪头。"
            "她说完自己先笑了，马尾在肩后晃了一下。画完后，她没再让你看第二眼，直接把速写本合上。"
        "陪怀小柿去图书馆":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            scene bg library_hx at bg_top
            "你陪怀小柿去图书馆。她找了个角落坐下，开始写东西。"
            $ affection_change = ""

            "你坐在她对面，翻自己的书。"
            "她写了一阵，把手机推过来。"
            "屏幕上是一行字。"
            hx "……你别坐这么近，我写不出来。"
            "你把椅子往后挪了挪。"
            "她又把手机推过来，随后把椅子朝你这边挪了半寸。"
            hx "……也不用那么远。"
        "和牵绕出去拍照":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg shaded_path at bg_top
            "你和牵绕约好出去拍照。他带你走了一条你没走过的小路。路上没什么人，两边都是树。"
            $ affection_change = ""

            scene bg shaded_path_q at bg_top
            q "这里光线好。"
            "他站在树荫下，随意摆了个姿势。"
            player_name "你倒是很熟练。"
            q "被你拍多了，自然就熟练了。"
            "他说完，把相机拿过去，反过来按下一次快门。"
            "你看向预览，发现照片里的自己也正歪着头。牵绕已经把相机还回来，偏头看向树影。"
    $ renpy.block_rollback()

    scene bg dorm_morning at bg_top
    "军训结束不久后，江枫和谢旻二人正式发布完整原创歌曲《旗手》。"
    "你正坐在宿舍书桌前整理素材，听见歌名时，手上的动作停住。舒缓克制的旋律流淌出来，军训第三天黎陌尘握住旗杆、指节泛白的画面随之浮上来。"
    "你把歌加入歌单，却没有告诉他；琴房窗户的照片也被移进新文件夹，文件夹名是“旗手”。"

    # ————————————————————————————————————————————————
    # 黎陌尘线·日常偶遇：长椅上的黎陌尘
    # 无条件触发，给玩家一个更生活化的互动
    # 建议加值 +8 / +6 / +3
    # ————————————————————————————————————————————————
    scene bg shaded_path at bg_top
    "某天傍晚，你从图书馆回来，走了一条平时不常走的小路。"
    "路两边种着梧桐，叶子已经开始发黄。走到一半，你看见路边长椅上坐着一个人。"

    scene bg shaded_path_lm at bg_top
    "是黎陌尘。"

    "他面前没有琴，也没有谱纸。他手里拿着一本书，但没有翻开。他只是坐在那里，看着路对面的树。"
    "你本来想直接走过去。但他抬起头，看到了你。"

    lm "……你也走这条路？"
    player_name "嗯，从图书馆回来。"
    "他点了点头，没有再多问。"
    "你在长椅旁边站了一会儿。他也没有赶你走。"

    menu:
        "你准备怎么回应？"
        "坐下来，陪他坐一会儿":
            $ limichen_affection += 8
            $ affection_change = "+8"
            $ affection_target = lm_display_name
            show screen affection_change
            "你在长椅另一端坐下。"
            $ affection_change = ""

            "他没有说话。你也没有说话。"
            "两个人坐在那里，看着路对面的梧桐叶一片一片落下来。"

            scene bg shaded_path_come_back_lm at bg_top
            "过了一会儿，他忽然开口。"
            lm "黎妤小时候，也喜欢走这种路。"
            lm "她说这种路安静，适合想事情。"
            player_name "你也这么觉得？"
            lm "……我不太会想事情。"
            "他把手里的书合上，放在膝盖上。"
            lm "我只是喜欢坐在这里。"
            "他没有再解释。你也没有追问。"

            scene bg shaded_path_night at bg_top
            "天色慢慢暗下来。他站起来，把书收进包里。"
            lm "……我先回去了。"
            "他朝你点了点头，转身走了。"
            "你坐在长椅上，又看了一会儿落叶。"

        "问他手里拿的是什么书":
            $ limichen_affection += 6
            $ affection_change = "+6"
            $ affection_target = lm_display_name
            show screen affection_change
            player_name "你手里拿的是什么书？"
            $ affection_change = ""

            scene bg shaded_path_come_back_lm at bg_top
            "黎陌尘低头看了一眼，把书翻过来给你看。"
            "封面是一本很旧的诗集。书名已经磨得看不清了。"
            lm "随便看看。"
            player_name "你喜欢诗？"
            lm "……不算喜欢。"
            "他把书合上。"
            lm "只是有几首，看的时候会觉得……很安静。"
            "他说完这句，似乎觉得自己说得太多，便没有继续。"
            "你也没有追问。"
            "他站起来，把书收进包里，朝你点了点头。"
            lm "我先回去了。"

        "打个招呼就离开":
            $ limichen_affection += 3
            $ affection_change = "+3"
            $ affection_target = lm_display_name
            show screen affection_change
            player_name "那我先走了。"
            $ affection_change = ""

            "他点了点头。"
            "你从他身边走过去。走了几步，你回头看了一眼。"
            "他还坐在那里，看着路对面的树。"
            "手里的书，始终没有翻开。"
    $ renpy.block_rollback()
    
    scene bg black at bg_top
    "……………………………………"

    scene bg dorm_afternoon at bg_top
    "某个下午，你外出结束回到宿舍。黎妤正伏在书桌前埋头作画，桌面上摊开一幅还没有完全干透的插画。"

    scene bg painting_ly at bg_top
    "画面之中，少女站在幽深昏暗的环境里，双手高高举着一盏灯。暖融融的光亮映亮她的脸庞，也驱散周遭一小片黑暗，远方依旧沉在沉沉夜色，女孩迈步向着前路走去。"
    
    player_name "这幅画打算叫什么名字？"
    ly "还没想好，或许可以叫《灯》吧。"
    player_name "很好看。"
    ly "真的吗？"
    player_name "真的。"
    
    scene bg turnaround_ly at bg_top
    "黎妤盯着画布凝望片刻，忽然开口，语气里带着一丝自己都没有预料到的冲动。"
    ly "我想把它发到网上。"

    "话音落下，她的指尖在画纸边缘停住，像是直到说出口才确认这个念头。"
    ly "……会不会有点幼稚？就是把作品公开到网上这件事。"
    player_name "不会。你画了这么多年，本就该让更多人看见。"

    "她用指尖叩了叩画纸边缘，随后把手机递给你。"
    ly "那我就发出去啦。你帮我选封面，你的镜头拍出来效果最好。"
    "你选了灯光最亮的那一版，替她拍下画作。黎妤确认照片后，把它上传到自己的社交账号。"

    scene bg teaching_building_dusk at bg_top
    "某天傍晚，你路过教学楼，想起二楼那个亮灯的琴房。你走上去看了一眼。琴房门虚掩着，里面有人在弹琴。"
    
    scene bg piano_room_evening_lm at bg_top
    "是黎陌尘。你没有进去，只站在门口听完整段旋律。他弹的是那首写了三年的曲子。弹到一半，他停下来，重新开始。"
    "你举起相机，隔着门缝拍下他的侧影。"
    menu:
        "琴声停在门后，你准备："
        "推门进去":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            "你推开门。琴声停了。他没有立刻回头，手指还停在琴键上。"
            $ affection_change = ""

            scene bg piano_room_evening_cone_back_lm at bg_top
            "过了两秒，他才侧过脸看你。"
            player_name "我路过，听到琴声。"
            "他看了你一会儿，像是在确认你为什么会站在这里。然后他朝钢琴旁边那把空椅子抬了抬下巴。"
            lm "坐吧。"
            "你走过去，拉开椅子坐下。他把琴凳往旁边挪了一点，给你腾出更多空间。他重新把手放回琴键上，弹了一遍。这次没有停。"
        "放下相机，悄悄离开":
            $ limichen_affection += 3
            $ affection_change = "+3"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg stairs_evening at bg_top
            "你放下相机，转身离开。琴声在你身后继续，走到楼梯口时，它停了。你没有回头。"
            $ affection_change = ""
    $ renpy.block_rollback()

    scene bg teaching_building_corridor_ly at bg_top
    "你从琴房出来的时候，正好在走廊上碰到黎妤。她怀里抱着一摞画纸，看到你从琴房方向走出来，眼睛亮了一下。"
    ly "欸，你从琴房出来的？我哥还在里面吗？"
    player_name "嗯，刚弹完琴。"
    ly "我正好要去找他，让他帮我看看这幅画。"
    "她举了举怀里的画纸。"
    ly "……不过，你要是有空的话，也可以陪我去湖边写生。"
    "她看了看琴房的方向，又看了看你。"
    menu:
        "陪黎妤回去找黎陌尘":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            "你摇了摇头，说自己想再回去听一会儿琴。"
            $ affection_change = ""
            "黎妤看了你一眼，笑了笑。"
            ly "行吧。那我先不打扰你们。"

            scene bg piano_room_evening at bg_top
            "她抱着画纸走进琴房，顺手把门带上。你跟在后面。"

            scene bg piano_room_evening_cone_back_lm at bg_top
            "黎陌尘抬头看到你回来，手指在琴键上停了一下。"
            lm "你怎么又回来了？"
            lm "……落下东西了？"
        "陪黎妤去湖边":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            player_name "我陪你去湖边吧。"
            $ affection_change = ""

            "黎妤眼睛亮了起来。"
            ly "真的？那走走走！"
            "她拉着你的袖子往外走。路过琴房门口的时候，她朝里面喊了一声。"
            ly "哥！我先去湖边了！"
            "琴房里传来一声淡淡的“嗯”。"
    $ renpy.block_rollback()

    scene bg dorm_afternoon at bg_top
    "隔日，你上完课从教学楼回到寝室，看见黎妤一动不动举着手机坐在书桌前。察觉到你的靠近，她没有抬头，直接把手机递到你的手上。"
    "屏幕上是一条私信，来自一位业内成熟的独立插画师，向她发出了绘本项目的合作邀约。"
    
    scene bg phone_ly at bg_top
    ly "……你说，我要不要回复她？"
    player_name "你内心想答应吗？"
    ly "想，可我又害怕自己做不好。"

    player_name "你完全可以做到，多给自己一点信心。"

    "黎妤望了你几秒，敲下屏幕，只回复了一个字：“好。”"
    "发送完毕，她把手机扣在桌面，整个人埋进胳膊里。"
    ly "我回消息了……天呐，我好紧张。"
    "你把滚到桌边、快要跌落的画笔推回桌面中央。"

    scene bg desk_turn_on at bg_top
    "夜幕降临，江枫在桌前修改谱子，黎妤翻着画册，怀小柿抱膝坐在床上。你翻阅手机时，一篇短篇小说《桃溪村的夏天》闯入视线。"
    "点开阅读，文笔干净柔和。故事讲述女孩在乡村长大的过往：盛夏聒噪的蝉鸣、院子里老旧的竹椅、奶奶熬好的绿豆汤、傍晚漫天铺展的晚霞。"
    "读到文末，看见作者写下的后记：“这个故事写给我奶奶。也写给所有在乡下长大的人。”"
    "你退出页面，看了一眼作者 ID，“柿柿如意”。"
    "你把手机放下。屏幕暗下去。"
    "你转头看了一眼怀小柿的方向。她坐在床上，抱着膝盖，手机屏幕的光映在她脸上。她没有在打字。她只是看着屏幕。"
    "你收回视线。什么都没有说。"

    scene bg desk_turn_off at bg_top
    "深夜。宿舍里其他人都睡了。你醒着，听到上铺传来很轻的敲击声。"

    scene bg dorm_one_hx at bg_top
    "你抬头看了一眼。怀小柿坐在床上，抱着膝盖，手机屏幕的光映在她脸上。她在打字。"
    "她打完一段，停下来。手指悬在屏幕上方，没有落下去。"
    "她转过头，看向你的方向。你没有闭眼。她也没有移开视线。"
    "两个人在昏暗里对看了一眼。"
    "然后她开口了。声音压得很低，怕吵到别人。"

    hx "……你还没睡？"
    player_name "嗯。"
    hx "……我吵到你了？"
    player_name "没有。"

    "她沉默了几秒。手指在手机壳边缘蹭了两下。"
    "然后她把手机翻过来，屏幕朝下，放在枕头上。"
    "她低下头。过了一会儿，又抬起来。"

    hx "……你想看吗？"
    player_name "什么？"
    hx "我在写的。"

    "她没有等你回答。她把手机从枕头上拿起来，解锁，点开一个文档。然后她探身下来，把手机递给你。"
    "屏幕上的字很小。是一段小说。写的是桃溪村的夏天。"
    "你读完了。把手机还给她。"

    menu:
        "怀小柿把手机递下来，你准备："
        "认真读完，告诉她感受":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "很好看。"
            $ affection_change = ""

            scene bg dorm_two_hx at bg_top
            "她接过手机，把被子往上拉了拉，遮住半张脸。"
            hx "……哪里好？"
            player_name "她一个人坐在田埂上，看着别人在树下玩。这段写得很好。"
            "她把被子往上拉了一点，把眼睛也遮住了。"
            hx "……那是我。"
            "她说得很小声。你没有听清，但你点了点头。"
            "她没再说话。敲击声停了。"
            "但过了一会儿，她又开始打字。这次比刚才轻。"
        "只看了一眼，还给她":
            $ huaixiaoshi_affection += 3
            $ affection_change = "+3"
            $ affection_target = hx_display_name
            show screen affection_change
            "你看了几行，把手机还给她。"
            $ affection_change = ""

            player_name "写得挺好的。"
            scene bg dorm_three_hx at bg_top
            "她接过手机。没有看你的表情。"
            hx "……嗯。"
            "她把手机收回去，屏幕暗下去。"
            "上铺安静了很久。然后敲击声重新响起来。这次比刚才更轻，更慢。"
            "你闭上眼睛。"
    $ renpy.block_rollback()

    scene bg dorm_morning at bg_top
    "第二天早上，宿舍里只有你和怀小柿。她在系鞋带，你在收拾书包。"

    scene bg tieshoelaces_hx at bg_top
    "她系了很久。比平时慢。"
    "你把书包拉链拉上，正准备走。她忽然开口。"
    hx "……你昨天看的那篇小说。"

    "她的声音很轻，像是从嗓子底下挤出来的。"

    hx "你觉得怎么样？"
    "你停下来。"
    player_name "很好看。"

    "她低头看着鞋带。系好的结扣，她又解开，重新系了一遍。"

    hx "……后面还有。"
    hx "你看吗？"

    "她抬起头看你。眼睛很快垂下去。但她的手指没有停，她把手机从口袋里掏出来，屏幕上已经打开了小说的页面。"
    "她没有递给你。她只是放在床沿上，朝你的方向推了推。"

    menu:
        "怀小柿把手机放在床沿上，你准备："
        "拿起来，继续往下看":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            "你走过去，把手机拿起来。"
            $ affection_change = ""

            scene bg sit_down_two_hx at bg_top
            "她往旁边挪了挪，给你让出一块床沿的位置。"
            "你坐下来，翻到最新一章。她在旁边，安安静静地坐着，没有看你的屏幕。"
            "你读完之后，把手机还给她。"
            player_name "写得很好。"
            hx "……哪里好？"
            player_name "她不知道往哪走，但没有回头。这句写得很好。"
            "她把手机收回去，锁屏，放在枕头旁边。"
            "她没有再说话。但你注意到，她系好的鞋带，这一次没有解开。"
        "摇摇头，等她愿意主动给你看":
            $ huaixiaoshi_affection += 3
            $ affection_change = "+3"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "等你想给我看的时候，我再拿。"
            $ affection_change = ""

            "她愣了一下。手指停在手机边缘。"
            "过了一会儿，她把手机收回去，锁屏，放进口袋。"
            hx "……嗯。"

            scene bg leave_dorm_hx at bg_top
            "她站起来，把书包背上。"
            "走到门口的时候，她停下来，没有回头。"
            hx "……后面那几章，写的是学校的事。"
            hx "你会想看的。"
            "她说完，推开门走了。"
    $ renpy.block_rollback()

    scene bg black at bg_top
    "……………………………………"
    "又过了一段时间。"
    
    scene bg library_front_morning at bg_top
    "某天下午，你前往图书馆归还书籍。"
    scene bg library_lm at bg_top
    "你在书架间找书的时候，看到了黎陌尘。他蹲在书架前，翻着一本很厚的乐理书。他似乎没注意到你。"
    menu:
        "走过去打招呼":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg library_rise_lm at bg_top
            "你走过去。他抬起头，看到你，微微一愣。"
            $ affection_change = ""

            lm "……你也来借书？"
            player_name "嗯，随便看看。"
            "他把手里的乐理书合上，放回书架。"
            lm "这本太厚了。我看了三天还没看完。"
            player_name "你三天看一本乐理书？"
            lm "……不是全部。只看了一半。"
            "他说这句话的时候，语气很平，但你听出来他有一点不好意思。你忍不住笑了一下。"
        "从另一排书架绕开":
            $ limichen_affection += 3
            $ affection_change = "+3"
            $ affection_target = lm_display_name
            show screen affection_change
            "你绕开他，从另一排书架走过去。你回头看了一眼。他还蹲在那里，没有动。"
            $ affection_change = ""
    $ renpy.block_rollback()

    scene bg library_lc at bg_top
    "你离开书架区域，走向靠窗那一排座位。"
    "凌晨坐在桌前，笔记本电脑摊开，屏幕是一个极简的网页界面，耳朵戴着耳机，手指悬停在键盘上方，迟迟没有落下。"
    "你本来打算径直走过去，他却忽然抬起头看见了你，也没有刻意遮挡屏幕。"

    lc "你要看看吗？"
    "你愣了愣，轻轻点头。"
    "他转动笔记本电脑，把屏幕朝向你。页面中央是一张老旧照片：老旧的农家院落，院内生长着一棵巨大的老树，树下安放一把竹椅。"

    player_name "这棵树，我认得。"

    "凌晨的手指在触控板边缘停了一下。"
    player_name "小时候，夏天热得睡不着，陈婆婆就在这棵树下铺草席。她摇蒲扇，我们几个小孩躺在席子上数星星。"
    "你顿了顿，回忆起更多细节。"
    player_name "你总爱讲鬼故事，讲到一半自己先害怕。二狗每次都嫌你讲得烂，但每次都听得最认真。"
    "凌晨只是安静地听着，手指从触控板上慢慢收回去，放在膝盖上。"
    lc "……你还记得这些。"
    player_name "记得。我搬走之后，总是想起这些。"
    "他垂下眼，沉默了几秒。"
    lc "你走的那年，二狗在树下坐了整整一个下午。奶奶叫他吃饭，他也没动。"
    "你心里一紧。"
    player_name "后来呢？"
    lc "后来他也走了。"
    "凌晨的语气很平，像在念一段已经翻过去很久的旧笔记。"
    lc "他家里出了事，搬得很急。走之前没跟任何人说，也没来跟我道别。"
    "他伸手把耳机收起来，一圈一圈缠好。"
    lc "再后来，我们见过一次。但那时候，已经跟小时候不一样了。"
    player_name "你们……闹翻了？"
    "凌晨没有立刻回答。他把缠好的耳机线放进电脑包侧袋，动作很慢。"
    lc "不算闹翻。只是有些东西，错过了就是错过了。"
    "他抬起头看你，眼神比平时多了一点温度，但那份温度很快又收了回去。"
    lc "你现在看到的这个网站，有一部分就是为他建的。但他大概永远不会来看。"
    player_name "他知道这个网站吗？"
    lc "不知道。"
    "他把电脑屏幕轻轻转回去，页面还停在那棵老槐树的照片上。"
    lc "我也不打算告诉他。"
    "你想起后台那晚，他说的那句话——“以前的事，我不太想提”。此刻你终于明白，那句不想提里，藏着的不只是怨，还有一段没能好好告别的童年。"
    player_name "那他现在……真的在计算机系？"
    "凌晨看了你一眼。他听懂了你在问什么。"

    lc "我看起来这么不可信吗？"

    "他把网页最小化，重新打开一份代码文档，手指落回键盘上。"
    lc "不过他的名字我不会替他说的，别对他抱太高期待，他很会藏。"
    "你站在桌边，看着屏幕上那棵被最小化又恢复的老槐树。你忽然觉得，刘二狗这个人，可能比你想的更难找。"
    "你没有再追问。轻声和凌晨道别后，你转身离开。"

    scene bg black at bg_top
    "……………………………………"
    "又往后的一段时日。"

    # ————————————————————————————————————————————————————————————————————————
    play music "music/蜉蝣晶体.MP3" fadein 1.0

    scene bg dorm_afternoon at bg_top
    "自从开学那天你帮牵绕拍下那张照片，他总能够找出各式各样的理由邀约你外出拍照。你好几次，都以课业繁重为由婉拒。"
    "这段时间，你攒下生活费，购置了一台全新的相机，还把新机的照片发布在了朋友圈。不出意料，这条动态被牵绕看见。"
    "此刻，你便带着这台崭新的相机，坐在网球场的观众席上。他告诉你自己有网球比赛，就这样把你喊过来充当临时摄影师。"
    
    scene bg tennis_q at bg_top
    "你望向球场，盯住他奔跑的身影，举起相机按下快门。他跑动姿态利落，挥拍瞬间手臂线条绷紧，细密的汗水顺着下颌滑落，在阳光底下一闪而过。"
    "按下快门的那一瞬，你回想起报到那天给他拍下的旧照片。彼时他攥着行李箱拉杆，指节用力泛白；此刻手握球拍，指节同样绷得很紧。"
    "你放下相机静静观望。"

    scene bg tennis_over_q at bg_top
    "比赛落幕，牵绕拿下胜利。他走到观众席边上，拿过毛巾擦拭脸上的汗水。"

    q "拍到了吗？"
    player_name "拍到了。"
    q "拿来我瞧瞧。"

    scene bg look_photos_q at bg_top
    "你把相机递过去。他低头翻阅照片，手指在屏幕轻轻滑动，停留在其中一张。照片定格他击球腾空的瞬间，球拍挥至最高点，侧方阳光完整勾勒出他的轮廓。"

    q "是这一张。"
    player_name "怎么了？"
    q "没什么。"

    "他把相机交还给你，屏幕还亮着那张照片，没有再多评价。"

    scene bg playground_stand_evening at bg_top
    "球场上的人群渐渐散去，天色沉下来，路灯一盏盏亮起。你们并肩坐在看台，晚风掠过空荡的座椅。你记起凌晨跟你说过，刘二狗就在本校大二计算机系，心里萌生打听消息的念头。"

    player_name "牵绕，我想向你打听一个人。"

    scene bg turn_head_side_q at bg_top
    "他侧过头，唇角噙着一抹似有若无的浅笑，指尖漫不经心地摩挲着毛巾边缘，神态故作如常。"

    q "是谁？"
    player_name "大家叫他刘二狗，当然本名或许不是这个。小时候住在桃溪村，和你同届，读计算机系。我手上就只有这么一点线索。"
    
    "听到这个称呼，他眼尾跳了一下，仍旧耸着肩装出为难的样子。"
    q "连准确名字都不能确定，就跑来找人？这么大一所学校，找起来可不容易。"
    player_name "我明白，本来也没有抱太大希望，不用特意帮我去找，谢谢你啦。"

    scene bg playground_new_camera at bg_top
    "他没有顺着这个话题继续，视线落到你手边的相机。"

    q "你的这台新相机，花了不少钱？"
    player_name "攒了两个月的生活费。"
    q "想来价格不低。"
    player_name "还好。"

    "他把目光移开，指尖在膝盖上敲了两下，像被某段回忆碰了一下。"
    q "我从前也动过念头想学摄影。"
    player_name "那为什么最后没有去学？"
    q "没有多余的时间。"
    player_name "现在呢？"
    q "现在也没有。"

    "他说完，把毛巾搭到头上，挡住眼睛。你将相机收回包里，站起身。"
    player_name "天黑了，我们回去吧。"

    "他应声起身，二人一同离开网球场。"

    scene bg dorm_downstairs_evening at bg_top
    "走到岔路口，他停下脚步，目光落在你手边的相机上。"

    scene bg intersection_q at bg_top
    q "你那个新相机，买了不用也是浪费。"
    player_name "所以？"
    q "……所以有空帮我拍几张。"
    "他说完就走了，没有等你回答。但第二天，他发来了网球场的时间和地点。"

    scene bg desk_turn_on at bg_top
    "你回到宿舍，把相机里的照片导进硬盘：琴房侧影、湖边写生、老槐树，以及香樟树下的牵绕。你把它们放在同一个文件夹里，没有命名。"
    "窗外天黑得很慢。你合上相机，放在桌角，备用电池还在外套口袋里。"

    
    # ————————————————————————————————————————第四章————————————————————————————————————————
    play music "music/慵懒 穿搭分享.MP3" fadein 1.0

    scene bg teaching_building_morning at bg_top
    "军训结束后的日子过得很快。课表填满，作业堆起来，银杏叶从绿转黄。"
    "等你反应过来的时候，十月已经过了一半。你走去教学楼时，发现军训晒黑的手臂已经白回来一点。"
    "期中临近，专业课作业堆在桌角，班级群里的统计表一张接一张。军训的喧闹退到身后，校园重新被课表和琐事填满。"
    
    "下午最后一堂课结束，你整理相机配件时换下电池，顺手把备用电池放进课桌抽屉。桌椅声和同学的交谈盖过了这件小事。"
    "傍晚回到宿舍，你拉开背包才发现电池不在。眼看天色已经完全暗下来，宿舍楼与教学楼之间的路上，路灯次第亮起。"
    
    scene bg teaching_building_corridor_evening at bg_top
    "你怕电池放在教室过夜会弄丢，便拿上手机，独自折返教学楼。白日里熙攘的教学楼入夜后只亮着一半顶灯。暖黄的光铺在地板上，你的脚步声沿空旷长廊传开。"
    "你推开白天上课的教室门，屋内空荡荡的。借着走廊透进来的微光，走到自己白天坐过的位置，拉开抽屉，顺利摸到那枚备用电池。把电池揣进外套口袋，你转身打算就此离开。"
    "一缕钢琴旋律从走廊尽头传来，调子偏沉，尾音贴着墙面回荡。你的脚步在原地停住，随后循着琴声往前走。"
    
    scene bg piano_room_evening_lm at bg_top
    "练习室的门虚掩着，门缝里漏出一线暖光。射灯照在黑色钢琴上，漆面反着光，像一小块安静的湖。黎陌尘独自坐在琴凳上。"
    "他腰背挺直，全部注意力落在黑白琴键上。你隔着门缝听完整首曲子，没有发出声响。最后一个音符将要散尽，你的脚跟刚往后挪，琴声便停了。"

    lm "站在外面的人，不用躲了。"
    "黎陌尘的声音平静响起，音量不高，却清清楚楚穿透门板。原来从你的脚步声靠近长廊，他就已经察觉到门外有人。"
    "你身体微微一僵，索性伸手推开那道虚掩的房门。"

    player_name "不好意思，我回教室拿落下的东西，路过听见琴声，并不是有意偷听。"

    scene bg piano_room_evening_cone_back_lm at bg_top
    "黎陌尘侧过头望向门口，脸上看不出半分被打扰的不悦，只是朝钢琴旁边那把空置的椅子，微微抬了抬下巴。"
    lm "没关系，进来坐一会吧。"

    "你走进去，在钢琴侧边的椅子坐下。黎陌尘把琴凳往旁边挪了一点，给你让出位置。房间大半沉在阴影里，只有射灯照亮琴键和他的侧脸。"
    
    "他没有再多多余寒暄，指尖重新落回琴键，直接弹奏起另一首曲子。这是一首还没有对外公开的原创作品，旋律柔软，内里却裹挟着复杂酸涩的情绪。"
    "一曲演奏完毕，他的手指仍停在琴键上，等最后一个音散干净，才转头看向你。"

    scene bg piano_room_evening at bg_top
    lm "这是我最近写的，随便弹弹。你听完，有什么感受可以直说。"
    player_name "很好听，曲子里面情绪很饱满，能听得出来投入了很多心思。"
    "你发自内心给出评价。你看着琴键，想起黎妤提过家里摆满奖杯。"
    player_name "你以前……经常上台吧？"

    "黎陌尘的手指从琴键上收回来，放到膝盖上。他没有立刻回答，只把谱纸翻过去，盖住刚才写下的那一行。温和从他脸上退开，剩下克制的排斥。"
    "你看见他的指节在膝盖上收紧，便把追问停在这里，换了个话题。"
    
    player_name "说起来，你作为班长，期中一堆班级琐事要处理，会不会觉得很累？"

    "黎陌尘的肩线松下来，简单和你聊起收集班级反馈、协调教室等事务。他重新把谱纸翻回来，那一页却没有写字，只画了一道小节线；话题一碰到钢琴比赛，他便合上了谱纸。"

    scene bg stairs_evening at bg_top
    "不宜久留，你简单道别，离开钢琴练习室你走到楼梯口，回头看了一眼。练习室的门还虚掩着，灯还亮着。你举起相机，却没有拍。或许黎妤知道一些内情。"

    scene bg lakeside at bg_top
    "午后，秋阳褪去盛夏的灼热，变得温润柔和。校园湖边的长椅落了一层薄薄的银杏碎叶。你挎着相机出门采风，远远就看见黎妤独自坐在长椅上。"

    scene bg bench_ly at bg_top
    "平板搁在她膝上，《灯》的画面被密密麻麻的修改批注覆盖。黎妤把笔夹在指间转了一圈，又放下；屏幕暗下去，她重新点开。反复改稿已经磨掉了她的力气。"
    "你放轻脚步走到长椅另一侧。黎妤抬起头，疲惫没有藏住。"

    scene bg bench_tired_ly  at bg_top
    ly "啊，是你。"
    player_name "还在纠结绘本的修改方案吗？"

    "黎妤长长吐出一口气，把平板稍稍往下放。"
    ly "对方提了一大堆调整要求，很多想法我并不认同，可我又害怕自己太过固执，把这次来之不易的机会搞砸。"
    "她把笔在平板边缘敲了一下，声音闷闷的，陷入自我怀疑。"

    menu:
        "她把平板抱在腿上，等着你的回应。"
        "坐下来，听她说":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            scene bg bench_sad_ly  at bg_top
            "你往她这边挪了挪，先把时间留给她。黎妤把平板翻过来扣在腿上，像是不想再看那些批注。"
            $ affection_change = ""

            player_name "难得能拿到绘本合作机会，会担心搞砸太正常了。但这不代表你就要完全丢掉自己原本的想法。"
            "黎妤抬起头，眼底蒙着一层迷茫。"

            scene bg bench_vast_ly  at bg_top
            ly "可是合作方才是出钱的一方，要是我一直不肯妥协，会不会显得我很难沟通？"
            player_name "妥协可以，但不用全盘否定自己的创作。可以把可以让步的地方让出去，但是真正核心、你很在意的部分，可以好好跟对方讲道理，讲清楚你这么画的用意。"
            
            scene bg bench_relax_ly  at bg_top
            "黎妤指尖无意识摩挲平板的边框，沉默思索片刻，脸上的阴霾散去一小半。"
            ly "你说得好像也对…… 我总怕我的坚持只是小孩子的任性。"
            player_name "真正的创作，本来就该守住一点属于自己的东西。"
            "黎妤长长呼了一口气，把平板翻回来，点开和合作方的聊天框。"
            ly "行，我回去整理一下思路，把哪些可以改、哪些我想保留的地方分清楚，好好跟他们聊一聊。"
            "她的神色重新透出一点韧劲，心里的自我怀疑消解大半。"

        "举起相机，拍下她":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            "你没有开口立刻劝慰，悄悄把肩上的相机取下来，抬手举到眼前，取景框对准长椅上的黎妤。"
            $ affection_change = ""

            scene bg bench_vast_ly  at bg_top
            "秋日柔和的阳光落在她的发梢，眉头轻轻蹙起，目光落在平板画稿上，整个人浸在一种迷茫又执拗的情绪里。你轻轻按下快门。"
            "“咔哒” 一声快门响，打破安静。"

            scene bg bench_sad_ly  at bg_top
            "黎妤抬眼，手指在发梢停住，显出几分窘迫。"
            ly "哎，你怎么偷偷拍我啊，我现在表情肯定很难看。"
            player_name "不会，我拍的不是愁眉苦脸，是正在为自己热爱的东西纠结的样子，很真实。"
            "你把相机屏幕转向她，让她看刚刚拍下来的照片。她把照片保存下来，却没有发出去。"

            scene bg bench_relax_ly  at bg_top
            "黎妤凑近看了几眼，神色慢慢松弛下来，嘴角浅浅勾了勾。"
            ly "好像…… 确实没有想象中那么糟糕。"
            "她把平板搁在腿上，指尖划动屏幕翻看合作方那一堆修改意见。"
            ly "说真的，我还是有点慌。一边想把握住机会，一边又不想把自己画出来的东西改得面目全非。"
            player_name "纠结本身，也是创作的一部分。就算最后不能全部如愿，至少努力争取过就不会后悔。"
            "黎妤点点头，把平板锁屏收起来。"
            ly "好吧，我回去好好捋一捋，试着跟对方沟通看看。"
            "虽然心里的不安没有完全消失，但她不再一味陷在自我否定里面。"
    $ renpy.block_rollback()

    "她收起平板后，你问起昨夜在练习室听见的琴声。"

    player_name "对了，昨天晚上我在教学楼钢琴房碰到黎陌尘，他弹奏得非常动人。但是我一提到钢琴比赛，他整个人就很抗拒，什么都不愿意多说。以前他是不是经常参加比赛？"
    
    scene bg bench_tired_ly  at bg_top
    "黎妤抠着速写本封面的一角，脸上的愁绪又沉下去，语气里交织着心疼与无奈。"

    ly "哥以前拿过的奖杯，家里柜子都快要摆不下。大大小小钢琴赛事，只要他去参加，名次几乎都很靠前。"
    ly "但是初中发生过一件事，具体经过他从来不肯跟我细说。从那之后，有一天他就突然对外宣称，自己再也写不出曲子。自那以后，几乎不再参加任何钢琴比赛。"
    ly "那件事彻底改变了他，让他变成现在这样沉默的性格。只是他把心事捂得太紧，连我也不清楚完整的来龙去脉。"

    "你翻出相机里那张琴房侧影。门缝里漏出的那线光还停在照片边缘。你看了两秒，关掉相机屏幕。"

    scene bg bench_relax_ly  at bg_top
    "短暂沉默之后，黎妤晃了晃脑袋，强迫自己从沉重的话题抽离，目光重新落回平板屏幕。"
    
    ly "先不想过去的事了。绘本这边，我打算鼓起勇气和合作方沟通，至少守住一部分我想表达的东西。"

    scene bg black at bg_top
    "…………………………………………"

    scene bg lecture at bg_top
    "数日之后，计算机系要举办一场专题学术讲座。自网球场分别之后，刘二狗这件事一直搁在你的心上。"
    "凌晨给过的线索只有一句 “人在计算机系”，信息少得可怜。你心里还抱着一丝微弱的期待，说不定可以在讲座现场碰碰运气。"
    "会场大半座位已经坐满，室内空调吹得人微微发凉，台上教授对着 PPT 进行讲解，底下遍布翻页、低声交谈的细碎声响。你找位置坐下，漫不经心地扫视场内人群，并没有抱很高的期待。"
    
    scene bg lecture_q at bg_top
    "可你没有想到，居然看见了牵绕。他坐在相隔几排的位置，一身黑色外套，身子松松靠在椅背上。面前摊着一本计算机书，书页停在同一页很久，一只手插在外套口袋。"
    "中场休息铃声响起，会场瞬间嘈杂起来，学生纷纷起身接水、走动闲聊。牵绕瞥见了你，便起身穿过往来人群，走到你身旁。"

    q "你也来听这个？"
    "他看了你一眼，又看了看你手里的笔记本。"
    q "你一个文学系的，来计算机讲座凑什么热闹。"
    player_name "随便听听。"
    q "随便听听就坐我旁边？"
    "他说这话的时候，语气很随意。但他往旁边挪了挪，空出了一个位置。"
    "网球场那晚你已经跟他打听刘二狗，他心里很清楚你一直在惦记寻找这位儿时玩伴。他眉梢微微一挑，带着几分了然的戏谑，却故意不点破。"

    q "还在找之前跟我提过的那个人？"
    "被他直接点破心思，你也不掩饰。你没有直接重复 “刘二狗” 这个外号，转而说起桃溪村的生活细节，试探他的反应。"
    player_name "毕竟是小时候很重要的旧相识。我偶尔会想起桃溪村，想起陈婆婆夏天煮的绿豆汤，还有院子里那棵遮天蔽日的老槐树。"
    q "桃溪村，好像在哪刷短视频刷到过相关的乡村片段。绿豆汤配老槐树，听着确实很有夏天的氛围感。"
    
    "有一处转瞬即逝的小细节被你捕捉到：听见 “陈婆婆的绿豆汤” 时，他眼皮极快地往下垂了半秒，快到你甚至怀疑，只是会场灯光晃动带来的错觉。"
    player_name "那说回那个人，你后来有没有想起什么别的线索？就是桃溪村出来，同届计算机系的那一位。"

    "牵绕嗤笑一声，肩膀轻轻耸起，一副无可奈何的样子。"

    q "刘二狗？这什么土名字。"

    player_name "小时候的外号。"
    q "小时候的外号你也记这么清楚。"
    "他说这句话的时候，语气带着点嘲笑的意味。他拧开瓶盖喝了一口。拧回去时，瓶身被他捏得咔了一声。"

    q "说起来，乡下槐树花期的时候，花瓣落得到处都是，打扫起来特别麻烦。"

    "不等你抓住这句话继续深挖，他立刻轻巧调转话锋。"
    q "对了，你那台新相机，最近有没有拍到什么有意思的画面？"

    "直接把话题从童年往事，拉扯回到摄影上面。你看着他，他正垂眼拧瓶盖。瓶盖上的齿痕被指甲刮出一道白印。你忽然觉得，他比你以为的更会藏。"

    menu:
        "你准备怎么接他这句话？"
        "顺着他的话聊摄影":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "最近拍了几组秋天的银杏，光线好的时候还不错。"
            $ affection_change = ""

            q "回头发我看看。"
            "他说这话的时候，语气很随意。但他拧瓶盖的手松开了。"
            "你把手机拿出来，翻了几张给他看。他低头看完，没说好不好，只把手机还给你。"
            q "……构图还行。"
            "你听出来，这是他能给的最高的评价。"
        "继续追问桃溪村":
            $ qianrao_affection += 3
            $ affection_change = "+3"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "你刚才说槐树花期花瓣落得到处都是，你是在哪里看到的？"
            $ affection_change = ""

            "他拧瓶盖的手停了一下。"
            q "……网上。"
            "他没有再看你。"
            "你知道他在撒谎。但你没有拆穿他。"
        "什么都不说，看着他":
            $ qianrao_affection += 2
            $ affection_change = "+2"
            $ affection_target = q_display_name
            show screen affection_change
            "你没有接话。你看着他。"
            $ affection_change = ""

            "他被你看得不自在，把瓶盖拧紧，塞回外套口袋。"
            q "……看我干嘛。"
            player_name "没什么。"
            "他别过脸去，没有再说话。"
    $ renpy.block_rollback()

    "休息时间结束，讲座重新开始，两个人就此终止交谈。"

    scene bg shaded_path_evening at bg_top
    "又过去了几日，某个傍晚，夕阳把校园林木晕染成暖融融的金橙色。牵绕发来微信消息，借口社团需要宣传素材，邀请你出来，帮忙拍摄一组秋日外景人像。"
    "你应下邀约，二人并肩走在校内步道，金黄银杏簌簌飘落。走着走着，一棵高大的老槐树出现在道路前方，虬曲伸展的枝干，浓密的树冠，和记忆中桃溪村陈婆婆家那棵模样十分相像。"

    scene bg shaded_path_autumn_q at bg_top
    "走到树下，牵绕的脚步慢了半拍。他脸上惯有的笑意淡去，望着层叠的树冠，像被某段旧时光拉住。很快，他收回视线，抬手指向树冠。"
    q "这里光线很不错，就在这儿拍几张吧。"
    "那一瞬间的失神太过短暂，你甚至分不清，究竟是触景生情，还是黄昏光影造成的错觉。"
    menu:
        "直接问他":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            "你没有顺着他的话准备拍摄，眉头微微蹙起，看向站在槐树底下的牵绕。"
            $ affection_change = ""

            player_name "有件事我一直很好奇。刚刚聊到的那些桃溪村的细碎小事，像槐树落花、陈婆婆的绿豆汤，很多都是很私人的童年记忆。如果只是刷过短视频，不该了解得这么细致。"

            scene bg viewfinder_q at bg_top
            "牵绕脸上的笑意淡了几分。他把相机拿过去，反过来，让取景框对着你；你从取景框里看见他，他却看着你身后的老槐树。随后他垂眸看向银杏碎叶，既不承认，也不否认，只笑了一声。"
            q "哦？这么说，你是在怀疑我什么？"
            "他不接你的疑问，既不澄清，也不摊牌，把问题又抛回给你。眼底藏着一丝玩味，好像很享受看你纠结猜测的样子。"
            "你盯着他的表情，依旧读不到确凿答案，所有的怀疑依旧停留在主观感觉层面。"
            player_name "我只是觉得巧合有点太多了。"
            q "世间巧合本来就不少。好了，别想那么多，干活，拍照。"
            "他晃了晃身子，主动摆好拍摄姿势，强行把话题拽回到拍照这件事上，刻意回避继续深挖桃溪村的话题。"

        "不问他":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            "你把盘旋在心头的种种疑问压了下去。"
            $ affection_change = ""
            "就算此刻把心里的猜测说出口，你手上也拿不出半分实实在在的证据，到头来只会变成无端的揣测。"
    $ renpy.block_rollback()

    "你压下纷乱思绪，擦过镜头边缘，抬手举起相机。"
    player_name "行，那就在这里拍。"

    scene bg Photograph_two_q at bg_top
    "牵绕见你没有继续追问，肩膀松了一点，很快又恢复平日的表情。他调整站姿，迎着落日的余晖配合你的镜头。"
    "你按下快门，取景框里他站在槐树下。槐树的枯叶落在肩头，他没有拂掉。你忽然分不清，他是不在意，还是忘了。"

    "拍摄结束，你收起相机。他走过来，低头看了一眼你手里的相机屏幕。"

    menu:
        "你准备怎么回应他？"
        "把照片给他看":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            "你把相机递过去。他翻了几张，停在其中一张上。"
            $ affection_change = ""

            q "这张。"
            player_name "怎么了？"
            q "……没什么。就是觉得，这张的光不错。"
            "他把相机还给你，没有再多说。但你注意到，他看那张照片的时候，手指在屏幕上停了一会儿。"
        "把相机收起来":
            $ qianrao_affection += 2
            $ affection_change = "+2"
            $ affection_target = q_display_name
            show screen affection_change
            "你把相机收进包里。"
            $ affection_change = ""

            q "不给我看看？"
            player_name "回去修完再发你。"
            q "……行。"
            "他点了点头，没有追问。但你看得出来，他有一点失落。"
        "反过来拍他":
            $ qianrao_affection += 4
            $ affection_change = "+4"
            $ affection_target = q_display_name
            show screen affection_change
            "你没有给他看照片，而是把相机举起来，对准他。"
            $ affection_change = ""

            q "……你干嘛。"
            player_name "拍一张花絮。"
            "他抬手挡了一下镜头，但没有躲开。"
            "快门按下。照片里，他的手挡在脸前，嘴角却微微翘着。"
    $ renpy.block_rollback()

    scene bg dorm_downstairs_evening at bg_top
    "你们并肩走回宿舍区。一路上他没怎么说话，你也没有。"
    "走到岔路口的时候，他忽然停下脚步。"
    "你跟着停下来，等他开口。"
    "他却没有看你，只是低头看着脚边一片被风吹过来的银杏叶。"

    q "……今天拍得还行。"
    player_name "嗯。"
    q "回去修好了，发我。"
    player_name "好。"

    "他点了点头，转身朝另一条路走了。"
    "没有多余的话。也没有回头。"
    "你站在路口看了一会儿他的背影，然后转身往宿舍走。"
    "那天拍照结束之后，你们在校门口分开。他没有多说什么，只是照例挥了挥手，转身走进暮色里。"
    "你回到宿舍，把照片导进硬盘。其中一张里，他站在老槐树旁边，肩上的枯叶没有落下，也没有被他拂掉。你盯着那张照片看了几秒，然后把它放进一个没有命名的文件夹。"

    scene bg team_building at bg_top
    "日子一天天过去。银杏叶黄得更深，又一片片落下来。等你再翻日历的时候，秋日团建已经排上了日程。"
    "秋日团建安排在校园中心的小广场。长桌上摆着饮料和零食，同学们三三两两散在阳光里。熟悉的几个人也在不同位置，你可以去找其中一人聊天。"
    menu:
        "人群就在眼前，你想先走向谁？"
        "黎陌尘":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg team_building_lm at bg_top
            "黎陌尘正站在长桌边，作为班长，他手里拿着纸笔，安静清点物资、登记到场同学。待人过来搭话时，他会温和应答，但话语始终克制简短。"
            $ affection_change = ""

            "你缓步走到他身边。"
            player_name "班长，辛苦你了，还要负责清点这些东西。"
            "黎陌尘抬眼看见你，停下手中的笔，唇角扬起淡淡的笑意。"
            lm "没事，本来就是我该做的。团建大家玩得舒心就好。"
            "旁边一名路过的同学听见对话，顺口插话提起校内钢琴大赛的报名通知。"
            girl "班长，你钢琴那么厉害，这次比赛肯定会参加吧？"
            "听见“钢琴比赛”，黎陌尘握笔的指尖收紧。他把笔帽盖上，又打开，再盖上，避开了这个话题。"
            lm "暂时没有参赛打算。物资还有部分没有清点完，我们先不说这个了。"
            "他重新看向你，神情已经恢复平稳。"
            lm "你今天逛下来，觉得这次团建怎么样？"
            player_name "氛围挺舒服的，没有那么拘谨。"
            lm "那就好。"
            "简单闲谈几句之后，又有同学过来找他登记信息，他只能向你示意，继续忙手头的工作。"
        "黎妤":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            scene bg team_building_ly at bg_top
            "黎妤蹲在石凳边，把手机倒扣在桌面上，深呼吸一次，又翻过来继续回消息。"
            $ affection_change = ""

            "你在她身侧停下脚步。"
            player_name "还在和合作方沟通绘本的事情吗？"
            "黎妤抬头看见你，脸上带着一点疲惫，却还是扬起笑容。"
            ly "是啊，刚刚又拉扯一轮。一部分画面要求我可以妥协，但是有几处核心的插画构思，我不想让步。"
            player_name "可以慢慢沟通，不用逼自己急着给出答复。"
            ly "嗯，我不想轻易丢掉属于我自己的想法。就算机会难得，全部妥协之后画出来的东西，也不是我想要的。"
            "手机又弹出新消息。她扫了一眼，叹口气，把回复继续写下去。"
            ly "对方又发来新的修改意见了，我得继续回复。谢谢你过来陪我说说话。"
            "你点点头，不再打扰她，起身离开。"
        "怀小柿":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            scene bg team_building_hx at bg_top
            "怀小柿独自站在树荫边缘，手机备忘录里已经写了两行。她删掉一行，又把手机锁屏。"
            $ affection_change = ""

            "你走到她身旁。"
            player_name "一个人待在这里会不会太无聊？"
            "怀小柿转过头，目光落在你身上，神色柔和。"
            hx "还好，人多有点吵，在这边安静一点。"
            "她扫了眼周围，确认没有旁人，才压低声音。"
            hx "我刚刚在构思《桃溪村的夏天》接下来的剧情，想写一段夏日夜晚在老槐树下乘凉的片段。"
            player_name "听起来很有画面感。"
            "怀小柿轻轻弯了弯嘴角，还准备继续往下说，两名同学从旁边路过。她立刻停下讲述小说的话题，闭上嘴，重新变回安静内敛的模样，不再多说。"
            "见她不愿继续聊，你轻轻和她道别。"
        "牵绕":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg team_building_q at bg_top
            "牵绕混在一群男生中间，和大家说笑打闹，看上去游刃有余。但闲聊间隙，他的目光时不时掠过人群，留意你的位置。看见你朝他走来，他笑着和身边朋友打了声招呼，抽身走到你的面前。"
            $ affection_change = ""

            q "过来找我？难得。"
            player_name "我还挺好奇的，这次团建只允许咱们班同学参加，外班人想来需要提前报备，你怎么会在这里？"
            "牵绕双手插在外套口袋，语气坦然。"
            q "我提前联系黎陌尘打过招呼，跟他说想来凑凑热闹。他同意了，给我特批过来的资格。"
            player_name "原来是这样。"
            q "刚好听说有露天的小团建，过来看看。"
            player_name "对了，你最近有没有发现什么适合拍照的地方？"
            q "图书馆后方那条林间小路秋色不错，树叶全都变黄了，很适合外景拍摄。有空可以一起过去。"
            "他说这句话时没有看你，像在背一条早就想好的路线。"
            "你心里依旧藏着之前的疑惑，可他姿态从容，完全不给你深挖童年旧事的机会。没聊多久，远处有朋友喊他的名字。"
            q "朋友喊我了，我先过去。想拍照了随时找我。"
            "他挥挥手，转身重新回到人群之中。"
        
        "独处":
            "你没有去找任何人交谈，在广场四周散步。黎陌尘清点物资，黎妤回复消息，怀小柿站在树荫下，牵绕和朋友们说笑。"
            "你拍下秋日人群，又拍了一张空椅子。椅背上搭着一件没人认领的外套。"
    $ renpy.block_rollback()

    scene bg dorm_downstairs_evening at bg_top
    "夜色慢慢笼罩校园，团建结束，众人四散离开。"

    scene bg desk_turn_off at bg_top
    "你回到宿舍，把今天的照片导进硬盘：黎陌尘的笔帽、黎妤倒扣的手机、怀小柿删掉的那一行、牵绕没有看你的侧脸。你都没有删。"
    "琴房的创伤、绘本的改稿、小说的秘密和牵绕的疑点，分别停在相册的不同页面。窗外秋风掠过树叶，你合上电脑。"

    scene bg dorm_afternoon at bg_top
    "期中考试结束，你有一整个下午的空闲时间。"

    menu:
        "去琴房找黎陌尘":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg piano_room_morning at bg_top
            "你走到琴房。黎陌尘坐在里面，面前摊着谱纸。"
            $ affection_change = ""

            "他没有弹琴。他只是看着谱纸。"
            "你走进去，坐在旁边。"
            lm "……又写不出来。"
            player_name "那就先不写。"
            "你把相机拿出来，开始擦镜头。"
            "他看着你擦了一会儿，忽然开口。"
            lm "你擦相机的样子，很安静。"
            player_name "嗯？"
            lm "……没什么。"
            "他拿起笔，写下一个音符，又划掉。随后重新写了一个一样的。"
        "陪黎妤整理画稿":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            scene bg dorm_desk_books_ly at bg_top
            "你陪黎妤整理她的画稿。她的画稿堆了一整桌，乱的。"
            $ affection_change = ""

            "你一张一张帮她拍下来，按日期存好。"
            "她坐在旁边，看着你拍。"
            ly "你拍照的时候，比我画画还认真。"
            player_name "因为你的画值得认真拍。"
            "她的手指在画纸边缘停住。"
            ly "……你今天怎么突然这么会说话。"
            "但她嘴角翘起来了。"
            "她把最后一页速写本合上，手指在封面上按了一下。"
        "去图书馆找怀小柿":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            scene bg library_hx at bg_top
            "你去图书馆找怀小柿。她坐在老位置，面前摊着电脑。"
            $ affection_change = ""

            "你走过去，她抬头看了你一眼。"
            hx "……你怎么来了。"
            player_name "路过。"
            "她往旁边挪了半寸，给你腾出位置。"
            "你坐下来，翻开自己的书。"
            "她写了一阵，才小声说："
            hx "……有人在旁边，好像写得顺一点。"
        "约牵绕打网球":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg tennis_instruction_q at bg_top
            "你约牵绕打网球。他答应的速度比你想象的快。"
            $ affection_change = ""

            "你不太会打，他站在旁边，手把手教你握拍。"
            q "手别抖。"
            player_name "我没抖。"
            q "你抖了。"
            "他伸手按了一下你的手腕。"
            "他的手停了一瞬，随后收回去。"
            q "……就这样。自己练。"
            "他转身走了。但走了两步，又回头看你。"
            "你低头看向球拍，拍柄上还留着他手指按过的温度。"
    $ renpy.block_rollback()

    scene bg desk_turn_on at bg_top
    "你回到宿舍，把相机里的照片导进硬盘。琴房侧影、湖边写生、老槐树、香樟树下的牵绕。"
    "一学期下来，文件夹里的照片比开学时多了几倍。"
    "窗外天黑得很慢。你合上相机，放在桌角，备用电池还在外套口袋里。"


    # ————————————————————————————————————————第五章————————————————————————————————————————
    play music "music/夏日Romantic Night.MP3" fadein 1.0

    scene bg classroom at bg_top
    "初冬的风擦过校园，教室窗上起了一层薄雾。期中刚结束，专业课作业和小组报告已经堆到桌角，期末的压力紧跟着逼近。"
    "图书馆的座位开始难抢，班级群里的通知却越来越多。你背着相机走过银杏落尽的路，偶尔按下快门，也越来越清楚，有些心事不是镜头能装下的。"
    
    scene bg dorm_four_hx at bg_top
    "怀小柿半靠在床头，手机冷光映着她的脸，指尖敲着《桃溪村的夏天》。她打一段，退回去删两个字，又重新写。"
    "小说在网络平台热度稳步上涨，网上的读者隔着屏幕热烈共情故事。真正压在她心上的，是期末文学类小组作业。"
    "课程要求提交一篇原创短篇故事，授课老师在课上提过：写得出彩的作业，作者可以选择匿名投稿给校刊。"
    "麻烦的地方在于：怀小柿准备交的这篇短篇，故事背景同样是桃溪村，遣词、意象、情绪，和她网络连载的小说高度同源。"
    "一旦这篇短文登到校刊，就算是匿名，熟悉她文笔的同班同学、身边朋友，只要同时看过校刊短文和网络小说，很容易从文风、独有的故乡细节上嗅到相似之处。"
    "不需要网上大扒帖，仅仅身边熟人的一点点联想、私下的比对猜测，就足以戳破她的保护层。"
    "风险不是已经发生，而是实实在在摆在面前的一道选择题：要不要投稿？投，就等于把相似文字放到现实熟人圈子视野；不投，又会错过一次被看见的机会。"
    "敲完一大段更新，怀小柿把手机往被子上一扣。她侧过头看向你的床位，手机备忘录打开又锁上；屏幕暗下去后，她还盯着那块黑屏。"
    
    hx "……有空吗，想跟你说两句话。"
    menu:
        hx "……有空吗，想跟你说两句话。"
        "听她把话说完":
            $ player_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            "你掀开被子一角，微微侧身，靠近她床位的方向。"
            $ affection_change = ""

            "怀小柿压低音量，只让你一个人听得见。"
            hx "期末那篇短篇作业，我写的还是桃溪村的故事。老师说写得好可以匿名投到校刊。"
            "她的指尖无意识攥住被褥的边角，声音带着一丝紧绷。"
            hx "可那篇的感觉，和我网上写的《桃溪村的夏天》太像了。就算校刊用匿名，咱们班好多同学也会读校刊。万一有人同时看过两边的文字，顺着文风、那些只有桃溪村才有的细碎描写往上联想……"
            hx "网上的秘密目前只有你和江枫知道。我很害怕，不用实锤，仅仅只是身边人的怀疑和私下揣测，就足够让我手足无措。我还没有准备好，把心底这些私人的故事摊在现实熟人面前评判。"
            hx "投稿是一个机会，可迈出那一步，代价我承担不起。有些藏在文字背后更深的东西，我现在还没有准备好说出口。"
            player_name "放心，我不会向外人说起。这件事，你可以慢慢想，不用急着下决定。"
            "怀小柿点了点头，把被子往上拉了一点，盖住下巴。"
        "说今天太晚了，明天再聊":
            $ player_affection += 2
            $ affection_change = "+2"
            $ affection_target = hx_display_name
            show screen affection_change
            "你示意现在太晚，建议明天再聊。怀小柿把手机塞到枕头下面，翻了个身；枕头边缘漏出一点屏幕光。"
            $ affection_change = ""
    $ renpy.block_rollback()
    
    # ————————————————————————————————————————————————————————————————————————
    # 第五章·中期小高潮：校刊风波
    scene bg dorm_morning at bg_top
    "那晚之后，怀小柿没有再主动提起短篇投稿的事。"
    "她照常上课、写代码、在深夜敲小说。只是每次你路过她书桌，她都会把手机屏幕稍微偏开一点。"
    "你没有问。她也没有说。"

    "几天后，校刊新一期出刊。"
    "文学类小组作业的匿名投稿栏里，有一篇短篇，标题叫《槐花落》。"

    scene bg classroom at bg_top
    "课间，你坐在教室里翻校刊。那篇小说写得很安静，写一个女孩在乡村长大，夏天在槐树下乘凉，后来离开，再也没有回去。"
    "你读到第三段，手指停住了。"
    "文风太熟了。桃溪村的槐树、陈婆婆的绿豆汤、田埂上的晚风。每一个细节，都像是从《桃溪村的夏天》里拆出来的。"
    "你抬头看了一眼怀小柿。她坐在靠窗的位置，低头翻书，但那一页很久没有翻过去。"

    "前排两个女生在小声议论。"
    girl_one "这篇《槐花落》写得好好啊，感觉作者就在我们年级。"
    girl_one "你看这段，桃溪村的夏天，槐花落在石阶上。跟网上那本《桃溪村的夏天》文风好像。"
    girl_two "真的假的？那本我也看过，作者叫柿柿如意，该不会是我们学校的吧？"
    girl_one "有可能哦。你看这个用词，“老槐树”、“田埂”、“绿豆汤”，一般城里人写不出来。"

    "怀小柿的手指停在书页边缘。她没有抬头，但你能看见她的肩膀慢慢收紧了。"
    "她把书合上，又打开。翻到同一页，又合上。"

    scene bg dorm_evening at bg_top
    "晚上回到宿舍，群聊里也有人转发了校刊的链接。"
    ly "这篇《槐花落》好好看！有人认识作者吗？"
    jf "匿名投稿吧。文笔挺成熟的。"
    xm "你们文学系的人都这么会写？"
    "怀小柿没有在群里说话。她的头像亮着，但一直没有输入。"
    "过了几分钟，江枫单独给你发了一条私信。"
    jf "你看群了吗。小柿子好像有点慌。"
    player_name "我看到了。"
    jf "她知道那篇会被认出来。她之前就跟我说过。"

    scene bg dorm_five_hx at bg_top
    "你放下手机，转头看向怀小柿的床位。她坐在床上，手机屏幕朝下扣在膝盖上，手指攥着手机壳边缘。"

    hx "……你看到了吗。"
    player_name "看到了。"
    "她的声音很轻，像是从嗓子底下挤出来的。"
    hx "他们好像……猜到了。"
    hx "没有人点名，但每一句都在往我身上靠。"
    hx "我明明用了匿名，明明换了一些细节。可他们还是能从文风里认出来。"

    scene bg dorm_six_hx at bg_top
    "她抬起头看你。眼睛没有红，但目光很紧。"
    hx "我是不是不应该投。"
    hx "我是不是……连写都不应该写。"

    menu:
        "怀小柿攥着手机，等着你的回应。"
        "去群里把话题引开，先帮她挡一挡":
            "你拿起手机，回到群聊。"

            scene bg desk_turn_on at bg_top
            "你没有直接否认，也没有替她承认。你发了几张今天拍的照片，问大家要不要周末一起去湖边采风。"
            "话题被你硬生生岔开。黎妤第一个接话，谢旻跟着发了一个表情包，江枫也顺势聊起周末的天气。"

            $ huaixiaoshi_affection += 8
            $ affection_change = "+8"
            $ affection_target = hx_display_name
            show screen affection_change
            "群里的猜测慢慢沉了下去。"
            $ affection_change = ""

            scene bg dorm_six_hx at bg_top
            "你放下手机。怀小柿看着你，手指松开了一点。"
            hx "……谢谢。"
            player_name "他们只是猜。没有证据，你不用自己先认。"
            "她点了点头，把手机翻过来。屏幕还亮着，停在群聊界面。她没有再打字，但肩膀松了一点。"
            "你知道，这件事没有真正解决。但至少今晚，她不用一个人盯着那些猜测。"

        "陪她去找江枫，三个人一起商量":
            player_name "先别自己扛。江枫知道这件事，我们去找她。"

            scene bg desk_turn_on at bg_top
            "怀小柿犹豫了一下，最后还是穿上外套，跟你一起去了江枫的床位。"
            "江枫正在折纸。看到你们过来，她把手里的纸鹤放下。"
            jf "我猜你们会来。"

            scene bg dorm_jf_hx at bg_top
            "怀小柿坐到她旁边，抱着膝盖。江枫没有追问，只是把一只折好的纸鹤放在她手边。"
            jf "群里那点话，不算什么。他们猜他们的，你写你的。"
            hx "可是他们万一真的查出来……"
            jf "查出来就查出来。你写的是小说，不是认罪书。"
            "江枫看了你一眼，又看了看怀小柿。"
            jf "不过，接下来那一期校刊，你可以先不投。不是怕，是给自己留点时间。"

            $ huaixiaoshi_affection += 10
            $ affection_change = "+10"
            $ affection_target = hx_display_name
            show screen affection_change
            "怀小柿低头看着那只纸鹤。过了一会儿，她轻轻嗯了一声。"
            $ affection_change = ""
            "你站在旁边，没有多说话。但你知道，江枫说的，比你一个人劝她更有用。"

        "告诉她，别怕，继续写":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            player_name "你写的是真的。真的东西，就会有人认出来。"
            $ affection_change = ""

            player_name "但认出来，不代表你做错了。"
            "怀小柿看着你，嘴唇动了动，没有立刻说话。"
            hx "……可是我还没准备好。"
            player_name "那就慢慢准备。"
            player_name "你可以不回应，也可以继续写。写不写，投不投，都由你决定。"
            "她把手机重新拿起来，翻到校刊那篇《槐花落》。她看了很久，最后把页面关掉。"
            hx "……嗯。"
            "她没有再说话。但那天晚上，她打开文档，写了很长一段。"
            "你没有看。你只是听见键盘声一直响到很晚。"
    $ renpy.block_rollback()

    scene bg dorm_morning at bg_top
    "第二天早上，校刊那篇《槐花落》的讨论慢慢淡了下去。"
    "没有人再公开猜测作者。但怀小柿去上课的时候，还是习惯坐在最角落的位置。"
    "江枫把一只新折的纸鹤放在她桌上。怀小柿没有拿，但也没有把它推走。"

    scene bg library_front_morning at bg_top
    "期末周越来越近。图书馆的座位开始难抢，班级群里的通知也越来越多。"
    "怀小柿没有再提校刊的事。她照常写代码、写小说，只是每次你举起相机，她都会先侧过脸。"
    "你没有拍她。你把镜头转向窗外。"
    "你知道，她还在学着被看见。而你，可以等。"

    "期末周来得很快，天还没亮，自习室已经坐满。图书馆的灯一直亮到深夜。"
    "你经常在图书馆碰到牵绕。他泡在计算机参考书旁，草稿纸写满推导。笔夹在指间转了一圈，掉到桌上，他也没捡；累了便靠着椅背闭目，或打开相册，翻到某一页又很快划走，只留下一片模糊的绿色。"

    "期末周，你只能把有限的空余时间花在一处。"

    menu:
        "陪黎陌尘练琴":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            scene bg piano_room_morning at bg_top
            "你路过琴房，门缝里亮着灯。黎陌尘没有弹琴，只看着谱纸。"
            $ affection_change = ""

            "你走进去，坐在旁边。"
            lm "……你不用复习吗？"
            player_name "路过。"
            lm "你每天都路过。"
            "他没有再问，把谱纸翻到新的一页，写了一个音符，又划掉，重新写了一个一样的。你陪他坐到很晚。"
        "陪黎妤改稿":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            scene bg sketch_ly at bg_top
            "湖边风大，黎妤把画纸压在膝盖上改稿，你在长椅另一端坐下。"
            $ affection_change = ""

            "她改到一半，把平板递给你。"
            ly "你帮我看看，这样改行不行。"
            "你接过来，认真看了一遍。"
            player_name "这里，我觉得原来那版更好。"
            ly "……你也这么觉得？"
            "她把平板拿回去，改回原来那一版。光标闪了两下，她按下保存。"
            ly "行。听你的。"
        "陪怀小柿写作":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            scene bg desk_turn_off at bg_top
            "宿舍熄灯后，只有怀小柿的屏幕还亮着。她对着空白文档，你坐在旁边擦镜头。"
            $ affection_change = ""

            hx "……你擦相机的样子，和我写不出来的时候，有点像。"
            player_name "哪里像？"
            hx "……都在等。"
            "你继续擦镜头。她继续对着空白文档。"
            "那天晚上，她写了三千字，合上电脑后又在键盘上敲了一下，像在确认什么。"
        "和牵绕打球":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg playground_stand_evening at bg_top
            "操场灯快关了，牵绕还在投篮。你坐在看台上看着他。"
            $ affection_change = ""

            "他打了一会儿，走过来。"
            q "你不复习？"
            player_name "你不也打球。"
            q "……我复习完了。"
            player_name "骗人。"
            "他的手停在半空，随后笑了。"
            q "行吧。那你帮我数着，我投进十个就走。"
            "他转身走回球场。你数到第十个，他还在投。"
        "自己复习":
            scene bg desk_turn_on at bg_top
            "你把相机收进柜子，打算期末周先专心复习。"
            "桌上堆着课本和笔记，屏幕上是没写完的论文。图书馆抢不到座位的时候，你就在宿舍里看书。"
            "某个深夜，你抬头看了一眼书架最上层。相机放在那里，镜头朝下。"
            "你没有去碰它。"
            "你继续低下头，翻过一页笔记。窗外的风把台灯的光晃了一下。"
    $ renpy.block_rollback()

    scene bg canteen at bg_top
    "期末周的某个中午，你在食堂打饭。你端着餐盘找位置，看到了怀小柿。"

    scene bg canteen_two_hx at bg_top
    "她一个人坐在角落里，面前放着一碗汤和一本摊开的书。她没有在吃饭。她在看书。"
    menu:
        "端着餐盘坐过去":
            $ huaixiaoshi_affection += 5
            $ affection_change = "+5"
            $ affection_target = hx_display_name
            show screen affection_change
            scene bg canteen_four_hx at bg_top
            "你把餐盘放下。她抬起头，看到你，手里的书签停在半空。"
            $ affection_change = ""

            "她往旁边挪了挪自己的书，给你腾出位置。"
            "书页折了一个角，她又把那个角抚平。"
            "你们安静地吃饭。"
            "吃到一半，她忽然把自己碗里的玉米夹了一根给你。"
            hx "……这个好吃。"
            "你夹起来吃了。她把书翻过一页，嘴角动了一下。"
        "不打扰她，换一张桌子":
            $ huaixiaoshi_affection += 3
            $ affection_change = "+3"
            $ affection_target = hx_display_name
            show screen affection_change
            "你端着餐盘，去了另一张桌子。"
            $ affection_change = ""

            "你坐下之后，回头看了一眼。"

            scene bg canteen_three_hx at bg_top
            "她拿起汤勺，又放下。那碗汤始终没有动。"
    $ renpy.block_rollback()

    scene bg teaching_building_morning at bg_top
    "期末复习间隙，你路过教学楼。"

    scene bg piano_room_winter_lm at bg_top
    "琴房的门开着。黎陌尘坐在里面，面前摊着一沓谱纸。"
    "他没有在弹琴。他只是看着谱纸发呆。"
    "你站在门口。他抬起头看到你。"
    lm "……进来坐吧。"
    "你走进去。他把谱纸往旁边挪了挪，给你腾出位置。"
    lm "写不出来。"
    "他说了三个字，语气很平。"
    "你把相机放在桌上，镜头朝下，坐在他旁边。谱纸的边角碰到桌面，发出一声细响。"
    "他看着琴键，隔了片刻才开口。"
    lm "有时候我觉得，弹琴和写曲子是两件事。"
    player_name "哪里不一样？"
    lm "弹琴是弹别人的东西。写曲子是写自己的。"
    lm "……但我最近写不出来。"
    "他看着琴键，沉默了一会儿。"
    menu:
        "不说话，陪他坐一会儿":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            "你坐在旁边，把相机放在腿上。"
            $ affection_change = ""

            "你们坐在琴房里，一直到天色完全暗下来。"
            "他站起来，合上琴盖，琴凳往后挪了一下，没有推回去。"
            lm "……走吧。"
        "问他去不去食堂":
            $ limichen_affection += 3
            $ affection_change = "+3"
            $ affection_target = lm_display_name
            show screen affection_change
            player_name "要不要一起去食堂？"
            $ affection_change = ""

            "他的手停在琴盖边缘。"
            lm "……好。"
            "他站起来，用手掌碰了一下琴键，没有按下去，才把琴盖合上。"
            "你们一起去食堂，路上没怎么说话。"
            "但他走路的时候，脚步比平时慢了一点。"
    $ renpy.block_rollback()

    scene bg library_front_morning at bg_top
    "期末复习的日子一天天过去。图书馆、自习室、开水间，你来来回回地跑。"

    scene bg water_supply_room_q at bg_top
    "有一回，你在开水间碰到牵绕。他看了眼你的相机包，插兜偏头对你说话。"
    q "你那个相机最近落灰了吧。"
    "你低头看了一眼，拉链上确实有一层灰。"
    "你们聊了几句复习和校园里的拍摄地点，谁也没有把话题往更深处推。"
    "临走的时候，他忽然问了一句。"
    q "明天约了人打乒乓，你要不要来？"

    scene bg stairs_evening at bg_top
    "有一回傍晚，图书馆快要闭馆，大批学生往外涌出。你们恰好并肩顺着楼梯往下走。外面的天色已经彻底暗透，廊灯投下一片片昏黄的光晕。楼梯间回声很重，周围来往的人不多。"

    scene bg stairs_evening_q at bg_top
    q "复习熬得有点头疼，打算去校外买点热的东西填肚子。"
    player_name "看你最近几乎天天泡图书馆，计算机系期末压力这么大？"
    q "专业课堆得狠，不花时间啃是过不去的。"
    "他两手插在外套口袋，步伐不疾不徐，下楼的时候目光望向窗外沉沉的夜色。"
    q "偶尔也会觉得，书本习题堆过来，人会被压得喘不过气。就很想找个地方安安静静待一会儿，什么都不用去想。"

    menu:
        "把话头往旧地方引":
            $ qianrao_affection += 8
            $ affection_change = "+8"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "会想要回什么旧地方待一待吗。有些老地方待着会让人放松。"
            $ affection_change = ""

            q "旧地方？天下相似的风景到处都有，不必执着某一处。"
            "他答得圆滑，肩头绷紧半秒，随后把外套拉链往上拉了一截，遮住半截下巴。"
            q "说起来，你那台相机，期末复习搁置这么久，手会不会生？等考试全部结束，找个晴天，再出来拍几组。"
        "只聊压力，不提旧事":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "期末周大家差不多都是这个状态，熬过去就好了。"
            $ affection_change = ""

            q "确实，只盼着早点考完解放。"
            "他把手插回口袋，脚步比刚才快了一点。"
            q "考完试之后校园景色应该还不错，到时候可以出来拍照。"
        "顺着他的话，约考完拍照":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "那等考完试，正好可以出来走走拍拍照。"
            $ affection_change = ""

            q "那说定了，考完联系你。"
            "他掏出手机，屏幕亮了一下，又按灭，没有立刻记下。"
    $ renpy.block_rollback()

    player_name "可以。"
    "走到一楼大厅，人流分开，他朝你摆了摆手，便朝着校门的方向走远。背影消融在夜晚的人流之中。"

    scene bg lakeside at bg_top
    "没过几日，考完一门大课之后，校园里难得拥有一小段松弛的傍晚。牵绕主动发来消息，问你要不要去校园西侧那片老槐树林拍摄。你如约赴约。"
    "冬日的槐树早已落尽叶子，虬曲黝黑的枝干向天空伸展。落日余晖把枝丫的影子铺在地面，干枯落叶被晚风卷得打旋。"
    
    scene bg Photograph_three_q at bg_top
    "牵绕已经等在树下，身上穿着厚实的黑色外套。看见你过来，他便配合你的镜头摆出不同姿态。"
    "拍摄间歇，一根干枯的槐树枝被风折断，咔一声落在脚边。牵绕看着那根断枝，没有捡。"
    q "小时候见过不少这样的树。冬天枝丫光秃秃，看着萧条，根却扎得很深。"
    "这句话说完，他很快收回思绪，抬眼看向你，脸上又恢复往日那副漫不经心的笑意。"
    q "别发呆，抓紧多拍几张，天色很快就要彻底暗下去。"
    "你举起相机继续拍摄。他不会再多往下展开刚刚那句话。"

    "一轮拍摄结束，暮色沉沉，你们并肩踏上返回宿舍区的小路。晚风卷着枯叶在脚边打转。"
    menu:
        "顺着他的话，问童年":
            $ qianrao_affection += 6
            $ affection_change = "+6"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg walk_winter_q at bg_top
            player_name "听你说起这些老树，感觉你的童年好像见过不少类似的景物。"
            $ affection_change = ""

            q "到处都有这类树而已，算不上什么特别的经历。"
            "他侧过头看了你一眼，没有接话，把相机包往肩上提了提，带子勒进外套。"
            q "说点现实的吧，你期末剩下的几门课复习得怎么样？"
        "只聊刚才拍的照片":
            $ qianrao_affection += 7
            $ affection_change = "+7"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg walk_winter_q at bg_top
            player_name "刚刚黄昏光线效果很好，有几张成片我觉得效果很不错。"
            $ affection_change = ""

            q "是吗，那期待你的成片。之后有空还可以再来这边，日落的时间段氛围感一直不错。那张你留着，别删。"
            player_name "哪张？"
            q "就那张。"
        "约开春再来拍一次":
            $ qianrao_affection += 5
            $ affection_change = "+5"
            $ affection_target = q_display_name
            show screen affection_change
            scene bg walk_winter_q at bg_top
            player_name "寒假过完开春之后，这边树木抽芽，应该会更适合拍摄，到时候可以约。"
            $ affection_change = ""

            q "没问题，开春天气回暖，倒是值得再来一趟。到时候槐树该发芽了。"
            "他说完停了一下，像意识到自己说了什么，随后把话题带回拍摄。"
    $ renpy.block_rollback()

    scene bg dorm_downstairs_evening at bg_top
    "到分叉路口互相道别之后，他便独自消失在宿舍楼的方向。"

    play music "music/黄昏海岸线.MP3" fadein 1.0

    scene bg teaching_building_corridor at bg_top
    "期末考试陆续结束。"

    scene bg dorm_evening at bg_top
    "寒假出发前一晚，你正在宿舍收拾行李。手机弹出两条消息。一条是黎妤发来的。"
    ly "明天我哥要去琴房最后练一次琴，你要不要一起来？练完我们一起去吃个饭。"
    "另一条是黎陌尘发来的。"
    lm "明天黎妤说要去湖边写生，你要是有空可以一起。她最近画稿有点卡。"
    "两条消息，同一天，同一个时间段。"
    menu:
        "去琴房，听黎陌尘弹琴":
            $ limichen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lm_display_name
            show screen affection_change
            "你回复了黎陌尘。"
            $ affection_change = ""

            scene bg piano_room_morning at bg_top
            "第二天，你去了琴房。黎陌尘弹了一首曲子给你听。弹完，他把谱纸合上。"
            lm "这首还没名字。"
            player_name "什么时候有名字？"
            lm "等它写完。"
            "黎妤没有来。她在湖边画了一下午。"
        "去湖边，陪黎妤写生":
            $ liyu_affection += 5
            $ affection_change = "+5"
            $ affection_target = ly_display_name
            show screen affection_change
            "你回复了黎妤。"
            $ affection_change = ""

            scene bg lakeside at bg_top
            "第二天，你去了湖边。黎妤画了一下午，你坐在旁边拍照。她合上速写本。"
            ly "今天这张不给你看。"
            player_name "为什么？"
            ly "因为画得不好。"
            "黎陌尘没有来。他在琴房待了一整天。"
    $ renpy.block_rollback()

    scene bg teaching_building_morning at bg_top
    "寒假到来。大家收拾行李，四散回到各自的家乡，偌大校园变得空旷冷清。"
    "你也收拾行囊踏上归途。往年过年家里都留在城市，这一年，奶奶再三提议，希望一家人回桃溪村老家过年。几经商量，家里破天荒应允下来。"

    scene bg village at bg_top
    "车子一路往乡下行驶，道路两边风景慢慢变换。熟悉的乡野风物一点点映入眼帘，阔别多年的桃溪村，就这样重新出现在你的眼前。"
    "安顿下来的第一天午后，冬日的阳光温和地洒在村落。你把相机挎在肩上，打算独自出门，去逛一逛小时候常常流连的那些老地方。"

    menu:
        "走出门，你准备先去哪里？"
        "先去村东那棵记忆里的老槐树":
            scene bg locust_tree_old at bg_top
            "你沿着乡间土路，径直走向村东。那棵巨大的老槐树依旧立在原地，冬日树叶落尽，遒劲的枝干向四面伸展。地面落满陈年枯叶，石质老竹椅还摆在树底下，上面蒙着薄薄一层灰尘。"
            "你举起相机，从不同角度拍下老树。指尖抚过粗糙的树干，又碰到竹椅的椅背，手指沾了灰。你在裤子上擦掉，没有拍那张椅子。"
            "四下安安静静，只有风吹过枝桠发出的沙沙声响。这里现在看不到熟悉的人，只剩下满树过往的回忆。"
        "先走到陈婆婆旧家的院子外看看":
            scene bg courtyard_old at bg_top
            "你顺着村中小路，走到陈婆婆家院墙外面。院门紧闭，院墙爬着干枯藤蔓。隔着围墙，可以看见院内那几棵老果树。"
            "小时候，你常常跑到这座院子里蹭一碗绿豆汤。你隔着围墙听了听，里面没有声音。你举起相机，又放下。"
        "沿着田埂漫无目的四处闲逛":
            scene bg ridge_field at bg_top
            "你踏上田埂小路，冬日田地空旷辽阔。走到一半，你发现田埂尽头那棵小树不见了，原地只剩一个浅坑。"
    $ renpy.block_rollback()

    "一番游走之后，你转念打算正式上门探望陈婆婆。童年时她待你一向很好，既然回到桃溪村，理应过去拜个年。"

    scene bg courtyard_new at bg_top
    "你提着家里准备好的一点年礼，走上那条熟悉的石板小路。院门没有完全关死，虚掩着一道缝隙。你轻轻抬手叩响木门。"
    lc "请进，门没有闩上。"
    "听见这道熟悉的声音，你的脚步顿了顿，伸手推开院门。"

    scene bg new_courtyard_one_lc at bg_top
    "院子里晒着冬日的暖阳。陈婆婆坐在屋檐下的竹椅上晒太阳，而凌晨就站在一旁，正帮老人整理晒在竹匾里面的干菜。他一身简单深色棉衣，头发比在学校看着要柔和一点，褪去了平日里那层疏离的外壳。"
    "凌晨听见推门动静，转过头，目光落在你的身上，眼底同样掠过一丝明显的意外。"
    lc "没想到，你也回来了。"

    "陈婆婆耳朵不算特别灵光，眯起眼睛辨认了你好一会儿，才认出你是谁，脸上立刻绽开慈祥的笑意。"
    pp "哎哟，这不是二丫吗！好久不见，快过来烤烤太阳。"
    "你把年礼递过去。陈婆婆给你倒水，杯子是搪瓷的，边沿磕掉了一小块瓷。你陪婆孙二人在屋檐下晒太阳。陈婆婆絮絮叨叨跟你说起这些年村里各家的近况，念叨从前一群小孩子在槐树下疯跑玩耍的旧事。"
    pp "想当年，你们几个娃娃，二狗、二牛，还有你，天天在树底下闹得满头大汗。时间过得可真快啊，一个个全都出去读大学咯。"
    "听到“二狗”，凌晨手里的干菜梗折断了。他把断掉的那截放进竹匾，没有抬头。竹匾里的干菜摊得很开，风一吹，又聚回一起。"

    menu:
        "陈婆婆转身整理东西，你压低声音问凌晨："
        "趁陈婆婆转身，问凌晨刘二狗的事":
            $ lingchen_affection += 4
            $ affection_change = "+4"
            $ affection_target = lc_display_name
            show screen affection_change
            scene bg new_courtyard_two_lc at bg_top
            player_name "说起来，刘二狗……也就是牵绕，你应该是认识他的吧？"
            $ affection_change = ""

            lc "我认识。"
            "凌晨的语气压得很低，神色带着一点不愿提起的抵触，目光望向院门外那条乡间小路。"
            lc "只是没想到这么快你就找到他了。"
            lc "关于他的事，我不太想多聊。很多东西，该由他本人来讲，轮不到我替他说三道四。"
            "说完，他把竹匾往太阳底下推了推，干菜摊得更开。"
        "不问旧事，只聊村里近况":
            $ lingchen_affection += 5
            $ affection_change = "+5"
            $ affection_target = lc_display_name
            show screen affection_change
            scene bg new_courtyard_two_lc at bg_top
            player_name "几年没回来，村子变化确实挺大。"
            $ affection_change = ""

            lc "是，不少老房子都翻修重建。很多人，也只是留在记忆里。"
            "他说到“记忆里”时看了你一眼，很快移开。"
    $ renpy.block_rollback()

    scene bg new_courtyard_three_lc at bg_top
    "又陪陈婆婆闲聊一小会儿，考虑到老人家需要休息，你便起身告辞。凌晨送你走到院门口。"
    lc "既然回来，好好看看老家吧。有些东西，错过就很难再见到。"
    "说完，他便转身走回院内，关上那道虚掩的木门。"

    scene bg village at bg_top
    "逛完这一片区域，天色慢慢开始向傍晚倾斜。你掏出手机，屏幕上面弹出几条消息提示。"

    "黎妤待在家中的书桌前，台灯常常亮到很晚。对话框不断跳出她发来的消息。"
    ly "又改完一版稿件，甲方还是不满意。"
    ly "有时候真的觉得很累，我不知道这么坚持到底值不值得。"
    menu:
        "黎妤的消息停在屏幕上，你准备："
        "认真回她一段话":
            $ liyu_affection += 3
            $ affection_change = "+3"
            $ affection_target = ly_display_name
            show screen affection_change
            "你认真回复一大段文字，开导她不要过度自我否定。"
            $ affection_change = ""
        "让她先休息，明天再说":
            $ liyu_affection += 3
            $ affection_change = "+3"
            $ affection_target = ly_display_name
            show screen affection_change
            "你简单叮嘱她不要熬夜，把话题收束。"
            $ affection_change = ""
    $ renpy.block_rollback()

    "黎陌尘的社交账号十分沉寂，仅有几段不带任何文字的钢琴录音。音频里面琴声时而温柔，时而裹挟压抑的情绪，发布之后便不再更新动态。"

    "怀小柿就在桃溪村本村。你远远看见她在自家门前收拾杂物，没有上前。她后来发来几张老家风景照，其中一张拍到了老槐树的树冠，没有配文字。"
    hx "回到这里，很多旧回忆全都涌上来，写故事的思绪一下子丰富不少。"

    "牵绕的消息回复时快时慢。某天夜里，他发来几条消息，附带几张城市夜景随拍。"
    q "家里这边晚上的夜景。"
    q "考完试之后总算能稍微松一口气。"
    menu:
        "牵绕的夜景消息停在屏幕上，你准备："
        "再试一次，提乡下老树":
            $ qianrao_affection += 6
            $ affection_change = "+6"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "夜景挺好看的，我现在正好在乡下老家，这边冬天到处都是光秃秃的老树。"
            $ affection_change = ""

            q "到处都有，没什么特别。"
            q "不说这个，你寒假有没有在出外景？"
            "他轻巧转开话题，不继续聊景物背后可能关联的过往。"
        "只聊摄影":
            $ qianrao_affection += 4
            $ affection_change = "+4"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "拍得很不错，光影氛围感很强。我这几天也在到处拍，回了一趟乡下老家。"
            $ affection_change = ""

            q "那等开春回学校，正好可以接着拍。之前说好的。"
        "简单回一句，早点休息":
            $ qianrao_affection += 3
            $ affection_change = "+3"
            $ affection_target = q_display_name
            show screen affection_change
            player_name "挺好，好好休息。"
            $ affection_change = ""

            q "嗯，开学见。"
    $ renpy.block_rollback()

    "江枫、谢旻在家一遍遍录制音乐小样，录完推翻，推翻之后又重录，聊天框经常传来一段段半成品音频。"
    jf "又废掉一版，感觉离我想要的效果越来越远。"
    xm "耳朵已经起茧了。"
    jf "滚。"

    "凌晨继续维护存放回忆的个人网站，上传老照片和旧录音。小莱居家休养，很少上线，偶尔会给你发消息报平安。"
    "冬日缓缓流转，一月过去，二月也慢慢走到尾声。过年的热闹喧嚣慢慢褪去，转眼就到了返校的日子。"

    scene bg dorm_downstairs_morning at bg_top
    "3月，大一下学期返校。冰雪消融，料峭的春寒依旧还残留在空气里。宿舍楼里面又重新响起行李箱拖拽的声响，寝室恢复往日的喧闹。"
    # ————————————————————————————————————————————————
    # 黎妤线·关键剧情前置：寒假速写本
    # 无条件触发，给玩家保底加值，确保能进关键剧情
    # 建议加值 +12
    # ————————————————————————————————————————————————

    play music "music/性感休息室背景 Sexy Night.MP3" fadein 1.0

    scene bg dorm_afternoon at bg_top
    "返校后的第一个周末，宿舍里只有你和黎妤。"

    scene bg dorm_bed_ly at bg_top
    "她盘腿坐在床上，面前摊着一本厚厚的速写本。"
    "那是寒假带回家的那本。现在它比之前厚了一倍。"

    ly "你过来看看这个。"
    "她朝你招了招手。你走过去，坐到她床边。"
    "她把速写本翻开，一页一页给你看。"
    "全是墙。"

    scene bg wall_ly at bg_top
    "老城区的青砖墙、巷子尽头的红砖墙、村口斑驳的白墙、被爬山虎盖满的矮墙。"
    "每一面墙都画得很细。砖缝、苔藓、剥落的漆皮、钉在墙上的旧信箱。"
    "你翻到中间某一页，停住了。"

    scene bg wall_girl_ly at bg_top
    "那一页画的是同一面墙，但墙上多了一个人。"
    "一个女孩，背对着画面，站在墙前面。"
    "她的肩膀画得很僵，手也不知道该放在哪里。"
    "整个人像是一块贴上去的纸片。"

    scene bg dorm_bed_ly at bg_top
    player_name "这一页……"
    ly "画砸了。"
    "她伸手想把那一页翻过去。你按住了纸边。"
    player_name "你从来没画过人。"
    ly "嗯。画墙我可以画一天，画人不行。"
    ly "每次画到人的时候，我就不知道该给他们什么表情。"

    "她把速写本拿回去，翻到最后一页。"
    "最后一页是空白的。"
    ly "我本来想画一张全家福。"
    ly "但是画不出来。"

    "她低头看着空白页，手指在纸面上按了一下。"

    menu:
        "你准备怎么回应她？"
        "鼓励她试着画人，哪怕画不好":
            $ liyu_affection += 12
            $ affection_change = "+12"
            $ affection_target = ly_display_name
            show screen affection_change
            player_name "画不好就画不好。"
            $ affection_change = ""

            player_name "但你不画，就永远画不好。"
            "黎妤看了你一会儿。"
            ly "……你说话怎么跟老师一样。"
            "但她笑了。"

            scene bg wall_girl_photographer_ly at bg_top
            "她把速写本翻回那一页，拿起笔，在那个僵硬的女孩旁边，又画了一个人。"
            "这次是一个举着相机的侧影。"
            "线条还是不太稳。但比刚才那个好。"
            player_name "这是谁？"
            ly "你说呢。"
            "她没有抬头。"
        "夸她墙画得真好":
            $ liyu_affection += 8
            $ affection_change = "+8"
            $ affection_target = ly_display_name
            show screen affection_change
            player_name "你的墙画得真好。"
            $ affection_change = ""

            player_name "这些砖缝、苔藓，每一笔都能看出是真的去看过。"
            "黎妤的耳朵红了一点。"
            ly "……谢谢。"
            scene bg dorm_bed_hold_book_ly at bg_top
            "她把速写本合上，抱在怀里。"
            ly "墙比人好画。墙不会动，也不会说话。"
            player_name "但人也很有意思。"
            ly "是啊。"
            "她低头看着速写本的封面，没有继续往下说。"

        "不说话，陪她一起翻完":
            $ liyu_affection += 6
            $ affection_change = "+6"
            $ affection_target = ly_display_name
            show screen affection_change
            "你没有说话。你把速写本接过来，一页一页慢慢翻。"
            $ affection_change = ""

            "她坐在旁边，安静地陪着你。"
            "翻到最后一页，你合上速写本，还给她。"
            player_name "很好看。"
            ly "……嗯。"
            "她把速写本收起来，放进画包。"
    $ renpy.block_rollback()

    if liyu_affection >= 50:
        scene bg dorm_morning at bg_top
        "没过几日，黎妤的邮箱收到绘本甲方正式发来的最新修订邮件。这一次的修改要求不再是细枝末节的润色，而是直接要推翻《灯》故事最核心的立意。"

        scene bg dorm_downstairs_evening at bg_top
        "傍晚，她把你约到宿舍楼下。晚风带着残留寒意，她攥着手机，屏幕黑着，指节却压得发白。"

        menu:
            "甲方已经触及故事核心，你准备怎样陪她面对？此为关键剧情，建议游玩前先存档。"
            "【坚守本心】宁可丢掉项目，也要守住创作内核":
                $ ly_important_flag = "hold_idea"
                "你看着黎妤，先停了片刻，才认真说出想法。"
                player_name "如果代价是彻底丢掉你想表达的东西，那这份合作的意义就大打折扣了。实在不行，放弃这个项目也并不可惜。"
            "【适度周旋】做出部分让步，尽力保住这次合作机会":
                $ ly_important_flag = "compromise"
                "你看着黎妤攥紧的手机，斟酌片刻后开口。"
                player_name "机会来之不易，可以试着做出一部分妥协，看看能不能守住底线，尽量争取把项目保留下来。"
                "黎妤把手机攥得更紧，指节压得发白。"
        $ renpy.block_rollback()

        "黎妤听完，长长呼出一口气，肩膀沉下去，眼底仍有茫然。"
        ly "我需要一点时间好好想一想。"
        "她没有立刻答复。走出两步，她停下来，没有回头。"
        ly "你先回去吧。我想一个人走走。"
        "说完，她继续朝宿舍楼走去。"

    scene bg desk_turn_on at bg_top
    "你回到宿舍，把相机放在桌上。窗外三月的风还带着寒意。你打开相册，翻到寒假在桃溪村拍的老槐树，枝干光秃秃地伸向夜色。你看了很久，随后合上相机，关了灯。"


    # ————————————————————————————————————————第六章————————————————————————————————————————
    scene bg teaching_building_morning at bg_top
    "三月的风褪去残余寒意，春风漫过汴京大学校园。枝头花木陆续抽芽开花。"
    "整个冬天积压下来的心事如同地下涌动的春水，再也无法一味掩埋。"

    scene bg lakeside at bg_top
    "湖边的柳树抽出嫩绿色新条。黎妤约你来到熟悉的湖畔长椅。春日湖面波光粼粼，她攥着平板，神色褪去单纯的疲惫，多了一份下定决心后的沉静。"
    if ly_important_flag == "hold_idea":
        scene bg lakeside_sad_ly at bg_top
        ly "我反复和甲方沟通过好几次，我不肯妥协他们对于故事内核的修改要求。谈判彻底谈崩了。绘本合作项目，黄了。"
        "黎妤轻轻把平板放在腿上，语气平静，但眼底藏着难以掩饰的失落。"
        ly "说不难过是假话。这是我拿到的第一个正式商业绘本邀约。我曾经很期待它。可如果要我把《灯》最核心的那一部分全部抹掉，画一本完全不属于我的故事，那我宁愿不要这份机会。"
        menu:
            "你如何回应黎妤？"
            "肯定她的选择":
                $ liyu_affection += 5
                $ affection_change = "+5"
                $ affection_target = ly_display_name
                show screen affection_change
                player_name "守住自己的创作内核，本身就已经很有勇气。机会还会再有。"
                $ affection_change = ""

                "黎妤向你道谢，说接下来会继续画属于自己的短篇插画。就算没有商业合作，她也不想停下画笔。"
            "安慰她惋惜这次机遇":
                $ liyu_affection += 7
                $ affection_change = "+7"
                $ affection_target = ly_display_name
                show screen affection_change
                player_name "付出那么多心血最后落空，换谁都会难受，难过也是理所应当的。"
                $ affection_change = ""

                "黎妤向你道谢，说接下来会继续画属于自己的短篇插画。就算没有商业合作，她也不想停下画笔。"
        "春风吹起她的发丝，黎妤长长呼出一口气。绘本一事尘埃落定，但属于她的创作挣扎远远没有结束。你们小坐片刻之后互相道别。"
    elif ly_important_flag == "compromise":
        scene bg lakeside_sad_ly at bg_top
        ly "我权衡很久，选择做出一部分让步。一些次要的情节按照甲方的想法调整，但我拼死保住了《灯》最核心的立意。合作算是保住了。"
        "她指尖摩挲平板边缘，眉宇缠绕着挥之不去的郁结。"
        ly "可每一次修改，都像在一点点割掉属于我的东西。就算守住内核，很多地方也已经不是我最初设想的模样。我不知道自己这样做到底算务实，还是算对理想的退让。"
        menu:
            "你如何回应黎妤？"
            "认可这份现实的权衡":
                $ liyu_affection += 5
                $ affection_change = "+5"
                $ affection_target = ly_display_name
                show screen affection_change
                player_name "能在现实夹缝守住最重要的部分，已经很不容易。不必强迫自己做到完美无瑕。"
                $ affection_change = ""
            "提醒她不要过度消耗自己":
                $ liyu_affection += 7
                $ affection_change = "+7"
                $ affection_target = ly_display_name
                show screen affection_change
                player_name "守住底线的同时，也别把自己全部搭进去。你的感受同样很重要。"
                $ affection_change = ""
        ly "嗯。我会一边完成这份绘本，一边继续画私人创作，给自己留一块只属于我的小天地。"
        "春风吹起她的发丝，黎妤长长呼出一口气。绘本一事尘埃落定，但属于她的创作挣扎远远没有结束。你们小坐片刻之后互相道别。"
    else:
        # 好感不足50，没触发关键剧情
        scene bg lakeside_daze_ly at bg_top
        "湖边的柳树抽出嫩绿色新条。你路过湖边的时候，看见黎妤坐在熟悉的那张长椅上。"
        "她面前摊着平板，屏幕上还是《灯》的画面。她手指悬在屏幕上方，停了很久，没有落下去。"
        "你走过去。她抬头看到你，把平板翻过来扣在腿上。"
        ly "……你怎么来了。"
        player_name "路过。"
        "她点了点头，没有继续说下去。"
        "你在长椅另一侧坐下。她没有再翻平板，只是看着湖面。"
        "过了一会儿，她忽然开口。"
        ly "……最近在跟一个合作方拉扯，改来改去，有点烦。"
        player_name "很难谈吗？"
        ly "还好。我自己能处理。"
        "她说完这句，就不再往下说了。"
        "你没有追问。她也没有再提。"
        "你们坐了一会儿，各自看着湖面。风把她的碎发吹乱，她抬手把头发别到耳后。"
        "然后她站起来，说先回宿舍了。"
        "你看着她走远。她走得很慢，肩膀微微收着，像是在想什么。"
        "但你没有问。她也没有说。"

    # ————————————————————————————————————————————————
    # 黎妤线·关键剧情后续：根据 hold_idea / compromise 分别展开
    # 建议加值 +12
    # ————————————————————————————————————————————————
    if ly_important_flag == "hold_idea":
        scene bg sketch_three_ly at bg_top
        "几天后，黎妤约你去湖边。"
        "她坐在老位置上，面前摊着速写本，但没有在画。"
        "她手里捏着一支笔，笔尖悬在纸面上方，停了很久。"

        ly "……我最近一直在想一件事。"
        player_name "什么事？"
        ly "那个项目黄了之后，我反而松了一口气。"
        "她说完自己先愣了一下，像是没料到会说出这句话。"
        ly "很奇怪吧。明明是我第一个商业邀约，搞砸了，我却觉得轻松。"

        player_name "不奇怪。"
        player_name "你守住了自己想画的东西。那口气松下来，很正常。"

        scene bg sketch_two_ly at bg_top
        "黎妤看了你一会儿，然后把速写本翻到新的一页。"
        "她拿起笔，开始画。"
        "她画得很快，没有打草稿，线条直接落在纸上。"
        "你坐在旁边，没有打扰她。"
        
        scene bg sketch_drawing_ly at bg_top
        "画到一半，她忽然把速写本转过来给你看。"
        "画面上是一个女孩，站在一盏灯下。灯很小，光很暖。女孩手里举着相机，镜头朝外。"

        scene bg sketch_three_ly at bg_top
        player_name "这是……"
        ly "《灯》的新版。"
        ly "没有甲方，没有修改意见。我自己想画的样子。"

        "她把速写本收回去，又在角落补了一行小字。"
        "你没有看清她写了什么。她也没有主动给你看。"

        scene bg lakeside_spring at bg_top
        "那天下午，她画完了整整一页。"
        "合上速写本的时候，她长长呼出一口气。"
        ly "谢谢你那天跟我说的话。"
        ly "守住内核，比拿下一个项目难多了。"
        player_name "但你做到了。"

        "她笑了笑，把速写本塞回画包。"
        ly "嗯。我自己也知道。"

        $ liyu_affection += 12
        $ affection_change = "+12"
        $ affection_target = ly_display_name
        show screen affection_change
        $ affection_change = ""

    elif ly_important_flag == "compromise":
        scene bg dorm_sketch_one_ly at bg_top
        "几天后的一个下午，你回到宿舍。黎妤坐在书桌前，面前摊着两本速写本。"
        "一本是甲方项目的稿子，另一本是她自己的私人速写。"
        "两本并排摊开，中间隔着一支笔。"

        ly "你回来得正好。"
        "她朝你招了招手。"
        ly "你帮我看看，这两本放在一起，像不像两个人画的？"

        "你走过去，低头看。"
        "左边那本，线条工整，构图严谨，每一处都符合甲方要求。"
        "右边那本，线条随性，颜色大胆，有几页甚至只画了一半。"
        player_name "像两个人画的。"
        ly "对吧。"
        "她把两本速写本合上，叠在一起。"
        ly "这几天我一直在做一件事。"
        ly "把甲方要的稿子，和我自己想画的东西，分开放。"

        "她拿起笔，在左边那本封面上贴了一张便签。"
        "便签上写着两个字：工作。"
        "又在右边那本封面上贴了一张。"
        "便签上写着两个字：自己。"

        scene bg dorm_sketch_two_ly at bg_top
        ly "以前我总觉得，要么全部妥协，要么全部守住。"
        ly "但你说得对，可以在中间划一条线。"
        player_name "划出来之后呢？"
        ly "划出来之后，改稿的时候就不那么难受了。"
        ly "因为我知道，改完这一本，我还有另一本。"

        "她把右边那本速写本拿起来，翻到最新一页。"
        "那一页上画的是一个女孩，坐在长椅上。旁边空着一个位置。"
        player_name "这里怎么空着？"
        ly "还没画完。"
        "她看了你一眼，把速写本合上。"
        ly "以后再说。"

        "她把两本速写本分别放进两个不同的画袋。"
        "一个放在书桌左边，一个放在书桌右边。"

        $ liyu_affection += 12
        $ affection_change = "+12"
        $ affection_target = ly_display_name
        show screen affection_change
        "中间隔着一支笔，像一条线。"
        $ affection_change = ""

    else:
        # 好感不足50，没触发关键剧情，给一个轻量版后续
        scene bg sketch_three_ly at bg_top
        "几天后，你路过湖边，看见黎妤坐在长椅上。"
        "她面前摊着速写本，但没有在画。"
        "她看到你，朝你点了点头。"
        ly "……最近还好吗？"
        player_name "还行。你呢？"
        ly "老样子。改稿，画画，改稿。"
        "她说完，把速写本合上。"
        ly "没什么特别的。"

        scene bg lakeside_spring at bg_top
        "你们坐了一会儿，各自看着湖面。"
        "然后她站起来，说先回宿舍了。"

        $ liyu_affection += 5
        $ affection_change = "+5"
        $ affection_target = ly_display_name
        show screen affection_change
        "你看着她走远。她走得很快，没有回头。"
        $ affection_change = ""

    if huaixiaoshi_affection >= 50:
        scene bg desk_turn_off at bg_top
        "暮春的夜晚，天气已经有些热了。"
        "你睡得不太沉。半夜醒来，看到怀小柿的床铺空着。你侧头看了一眼，阳台的门虚掩着，门缝里透出一点光。"

        scene bg balcony_one_hx at bg_top
        "你披上外套，走到阳台门口。怀小柿站在栏杆边，手机屏幕的光映在她脸上。她没有在打字，只是看着屏幕。"
        "你站在门口，没有出声。"

        scene bg balcony_two_hx at bg_top
        "她听到动静，转过头。看到是你，她愣了一下。"
        hx "……我睡不着。"
        "你把门推开一点，走到她旁边。两个人站在阳台上，看着楼下的路灯。"
        "过了一会儿，她开口了。"
        hx "……有些话，我想，我该全部跟你说清楚。"

        menu:
            "此为关键剧情，建议游玩前先存档。"
            "侧过身认真听她诉说":
                $ huaixiaoshi_affection += 5
                $ affection_change = "+5"
                $ affection_target = hx_display_name
                show screen affection_change
                "你侧过身，安静地望向她，示意自己会认真听。"
                $ affection_change = ""

                hx "网上写《桃溪村的夏天》的作者柿柿如意……是我。"
                "她停了停，指甲在手机壳边缘刮过。"
                hx "校刊那件事之后，你应该早就猜到了。"
                hx "我一直没敢正面承认过。"
                hx "但有一件事，我连你都没告诉——这本书里写的女主原型，是谁。"

                "一条小说平台的作品链接，悄悄发送到你们的私聊对话框。"
                "你点开链接。页面跳到小说主页，目录很长。你往下翻，翻到最新一章，然后停住了。女主的名字，和你一样。"

                player_name "所以，书里的女主原型是我。"

                scene bg balcony_three_hx at bg_top
                "怀小柿的肩膀绷紧，手指攥住栏杆。她没有躲开你的目光，声音压得很低。"
                hx "嗯。"

                "你把手机还给她。屏幕还亮着。"
                player_name "我不会说出去。"
                player_name "你慢慢写。我不催。"
                player_name "你的文字很温柔，我很喜欢。"

                "隔了片刻，她才开口。"
                hx "……你是第一个这么说的人。"
                player_name "说什么？"
                hx "说喜欢我的文字。"
                "她顿了顿。"
                hx "江枫也看过。但她只说‘写得不错’。你是第一个说‘喜欢’的。"

                "她没有说谢谢。但她攥着栏杆的手指，松开了一点。"

                hx "期末那篇短篇作业，最后我没有向校刊投稿。我不敢冒那个风险。可这件事让我反复在想——《桃溪村的夏天》里面写的故事，哪些是真实发生，哪些只是我一厢情愿的幻想。"
                hx "书里面的女主，原型就是你。那个总是陪在女主身边、沉默内向的女孩子，是幻想化的我自己。"
                hx "当年你家是最早搬离桃溪村的。你搬走的时候我年纪还小，只记得村里有个爱拍照的姐姐，后来就不见了。"
                hx "你搬走之后，江枫一家才搬去村西，成为我的发小。"
                hx "我那时候，就常常一个人坐在田埂，远远望着村东的老槐树，看着二牛、二狗在树下玩耍。我没有真正参与你们的嬉戏打闹。书里那些我们一同疯跑玩耍的片段，全部都是我坐在田埂之上脑补出来的画面。"
                hx "江枫清楚全部内情，她通读我的小说，分得清现实与幻想，会替我守住秘密。写小说，其实是在弥补我童年那份求而不得的遗憾。"
                hx "我很害怕，如果这些幻想被熟人看见，大家会怎么看待我。"

                $ hx_shared_novel_origin = True
                player_name "原来……是这样。"
                hx "可上了大学真正和你相识相处之后，曾经只存在文字幻想里面的羁绊，变成了现实。我心里的感觉，也早就不再仅仅只是对童年的念想。"

                scene bg balcony_four_hx at bg_top
                "她说完了。阳台上很安静。你看着她。她的眼睛有点红，但没有哭。"
                "她忽然笑了一下。那个笑很轻，像是一块石头从肩上落下来。"
                hx "我写了三年。写了三十多万字。但我从来不敢给任何人看。"
                hx "你是第一个。"
                hx "所以……如果你觉得不好看，也告诉我。我不会删。但我需要知道。"

                "她没有把话说死，只把朦胧的情愫轻轻放在你们之间，没有逼你给出答复。"
                "你站在阳台上，看着她的侧脸。你忽然想起她在宿舍里一次次把手机扣下、又一次次把屏幕推到你面前的样子。"
                "她大概也在等。"

            "表示现在太疲惫，希望改天再说":
                $ huaixiaoshi_affection += 3
                $ affection_change = "+3"
                $ affection_target = hx_display_name
                show screen affection_change
                "你轻声说现在太疲惫，希望改天再听她说。怀小柿神色黯淡，默默转过身，没有再开口。"
                $ hx_novel_delayed = True
                $ affection_change = ""
        $ renpy.block_rollback()

        scene bg dorm_morning at bg_top
        "第二天早上，江枫在阳台晾衣服。怀小柿走过去，站在她旁边。"
        "江枫没回头，只是把一件衬衫抖开，挂在衣架上。"
        jf "你跟她说了？"
        hx "……嗯。"
        jf "她怎么说？"
        hx "她说……她喜欢我的文字。"
        "江枫顿了一下，把衣架挂上晾衣杆。"
        jf "那就行了。"

    # ————————————————————————————————————————————————
    # 黎陌尘线·关键剧情前置：春日琴房
    # 无条件触发，给玩家保底加值，确保能进关键剧情
    # 建议加值 +12
    # ————————————————————————————————————————————————

    play music "music/夏日Romantic Night.MP3" fadein 1.0

    scene bg teaching_building_dusk at bg_top
    "三月底的一个傍晚，你路过教学楼。"
    "二楼的琴房亮着灯，门虚掩着。"

    scene bg piano_room_evening at bg_top
    "你本来只是路过。但琴声传出来的时候，你的脚步慢了半拍。"

    "你站在门口听了一会儿。"
    "是一首很简单的练习曲。左手伴奏，右手旋律，节奏平稳。"
    "但弹到第三遍的时候，右手在某一个小节上卡了一下。"
    "然后他停下来，从头开始。"
    "又弹到那个地方，又卡了一下。"
    "第三次。他叹了口气。"

    lm "……进来吧。"

    "你推开门。"

    scene bg piano_room_spring_one_lm at bg_top
    "黎陌尘坐在琴凳上，手指还停在琴键上。看到你，他没有意外，也没有停。"
    "你走进去，坐在旁边的椅子上。"
    "他面前摊着谱纸，页角卷了边。谱纸上有几处用铅笔圈出来的地方，其中一处被反复描了好几遍。"

    lm "这首曲子不难。"
    lm "但这一段我总是弹不好。"

    "他重新把手放回琴键，弹了一遍。"
    "到那个小节的时候，他的右手顿了一下。"
    "只是一个很小的停顿，几乎听不出来。"
    "但他自己听出来了。"
    "他把手收回来，放在膝盖上。"

    scene bg piano_room_spring_two_lm at bg_top
    lm "……我很久没有上台了。"
    player_name "你不想上台吗？"
    lm "不是不想。"
    "他顿了顿。"
    lm "是不知道该怎么上去。"

    "他没有继续说下去。"
    "你也没有追问。"
    "你们坐在琴房里，听着窗外的风声。"

    menu:
        "你准备怎么回应他？"
        "告诉他，不上台也没关系":
            $ limichen_affection += 12
            $ affection_change = "+12"
            $ affection_target = lm_display_name
            show screen affection_change
            player_name "不上台也没关系。"
            $ affection_change = ""

            player_name "弹给自己听，也是弹琴。"
            scene bg piano_room_spring_three_lm at bg_top
            "黎陌尘看了你一眼。"
            "他没有说话，但他的手从膝盖上收回去，重新放回琴键上。"
            "他弹了一小段。"
            "这次没有卡。"
            "弹完之后，他把谱纸合上。"
            lm "……谢谢。"

        "问他四月有没有演出":
            $ limichen_affection += 10
            $ affection_change = "+10"
            $ affection_target = lm_display_name
            show screen affection_change
            player_name "四月是不是有春季音乐沙龙？"
            $ affection_change = ""
            
            scene bg piano_room_spring_three_lm at bg_top
            "黎陌尘的手指在琴键边缘停了一下。"
            lm "……你怎么知道？"
            player_name "黎妤提过一句。"
            lm "嗯。辅导员找过我。"
            "他把谱纸翻过去，盖住刚才圈出来的地方。"
            lm "我还没决定。"
            player_name "那就慢慢想。"
            "他点了点头，没有再说话。"

        "不说话，陪他坐一会儿":
            $ limichen_affection += 8
            $ affection_change = "+8"
            $ affection_target = lm_display_name
            show screen affection_change
            "你没有说话。你坐在旁边，把相机放在腿上。"
            $ affection_change = ""

            "他也没有再弹。"
            "两个人坐在琴房里，一直到天色完全暗下来。"
            "他站起来，合上琴盖。"
            lm "……走吧。"
    $ renpy.block_rollback()

    scene bg dorm_evening at bg_top
    "你回到宿舍。黎妤正坐在桌前翻画册。"

    scene bg dorm_sketch_two_ly at bg_top
    "她抬头看了你一眼。"
    ly "你去琴房了？"
    player_name "嗯，路过。"
    ly "我哥最近老往琴房跑。"
    ly "他说在练一首曲子，但是不给我听。"
    "她翻过一页画册，语气很随意。"
    ly "你说他是不是有什么事瞒着我。"
    player_name "应该没有吧。"
    ly "……算了。"
    "她合上画册，没有再问。"
    
    if limichen_affection >= 50:
        scene bg teaching_building_morning at bg_top
        "三月过去，四月来了。校园里的花陆续开了。"
        "校内举办无竞赛性质的春季音乐沙龙，不排名、不评奖，只做演奏分享。辅导员诚挚邀请黎陌尘登台。"
        "一份初中钢琴比赛的旧纪念相册被老同学辗转发给黎陌尘，尘封的创伤记忆被刺痛。夜里，钢琴练习室里，你收到黎陌尘发来的消息，问你是否有空过去一趟。"

        scene bg piano_room_evening_two_lm at bg_top
        "练习室只开着钢琴上方的一盏射灯，桌面上摊开旧纪念相册。黎陌尘坐在琴凳上，神色低落。看见你推门进来，他没有回避。"
        lm "老同学把这个相册发给我，翻到初中参赛那一组照片，很多已经快要压下去的回忆，又全部涌上来。"
        lm "我一直避开所有竞技类钢琴比赛。当年那场比赛，我的原创曲子，被敬重的指导老师挪用改编，当做他本人的作品拿去参赛。我出面提出异议，最后反而被周围人指责晚辈不懂尊师重道。没有人愿意站在我这边。"
        lm "那之后，我畏惧站上赛场，畏惧打分、畏惧评判。但是音乐本身我没有放弃。只是，我不再愿意把我的演奏交给赛场的评委。这次春季音乐沙龙，没有竞争，不分高下。我在犹豫，要不要登台。"
        menu:
            "以下两个选择分别影响黎陌尘的结局，建议游玩前先存档。"
            "鼓励他去沙龙做纯粹的演奏，不必强迫自己":
                $ limichen_important_choice = "encourage"
                $ limichen_affection += 5
                $ affection_change = "+5"
                $ affection_target = lm_display_name
                show screen affection_change
                player_name "沙龙没有竞赛评判，只为抒发自己。如果你内心愿意，就去；如果做不到，不去也完全没有错。"
                $ affection_change = ""
            "劝他依旧不要冒险登台，保护自己":
                $ limichen_important_choice = "protect"
                $ limichen_affection += 5
                $ affection_change = "+5"
                $ affection_target = lm_display_name
                show screen affection_change
                player_name "旧伤还没有完全平复，不必勉强自己站到众人目光之下，保护好自己更重要。"
                $ affection_change = ""
        lm "谢谢你愿意听我说这些。这些事情，我连黎妤，都没有讲得这么细。"
        $ limichen_shared_piano_past = True
        "他指尖抚过琴键，弹奏一小段舒缓忧伤的旋律。伤疤没有彻底和解，但他向你袒露了创伤的碎片。"

        ## 春季音乐沙龙·当天
        scene bg concert_hall at bg_top
        "沙龙定在四月的一个周六下午。地点是学校音乐厅的小演奏厅，能坐两百来人。"
        "你提前到了。第三排靠左边的位置，你坐下的时候，台上还空着。"

        scene bg concert_hall_people at bg_top
        "观众陆续进场。有音乐系的学生，有被朋友拉来的外系生，也有几个老师模样的中年人坐在前排。人不多，但座位几乎坐满了。空气里有一种安静又克制的期待。"

        "节目单是一张薄薄的纸。你低头看了一眼。"
        "黎陌尘的名字排在第七个。曲目栏里写着一行字：《未命名》。"

        "前面六个节目依次过去。有人弹肖邦，有人拉大提琴，有人唱了一首外国艺术歌曲。"
        "掌声不热烈，但很干净。每一个上台的人下来的时候，脸上都带着一点松了肩膀的神情。"
        "你一直看着侧台的方向。帘子后面，一个清瘦的身影在那里站了很久。"
        "轮到他的时候，主持人念出他的名字。"

        scene bg concert_hall_one_lm at bg_top
        "黎陌尘从侧台走出来。他今天穿了一件深灰色的衬衫，袖口挽到手腕，头发梳得很整齐。灯光打在他身上，他的睫毛垂着，视线落在琴键上，没有看台下。"
        "你忽然想起来，你从来没有见过他站在舞台中央的样子。你见过他在琴房里、在射灯下、在门缝后面，但那都不是舞台。这是舞台。台下坐着两百个人，而他一个人站在中间。"

        scene bg concert_hall_two_lm at bg_top
        "他在琴凳上坐下。手指悬在琴键上方，停了两秒。那是起手。你终于看见他完成了一次完整的起手。"
        "第一个音落下去。"
        "琴声很轻。旋律是你听过很多次的那一段。在琴房里，在门缝后面，你听过他一次又一次弹这首曲子。每一次，弹到某个地方，他就会停下来。"
        "手指从琴键上收回来，放在膝盖上。然后重新开始。你数不清听过多少次那样的停顿。"
        "但这一次，没有停。"
        "琴声一直往前走。走过那个他一直停下来的地方。"
        "第二段。"
        "你以前从来没有听过这一段。他的手在琴键上移动，很慢，很稳。有一段旋律忽然低下去，像一个人把一句话咽回去。然后又抬起来。再低下去。再抬起来。"
        "你忽然想起来，他说过这首曲子是写给一段路的。不是写给终点。你现在听出来了。那不是一段完整的路。那是一个人走过一段路之后，回头看的样子。"
        "最后一个音符落下去。他没有立刻收手。手指还停在琴键上，等那一点余音散尽。台下安静了两秒。然后掌声响起来。"
        "不是雷鸣般的，不是狂热的。是那种，听完之后真心想鼓的掌。前排那几个老师模样的中年人互相看了一眼，有人点了点头。"

        scene bg concert_hall_three_lm at bg_top
        "黎陌尘站起来，朝台下鞠了一躬。他抬起头的时候，视线扫过观众席。"
        "你坐在第三排，靠左边。你确定他看到你了。"
        "因为他那一眼停了一瞬。然后他转身走下台。背影很直，脚步很稳。"

        scene bg concert_hall_people at bg_top
        "沙龙下半场你没有怎么看进去。你坐在位置上，耳边是别人的琴声，脑子里还是那首曲子。尤其是第二段。"
        "散场之后，观众陆续往外走。你没有走。你坐在位置上，看着工作人员收拾谱架。然后你看见他从侧台出来。"
        "他手里拿着那张节目单，折了一次，又展开，又折回去。"

        scene bg concert_hall_four_lm at bg_top
        "他走到你这一排的边上的时候，停了下来。"
        "他没有坐下。他站在过道里，看着你。"

        lm "……你没走。"
        player_name "没走。"

        "他低头看了一眼手里的节目单，把它折成四折，塞进口袋。他没有说谢谢，也没有问你听完觉得怎么样。他只是站在那里，像是不知道该往哪走。"

        lm "那首曲子。"
        lm "第二段，我今天弹出来了。"

        player_name "我听出来了。"

        "他点了点头。没有解释。也没有追问。但你看得出来，他松了一口气。"
        "那种松，不是彻底放下了什么，而是把一直提着的一口气，终于呼了出来。"

        lm "……走吧。"
        "他朝门口的方向抬了抬下巴。你站起来，跟着他往外走。"

        scene bg concert_hall_doorway at bg_top
        "外面天还亮着。音乐厅门口的梧桐树叶子已经很密了。你们并肩走了一段路。谁也没有先开口。"

        scene bg dorm_downstairs_evening at bg_top
        "走到岔路口的时候，他停下了脚步。他好像想说什么。"
        "但他只是把口袋里那张折成四折的节目单掏出来，又看了一眼，然后又塞回去。"

        lm "你先回去吧。"
        lm "我还想去琴房坐一会儿。"
        player_name "好。"

        scene bg concert_hall_five_lm at bg_top
        "他点了点头，转身朝教学楼的方向走了。你站在原地看了一会儿。"
        "他的背影在梧桐树影里走得很慢，肩膀比平时松了一些。"
        "你忽然想起来，今天是四月的一个周六。去年的这个时候，你还不认识他。"
        "但现在你知道了，他有一首写了三年的曲子。而今天，他终于把那首曲子弹完了。"

        ## 沙龙之后·琴房
        scene bg piano_room_morning at bg_top
        "春季音乐沙龙结束之后的某天，你路过琴房。门开着。"

        scene bg piano_room_spring_four_lm at bg_top
        "黎陌尘坐在钢琴前。他没有弹。他面前摊着那本旧相册。"
        "你站在门口。他抬起头。"
        lm "进来吧。"
        "你走进去。他把相册合上，推到一边。"
        lm "那天沙龙，谢谢你坐在第三排。"
        player_name "你怎么知道是第三排？"
        lm "……我数了。"
        "他没有立刻接话。过了一会儿，他把相册重新拿回来，翻开其中一页。"
        
        scene bg piano_room_album_lm at bg_top
        "那一页是一张照片。初中比赛的。他站在台上，手里拿着奖杯。"
        "照片背面写了一行字。"
        lm "我一直以为，那是我最后一次上台。"
        "他把相册合上。"
        lm "但现在好像不是。"
        menu:
            "问他以后还会不会参赛":
                $ limichen_affection += 5
                $ affection_change = "+5"
                $ affection_target = lm_display_name
                show screen affection_change
                player_name "以后还会参加比赛吗？"
                $ affection_change = ""

                scene bg piano_room_spring_four_lm at bg_top
                "他想了想。"
                lm "不知道。"
                "他停了一下。"
                lm "但至少……不排斥了。"
            "不说话，只是陪他坐一会儿":
                $ limichen_affection += 8
                $ affection_change = "+8"
                $ affection_target = lm_display_name
                show screen affection_change
                "你没有问。你坐在旁边，把相机放在腿上。"
                $ affection_change = ""

                scene bg piano_room_spring_four_lm at bg_top
                "他也没有再说话。你们坐了很久。"
    else:
        scene bg teaching_building_dusk at bg_top
        "四月的一个傍晚，你路过教学楼。"
        "二楼的琴房亮着灯。门虚掩着，里面传出钢琴声。"
        "你本来打算直接走过去。脚步却在台阶边慢了一拍。"

        "你站在楼下听了一会儿。"
        "是一首很慢的曲子。弹到一半，停了。"
        "过了一会儿，又重新开始。"
        "还是那首曲子。弹到同一个地方，又停了。"

        "你没有上去。"
        "你想起黎妤说过，她哥最近一直在琴房写曲子。你不知道他在写什么，你也没有问。"

        scene bg classroom at bg_top
        "第二天上课，黎陌尘坐在前排靠窗的位置。他面前摊着谱纸，手指在桌面上轻轻敲着。"
        "谢旻凑过去看了一眼，问他在写什么。"
        "黎陌尘把谱纸翻过去，说没什么。"

        "你从他们旁边走过。黎陌尘抬头看了你一眼，微微点头。"
        "你也点了点头。"
        "就这样。"

        "你没有听过他弹完那首曲子。"
        "你只知道，他一直在写。"
        "写了很久。"
        "但你不知道那首曲子叫什么。"
        "你也没有问。"

        "四月的音乐沙龙，你后来听黎妤提过一句。"
        "她说她哥没有去。"
        "你说，哦。"
        "然后你们聊了别的事。"

        "那首曲子，你没有听过完整的版本。"
        "你只知道，它一直停在同一个地方。"
        "像一个人走到门口，又退了回去。"

    if qianrao_affection >= 50:
        scene bg teaching_building_morning at bg_top
        "春日渐深。你手上已经积攒起许多碎片化线索：桃溪村记忆、槐树下的失神瞬间、寒假回乡时从凌晨那里得到的暗示，以及牵绕在线下线上一次次刻意的回避。寒假拍下的桃溪村老槐树照片，还保存在你的相机相册里。"
        
        scene bg pagoda_tree at bg_top
        "某天傍晚，你们赴之前约定好的春日外景拍摄，走到校园那棵老槐树下。槐花开得漫天纷飞，白色花瓣簌簌飘落。"
        menu:
            "此为关键剧情，建议游玩前先存档。"
            "把桃溪村老槐树照片展示给他，直面摊开所有疑点":
                player_name "寒假我回了一趟桃溪村过年。这是村东那棵老槐树。"
                "你把相机屏幕转过去，照片上，冬日的老槐树枝干光秃，石竹椅蒙着一层薄灰。"
                player_name "这么多细碎的巧合，我很难继续当作只是偶然。"
                "你深吸了一口气。"
                player_name "牵绕。你就是刘二狗，对不对。"

                scene bg pagoda_tree_one_q at bg_top
                "春风吹落槐花。牵绕脸上玩世不恭的笑意一点点褪去。他没有立刻接话，视线落在相机屏幕上那棵光秃秃的老槐树上，像是被什么东西钉住了。"
                "他沉默了很久。然后他笑了一下。不是平时那种散漫的笑，是那种‘被你发现了’的、带一点无奈的笑。"
                q "……行吧。"

                $ qianrao_affection += 5
                $ affection_change = "+5"
                $ affection_target = q_display_name
                show screen affection_change
                q "我就是刘二狗。"
                $ affection_change = ""

                "他说完这三个字，像是松了一口气，又像是更紧张了。"
                q "你别用那种眼神看我。二狗这名字太土了，我自己改的。牵绕——牵挂着，绕着走。挺好。"
                "他说“挺好”的时候，没有看你。"
                "你忽然明白，他不是觉得“挺好”。他是觉得，除了“绕着走”，他不知道还能怎么办。"
                "你想起凌晨在图书馆说的那句话。"
                lc "你走的那天，二狗在树下坐了整整一个下午。奶奶叫他吃饭，他也没动。"
                "你看着眼前这个站在槐花雨里的少年。当年那个在树下坐了一整个下午的男孩，和现在这个把名字改成“牵绕”的人，慢慢重叠在一起。"
                player_name "凌晨跟我说过一件事。"
                "牵绕的指尖在相机边缘停了一下。他没有问是什么事，但他也没有走。"
                player_name "他说，我搬走那天，你在老槐树下坐了整整一个下午。"
                "牵绕脸上的表情没有变，但他的喉结动了一下。"
                player_name "他说你走之前没跟任何人道别。"

                scene bg pagoda_tree_two_q at bg_top
                "槐花落在牵绕的肩头。他没有拂掉。"
                q "……他倒是记得清楚。"
                "他的声音很轻，像是不想被风吹散。"
                q "你搬走的时候，我在那棵树下坐了一下午。我那时候在想，你是不是也会回来。"
                "他顿了顿。"
                q "后来我家也出了事，搬得比你还急。走的那天，我连去跟二牛说一声都来不及。"
                "他低下头，看着脚边的槐花。"
                q "再后来，我们见过一次。但那时候，已经跟小时候不一样了。"
                "你没有追问‘不一样’是什么意思。你想起凌晨缠耳机线的动作，一圈一圈，缠得很慢。"
                player_name "所以你把名字改成牵绕。"
                q "……嗯。"
                "他抬起眼，这一次他看你了。"
                q "牵挂着，绕着走。有些东西，我没法面对，那就绕着走。"
                "他说这句话的时候，语气很平。但你知道，这句话他大概在心里练了很多年。"
                q "关于当年我为什么离开桃溪村，那些事……我还没准备好讲。"
                q "我承认身份，不代表所有往事都能一笔勾销。"
                $ qianrao_admitted_identity = True
                "身份与出身终于得到承认，但童年心结仍被留在沉默之后。"

                "你想起凌晨说过，他的网站有一部分是为刘二狗建的，但刘二狗永远不会来看。"
                "此刻你站在牵绕面前，忽然很想问他：如果有一个网站，记录了当年桃溪村的所有夏天，你会去看吗？"
                "但你没有问出口。因为你知道，他现在还不会回答。"
                
                scene bg pagoda_tree_three_q at bg_top
                "他伸手从肩头拈起那片槐花，捏在指尖看了一会儿，然后松手，让风把它带走。"
                q "行了，别站着了。你相机还举着呢。"
                "他重新摆好姿势，脸上恢复了一点平常的散漫。但你知道，刚才那几句话，已经是他能给出的最大限度的坦白。"
                "你们之间的气氛一时僵持，又比刚才多了一点说不清的东西。"
            "依旧不直接点破，只借着槐花与春日聊摄影外景":
                player_name "今天的槐花和光线都很好，正适合拍一组春日外景。"
                scene bg pagoda_tree_two_q at bg_top
                q "今天的光线很不错。"
                "你们完成人像拍摄。虽然没有挑明，牵绕心里清楚你已经掌握了大量线索；那颗悬着的炸弹没有引爆。"
                "但你注意到，他站在槐树下的时候，肩膀比平时绷得更紧。像是这棵树本身，就让他不自在。"
    else:
        # ————————————————————————————————————————————————
        # 低好感兜底：不摊牌，但玩家能确认牵绕在回避
        # ————————————————————————————————————————————————
        scene bg teaching_building_morning at bg_top
        "春日渐深。校园里的树陆续抽了新芽。"
        "你约牵绕拍一组春日外景。他答应了，约在图书馆后方那条林间小路。"

        scene bg pagoda_tree at bg_top
        "路两边的树还没完全绿透。走到一半，前面出现一棵老槐树。"
        "槐树刚抽芽，枝干还是光秃的。"
        "牵绕的脚步慢了半拍。只是一瞬。随后他恢复如常，抬手指向树冠。"

        q "这里光线还行。拍几张吧。"

        scene bg pagoda_tree_two_q at bg_top
        "你举起相机。取景框里，他站在树下。"
        "你按下快门。"
        "他配合得很好。姿势、角度、表情都挑不出错。"
        "但你注意到，他一直没有靠近那棵树。"
        "他站在树荫外面，隔了一步的距离。"

        "拍完。你们收拾东西往回走。"
        "他一路在聊别的事。社团、期末、你最近拍了什么。"
        "你几次想把话题往桃溪村引，他都轻巧地绕开了。"

        "走到岔路口，他停下脚步。"
        q "今天拍得不错。修好了发我。"
        player_name "嗯。"

        scene bg dorm_downstairs_morning at bg_top
        "他挥了挥手，转身走了。"
        "你站在原地，看着他的背影。"
        "你忽然想起那个名字——刘二狗。"
        "你没有问。他也没有说。"
        "有些问题，你隐约知道答案。"
        "但你没有把最后一层纸捅破。"

        scene bg desk_turn_on at bg_top
        "那天晚上，你把照片导进硬盘。"
        "其中一张里，他站在老槐树旁边。"
        "距离很近，但没有碰到树。"
        "你把这张照片放大看了看。"
        "然后你把它放在文件夹里，没有命名。"

    # ————————————————————————————————————————————————
    # 牵绕线·关键剧情后续：天台
    # 只有摊牌后才触发，给玩家一个更近的互动
    # 建议加值 +10
    # ————————————————————————————————————————————————
    if qianrao_admitted_identity:
        scene bg dorm_morning at bg_top
        "摊牌之后，牵绕有几天没有主动联系你。"
        "你发朋友圈，他还是第一个点赞。但没有再发过消息。"
        
        scene bg dorm_afternoon at bg_top
        "某天傍晚，你收到他发来的一条微信。"
        q "教学楼天台。来一下。"

        scene bg teaching_block_tt1_q at bg_top
        "你上了天台。他靠在栏杆边，手里拎着两瓶汽水。"
        "看见你，他把其中一瓶递过来。"
        q "拿着。"

        "你接过来。瓶身是凉的。"

        scene bg teaching_block_tt2_q at bg_top
        "你们并肩靠在栏杆上，看着楼下的操场。"
        "过了一会儿，他开口。"

        q "那天在老槐树下说的那些，你别往外说。"
        player_name "我知道。"
        q "……不是怕丢人。"
        "他喝了一口汽水。"
        q "是还没准备好。"

        "你没有追问。"
        "你们站在天台上，看着天色一点点暗下去。"
        "操场上有人跑步，脚步声一圈一圈传上来。"

        q "你下次拍照，带我一个。"
        player_name "你不是不爱拍照吗？"
        q "……现在爱了。"

        "他说完，把汽水瓶搁在栏杆上。"

        $ qianrao_affection += 10
        $ affection_change = "+10"
        $ affection_target = q_display_name
        show screen affection_change
        "没有再解释。"
        $ affection_change = ""

    $ renpy.block_rollback()

    scene bg dorm_morning at bg_top
    "数周缓缓流逝。江枫和谢旻持续打磨原创词曲，写出新片段，又一次次推翻重写，困在创作瓶颈之中反复挣扎。"
    "凌晨不断完善承载回忆的个人网站，上传更多桃溪村老照片、旧录音。他依旧刻意和牵绕保持距离，二人几乎零交集。"
    "小莱身体状态时好时坏，一边调理身体，一边按节奏完成课业，慢慢找到属于自己的生活节奏。"
    "校园花开花落，草木从嫩芽转为繁茂浓绿。日子一天天过去，期末越来越近。"
    
    # ————————————————————————————————————————第七章————————————————————————————————————————
    play music "music/黑胶慢绪.MP3" fadein 1.0

    scene bg teaching_building_corridor at bg_top
    "期末考试陆续结束。"
    "初夏的风穿过校园，把最后一批梧桐絮吹散在空气里。"

    scene bg dorm_evening at bg_top
    "期末考结束的那天傍晚，你把相机里最后一张照片导进硬盘。屏幕跳出来一行提示文字——存储空间已满。"
    "你盯着这行字，安静愣了好一会儿。你点开相册，从第一张开始往后翻。"
    "一年前报到那天香樟树下的牵绕，攥着行李箱，指节泛白。"
    "这一年里，琴房射灯下独坐的黎陌尘，手指悬在琴键上方；湖边写生时马尾高高束起的黎妤，铅笔停在纸面；怀小柿低头系鞋带，左边辫子上的珠子轻轻晃。"
    "凌晨网站上那棵桃溪村老槐树，树下一把旧竹椅。窗边埋首地方志的小莱，发梢垂在书页上。舞台上遥遥相望的江枫与谢旻，中间隔着一小段灯光。"
    "你翻到最后一张。是七个人第一次吃饭时请人拍的合照。你站在江枫和怀小柿中间，一边肩膀微微歪着。"
    "你看了很久，然后合上电脑。硬盘可以换更大的，也可以把旧照片刻成盘，再腾出空间。但你心里清楚，满的不只是硬盘。"

    scene bg playground_stand_evening at bg_top
    "那天晚上，你一个人走到操场看台上，坐了很久。"
    "操场上没什么人。远处有几个学生在跑步，跑道边有个女生在压腿，看台上另一边坐着一对情侣，靠着栏杆聊天。你举起相机，随手拍了几张。然后放下相机，翻看相册。"
    "你忽然想起八岁那年，父亲把相机塞进你手里时说的那句话。"
    fq "你以后会遇到很多人。能记住一个是一个。"
    "你一直以为，这句话是在告诉你——要好好记录别人。但现在你忽然觉得，也许父亲想说的是另一件事。你能记住的人，是有限的。如果你只待在一个地方，你只能记住这个地方的人。"
    "你想去很多地方。拍很多人。不只是学校里的人。街上的、村子里的、城市里的。所有真实活着的人。"
    "这个念头其实很早就有。从你第一次举起相机开始，从你拍下第一个陌生人开始。只是大学生活太满，太热闹，让你把这件事往心底压了压。"
    "现在它自己浮上来了。你在看台上坐到天黑透，然后打开手机，给家里打了一个电话。"
    "接电话的是母亲。她听到你说期末考完了，先问累不累，又问什么时候回家。你没有绕弯子。"
    player_name "妈，我想休学一年。"
    "电话那头安静了几秒。你听见母亲把电视声音关小，然后才开口。她没有立刻反对，也没有立刻同意。"
    mq "为什么？"
    player_name "我想出去走走。拍东西。不是旅游那种，是认真走一段路，拍一段路。"
    mq "学业怎么办？回来之后跟得上吗？"
    player_name "我问过教务，休学一年可以保留学籍，回来重读大二。课可以补。"
    "电话那头又沉默了一会儿。然后你听见父亲的声音从旁边传过来，像是凑近了话筒。"
    fq "相机带了吗？"
    player_name "带了。"
    fq "旧的那台？"
    player_name "带了。"
    fq "路上别弄丢。"
    "母亲在旁边叹了口气，语气里带着无奈，但已经没有刚才那么紧了。"
    mq "你从小就是这样。想好了才说。我们拦也拦不住。"
    "她顿了顿。"
    mq "钱够不够？"
    player_name "攒了一些。路上省着用。"
    mq "不够就说。别硬撑。"
    "挂电话之前，父亲又补了一句。"
    fq "记得往家里打电话。"
    "你应了一声。电话挂断之后，你在看台上又坐了一会儿。风从操场那头吹过来，带着初夏夜晚的热气。"

    scene bg office_fd at bg_top
    "第二天上午，你去了辅导员办公室。"
    "辅导员听完你的来意，先翻了翻你的成绩单，又看了看你。"
    fd "成绩没问题。你确定要休学一年？不是休学一学期？"
    player_name "一年。我想走远一点。"
    "她放下成绩单，靠在椅背上，看了你几秒。"
    fd "理由呢？"
    player_name "想出去拍照。拍人，拍地方。不是课程实践那种。"
    "辅导员没有立刻接话。她拿起笔，在你名字旁边画了一个圈。"
    fd "学校规定，休学需要家长知情同意。你父母那边沟通过了吗？"
    player_name "昨晚打过电话。他们同意了。"
    "她点了点头，从抽屉里抽出一张表格推到你面前。"
    fd "填这个。下学期开学前交给我。学籍保留，回来之后跟着下一届读大二。"
    "你把表格收好。起身要走的时候，她叫住你。"
    fd "等一下。"
    "你回头。"
    fd "你回来的时候，还是想继续读文学系吗？"
    "你想了想。"
    player_name "想。文学和摄影，不冲突。"
    "辅导员看了你两秒。"
    fd "你知道文学系回来要补多少课吗？"
    player_name "知道。"
    fd "你大二重读，同届的人都大三了。你原来的室友，到时候可能已经不在一个班了。"
    "你沉默了一下。"
    player_name "我知道。"
    "辅导员没有再劝。她把表格推到一边，拿起笔，在你名字旁边画了一个圈。"
    fd "行。去吧。"
    fd "回来的时候，记得带几张照片给我看看。"

    scene bg teaching_building_corridor at bg_top
    "从办公室出来，你在走廊上站了一会儿。申请表在手里被风吹得轻轻翻动。"
    "现在是最后一个步骤了。"
    "你打开手机，点开汴大七人组的群聊对话框。"

    player_name "我打算休学一年，出去走走。"

    "群聊陷入几秒彻底的安静，没有人弹出消息。"
    ly "？？？"
    ly "你要去哪？"
    player_name "不知道。走到哪算哪。"
    "屏幕又沉寂下来。对话框上方“对方正在输入”反复闪烁，又消失。"
    "隔了片刻，江枫发来消息。"
    jf "什么时候走？"
    player_name "下周。"
    "谢旻发来了一个摊手无奈的表情包。紧接着，他单独给你发了一条私聊。"
    xm "认真的？"
    player_name "认真的。"
    xm "……行吧。你这种人不拦你。拦了你也走。"
    "群里怀小柿只敲出一个句号。但那天深夜，你收到她单独发来的一条消息。"
    hx "你走了之后，我还能把小说发给你看吗？"
    player_name "能。"
    hx "嗯。"
    "凌晨的头像亮着，始终没有在群里输入任何文字。第二天早上，你打开摄影账号，发现新增了一条私信。"
    "发信人 ID 是「不想忘」。"
    "私信里只有一个链接，是你之前去过的校园湖边长椅。链接下面附了一行极小的字。"
    "「这张没拍好。下次重拍。」"
    "最后，黎陌尘的消息出现。"
    lm "走之前，一起吃个饭。"

    scene bg barbecue at bg_top
    "一周之后的夜晚，七个人再一次坐在校外那家烧烤小店。和军训结束那晚是一模一样的位置，两张桌子拼在一起。"
    "只是今晚的氛围，已经不再是当初少年人刚相逢时肆意喧闹的欢喜。空气里裹着一层淡淡的离别重量。"
    if ly_important_flag == "hold_idea":
        "黎妤眼底藏着一点还未完全消散的失落，却依旧努力扬起笑意。"
    else:
        "黎妤眉宇间带着长期修改稿件带来的疲惫，但眼神已经比春天松弛许多。"
    "黎妤反反复复向你发问，问你什么时候回来。一遍又一遍，每问完一次，她自己先苦笑一声，隔几分钟，又忍不住再问一遍。"
    "江枫话不多，手上却一直在忙。你的玻璃杯只要空掉，她就立刻给你添满，哪怕杯子里还剩大半的凉水，也会拿起水壶往里面续。"
    "谢旻讲了一大堆天马行空的笑话，哄着饭桌的气氛。每一阵哄笑落下去之后，他又会短暂陷入沉默。他把一串烤年糕放到你的餐盘里。"
    xm "这个好吃，外面路上很难吃到。"
    "怀小柿缩在座位最靠里的角落，安安静静啃手里的烤玉米。一口，又一口，吃得极慢，仿佛在细细数着每一粒玉米粒。很少抬头说话，只是时不时抬眼望向你的方向，又飞快低下头。"
    "凌晨坐在长桌最外侧，手上没有捧着往日随身的书本。一言不发，伸手把一盘烤香菇轻轻推到你的面前，做完之后，便收回手，望向街边来往的路人。"
    "黎陌尘依旧像从前那样，默默伸手，把桌上所有人的水杯一一摆放整齐，对齐桌沿。细微、沉默的习惯，一如初见。"
    "谢旻把一串烤年糕翻了个面，忽然想起什么，转头看向黎陌尘。"
    xm "对了陌尘，你那首曲子写完了没？"
    "黎陌尘的手停在杯沿上。"
    lm "……还没。"
    xm "写了三年了，还没写完？"
    "黎陌尘没有接话。他把最后一个杯子摆正，收回手。"
    lm "……再说吧。"
    "谢旻看了他一眼，没有继续追问。他低下头，把年糕从签子上取下来，放进自己碗里。"
    "你注意到，谢旻说这句话的时候，江枫在旁边安静地喝了一口水。她没有看黎陌尘，但她的手在杯壁上停了一会儿。"
    "桌上短暂地安静了两秒。然后黎妤开口，把话题岔开了。"
    ly "对了，你们暑假有什么打算？我接了个墙绘的活，估计要跑好几个地方。"
    "气氛重新松下来。但黎陌尘没有再接话。他坐在那里，手指在桌沿下轻轻敲着，像在弹一段没有声音的旋律。"
    "炭火噼啪作响，烤肉香气漫开，可席间的话语比军训那晚稀薄很多。"
    "饭局走向尾声，大家陆续起身。你走在所有人的最后面，站在烧烤店门口，看着七道背影，三三两两，消散在夜晚的街道夜色之中。"
    
    scene bg library_front_morning at bg_top
    "离出发还有三天。你把该还的书收拾好，装进帆布袋，独自去了一趟图书馆。"
    "下午的图书馆人不多，阳光斜斜落在靠窗那一排桌面上。你绕过书架，走向那个熟悉的位置。"
    
    scene bg library_two_lc at bg_top
    "凌晨果然在。他坐在老位置上，笔记本电脑摊开，耳机没有戴，屏幕上是那个极简的网页界面。他听见脚步声，抬起头看到你，没有合上电脑。"
    lc "来了。"
    player_name "来还书。"
    "你把帆布袋放在桌上，在他对面坐下。他把电脑往你的方向转了一点，屏幕上还是那棵老槐树，页面旁边多了一个此前没有见过的栏目。"
    player_name "这个栏目……之前没见过。"
    lc "刚建的。还没做完。"
    "他点开那个栏目。页面加载出来，是一组照片。"
    "第一张，是一棵老槐树，夏天，树冠浓绿，树下一张竹椅。第二张，是几个模糊的小人影，站在树下，距离很远，看不清脸。第三张，是一把旧蒲扇，放在竹椅扶手上。"
    "最后一张，是一张手写的纸条。纸条上只有一行字，字迹歪歪扭扭，像是小孩写的。"
    "“二牛，等我回来。”"
    "你盯着那张纸条看了很久。"
    player_name "这是……"
    lc "他写的。"
    "凌晨的声音很轻。"
    lc "你搬走那年，他在树下坐了一下午。走之前，他把这张纸条塞在我家门缝里。"
    player_name "后来呢？"
    lc "后来他家也搬了。纸条我一直留着。"
    "他把页面往下拉了一点，光标停在最后一张照片下方。那里还有一行小字，是凌晨自己写的备注。"
    "“记录人：陈二牛 记录时间：至今”"
    player_name "你一直在等他回来。"
    "凌晨没有回答。他把电脑屏幕转回去，手指停在触控板边缘。"
    lc "……这个栏目，我本来没打算给任何人看。"
    player_name "为什么给我看？"
    "他沉默了几秒。"
    lc "因为你又要走了。"
    "他说这句话的时候，没有看你。"
    lc "你走之后，大概也会遇到很多人。有些事，你可能也会想记下来。"
    player_name "你希望我记下来吗？"
    lc "……随便你。"
    "他把网页最小化，打开了一份代码文档。但手指没有落在键盘上。"
    player_name "我路上会经过桃溪村。你有什么想让我带的吗？"
    "凌晨的手指在键盘边缘停住。他没有立刻回答，而是慢慢把耳机线从桌角收起来，一圈一圈缠好。"
    lc "不用带东西。"
    "他把缠好的耳机线放进电脑包侧袋。"
    lc "你路过村东那棵老槐树的时候……"
    "他顿了顿。"
    lc "你告诉他，树还在。"
    player_name "就这一句？"
    lc "就这一句。"
    "他重新把手放到键盘上，敲了一行代码，又删掉。"
    lc "走吧。你还要收拾行李。"

    scene bg library_front_evening at bg_top
    "你站起来，把帆布袋挎到肩上。走到书架拐角的时候，你回头看了一眼。凌晨还坐在那里，没有动，屏幕上的光映在他脸上。他面前那个网页，还停在那张歪歪扭扭的纸条上。"
    "你忽然想起，牵绕说过的那个词。"
    "“牵挂着，绕着走。”"
    "凌晨绕着走的方式，是把牵挂写成代码，存在一个永远不会消失的网站上。而牵绕绕着走的方式，是改掉名字，假装自己从来没有在树下坐过一整个下午。"
    "两个人都没有回头。但两个人都没有走远。"

    scene bg dorm_afternoon at bg_top
    "傍晚，江枫给你发了一条私信。"
    jf "我和谢旻在琴房，你来一趟。"

    scene bg guitar_practice_room at bg_top
    "你走到教学楼琴房门口。门开着，里面传出吉他声。"

    scene bg guitar_jf_xm at bg_top
    "江枫坐在琴凳上，谢旻站在旁边，手里拿着谱纸。"
    "你走进去。江枫没抬头，手指继续拨弦。谢旻把谱纸递给你。"
    xm "你来得正好。这首歌还没给别人听过。"
    "谱纸上的歌名写着《路上小心》。歌词写得歪歪扭扭，明显改过很多遍，有一整段被划掉又重新写在旁边。"
    player_name "写给谁的？"
    "江枫停下拨弦的手，抬头看你。"
    jf "你说呢。"
    "她把吉他递给谢旻，站起来，伸了个懒腰。"
    jf "本来想等你走的时候再唱。但我觉得，当面唱比发文件好。"
    "谢旻坐在侧边，开始弹前奏。江枫清了清嗓子，开口唱第一句。"
    "旋律很简单，歌词也很简单。写的是一个人背着包走出车站，回头看，发现身后有人站着。她没有回头挥手，但脚步慢了一拍。"
    "唱到最后一句，江枫的声音低下去，谢旻的琴声也轻了。她没有唱完，把最后两个字咽了回去。"
    jf "……算了，最后一句等你回来再唱。"
    player_name "为什么？"
    jf "因为最后一句是‘路上小心，记得回来’。"
    "她说这句话的时候，语气很随意，像在报一个菜名。"
    jf "你走了之后，我们的巡演第一站就定在你去的第一个城市。等你到了，发个定位。"
    xm "姐，你确定有人请我们巡演？"
    jf "你闭嘴。"
    "谢旻笑了一声，把吉他收好。江枫从琴凳上拿起一个纸折的小挂件，塞进你手里。是一只很简陋的纸鹤，和第一次见面时她在野餐垫上折的那只一模一样。"
    jf "拿着。路上别弄丢。"
    player_name "你每次送人都送纸鹤？"
    jf "不是。只送要走的人。"
    "她把琴房的门推开，晚风灌进来。你走出琴房的时候，谢旻在背后喊了一声。"
    xm "喂。"
    "你回头。"
    xm "那张照片。我说的是舞台上那张。真的别删。"
    player_name "不删。"
    xm "嗯。"
    "他把琴房的门轻轻关上。"

    scene bg library_front_morning at bg_top
    "出发之前，你去往图书馆。"

    scene bg library_window_look_up_xl at bg_top
    "小莱依旧坐在她常坐的靠窗座位，摊开厚厚的地方志。"
    xl "要出发了？"
    player_name "嗯。"
    xl "你回来的时候，提前告诉我。"
    player_name "你怎么知道我什么时候回来？"
    xl "你走之前会说的。"
    "她没有抬头。但她把那张写着地名的信纸，折好塞进信封里。"
    "她拉开抽屉，取出一只牛皮纸信封递给你。信封里面是满满一沓手写笔记，字迹工整清秀，一页页标注偏僻小城、旧村镇的地名与简短历史。"
    xl "这些是我整理的。路上如果途经这些地方，可以读一读。"
    "你翻开信封，里面是厚厚一沓手写笔记。你翻到其中一页，上面写着桃溪村隔壁镇子的旧名。"
    player_name "这个镇子……"
    xl "嗯。我在图书馆查资料的时候，有人跟我提过。"
    player_name "谁？"
    xl "一个计算机系的男生。他不怎么说话，但他在做一个网站。"
    "她顿了顿。"
    xl "他把桃溪村的老照片发给我看过。我帮他查了几个地名。"
    player_name "凌晨？"
    xl "……好像是这个名字。"
    "她继续整理桌上的书，语气很平。"
    xl "你认识他？"
    player_name "认识。"
    xl "那正好。"
    "她把信封往你那边推了推。"
    xl "你告诉他，桃溪村东边那个镇子，旧名叫“槐安”。我查到了。"

    $ affection_dict = {"牵绕": qianrao_affection, "黎陌尘": limichen_affection, "黎妤": liyu_affection, "怀小柿": huaixiaoshi_affection}
    $ max_char = max(affection_dict, key=affection_dict.get)
    $ max_value = affection_dict[max_char]
    if max_value >= 60:
        if max_char == "牵绕":
            jump qianrao_ending
        elif max_char == "黎陌尘":
            jump limichen_ending
        elif max_char == "黎妤":
            jump liyu_ending
        else:
            jump huaixiaoshi_ending
    else:
        jump friendship_ending

label qianrao_ending:
    # 绒面律动.MP3
    play music "music/绒面律动.MP3" fadein 1.0

    scene bg tennis_court at bg_top
    "隔日傍晚，你去往网球场找牵绕告别。"
    "偌大球场只有他一个人。他独自对着围墙练习击球，网球狠狠撞在球拍表面，发出沉闷厚重的声响。"
    "一下。又一下。"
    "你站在场边看台下面静静观望。他明明瞥见了你，却没有停下挥拍，仿佛你只是场边一道普通的影子。"
    "但你注意到，他击球的节奏比平时快。球撞在拍面上的声音，也比平时重。"
    
    scene bg tennis_court_one_q at bg_top
    "直到一整筐练习球全部打完，他才拿起毛巾擦去额角汗水，一步步走上看台，坐到你的身旁。"
    q "你来干什么？"
    player_name "来跟你道别。"

    scene bg tennis_court_two_q at bg_top
    "他把球拍搁在脚边，身子微微侧过去，目光避开你的脸。"
    q "道什么别。又不是以后再也见不到。"
    "看台上晚风呼啸，吹动球网哗啦哗啦不停作响。两个人之间漫开一大片沉默。"
    q "……你那台相机，路上千万不要弄丢。"
    player_name "不会。"
    q "镜头盖记得随手盖上。"
    player_name "知道。"
    q "多备几块电池。"
    player_name "已经买好了。"
    "他顿住，嘴唇抿了抿。"
    q "……记得寄明信片。"
    player_name "好。"

    scene bg tennis_court_three_q at bg_top
    "他站起身，伸手拿起脚边球拍，打算重新走回球场。"
    q "行了，我还要练球。你回去吧。"
    "他迈步走出两步，脚步猛地顿住，脊背对着你，始终不肯回过头。"
    q "……到地方记得发朋友圈。"
    "你想起出发前，凌晨在图书馆说的那句话。"
    player_name "牵绕。"
    "他停住脚步，没有回头。"
    player_name "我昨天去见过凌晨。"
    "他的肩膀绷了一下。"
    player_name "他让我路过村东那棵老槐树的时候，告诉你一句话。"
    "看台上的风把球网吹得哗啦作响。他没有回头，但也没有走。"
    player_name "他说，树还在。"
    "沉默持续了很久。"
    
    "你看见他握着球拍的那只手，指节慢慢收紧，又慢慢松开。球拍的拍柄上缠着吸汗带，已经被他攥出了一道折痕。"
    "你以为他会像之前一样，只说一句“知道了”，然后继续去打球。"
    "但他没有。"

    scene bg tennis_court_five_q at bg_top
    "他慢慢转过身，看着你。这是今晚他第一次真正看你。"
    q "……他还说了什么？"
    player_name "没有了。就这一句。"

    scene bg tennis_court_six_q at bg_top
    "牵绕低下头，看着自己手里的球拍。过了几秒，他忽然笑了一下。不是平时那种散漫的、装出来的笑，而是一种很轻的、像是被什么东西击中了的笑。"
    q "树还在。"
    "他重复了一遍。声音很低，像是说给自己听的。"
    q "我走的时候，那棵树还在。我以为这么多年，早被砍了。"
    "你看着他。他的睫毛垂下来，挡住眼底的情绪。"
    q "……二牛这个人，记性倒是好。"
    "他说“二牛”的时候，语气很复杂。有怨，有愧，也有一点你说不清的怀念。"
    "你没有追问。你知道他现在能说出这句话，已经用了很多力气。"

    "他把球拍换到左手，右手插回裤袋。这个动作他做过无数次，但这一次，手指在口袋里攥紧了。"
    q "你路上……"
    "他停了一下。"
    q "如果路过桃溪村，帮我看一眼。就一眼。"
    player_name "看什么？"
    q "什么都行。那棵树，陈婆婆的院子，村东那条河。随便什么。"
    "他说这句话的时候，声音很轻，像是怕被风吹散。"
    q "看完不用告诉我。你自己知道就行。"
    "你看着他。他没有再躲开你的目光。"
    player_name "好。"
    "他点了点头。没有再说别的。"

    "他把毛巾从脖子上扯下来，搭在肩上，转身走向球场。"
    q "行了，你走吧。我还要练球。"
    "他背对着你，弯腰捡起一颗球，抛起来，挥拍。球撞在围墙上，弹回来。"
    "然后他停下动作，没有回头。"
    q "……相机别弄丢。"
    "你笑了一下。"
    player_name "知道了。"

    scene bg tennis_court_nine_q at bg_top
    "你转身离开看台。走到台阶拐角的时候，你回头看了一眼。他站在球场中央，手里握着球拍，没有继续打球。他就那样站着，看着围墙。"
    "你不知道他在看什么。但你觉得，他大概在看一棵你看不见的树。"

    if qianrao_admitted_identity and qianrao_affection >= 70:
        # 结局 同行
        scene bg train_station at bg_top
        "你动身离开的那一天，他专程来到火车站送你。"
        "一路走向检票口，两个人一路沉默，没有多余闲谈。他走在你左边半步，手插在裤袋里，肩膀绷得比平时紧。"
        "马上就要检票进站，他忽然停下脚步，从外套口袋摸出一样东西，塞到你的掌心。"

        scene bg train_station_coin at bg_top
        "你低头一看——是一枚旧硬币，长年摩挲，边缘已经被打磨得发亮。币面刻着一棵树，轮廓酷似桃溪村那棵老槐树。"
        q "小时候在老槐树下捡的。一直留着，也没什么用。"
        player_name "为什么要给我？"
        q "……没什么特别的理由。"

        scene bg train_station at bg_top
        "他说完便转身离开，没有再多停留。你看着他的背影混进车站的人流，很快消失不见。"
        "你低头摊开手心，又看了一眼那枚硬币。你把硬币翻过来，背面没有刻字，只有几道细小的划痕。"

        scene bg train_internal at bg_top
        "你靠在车窗边，手指反复翻转把玩这枚旧硬币。翻到第四回的时候，你才看见——在树根最底部的边缘，刻着一行极小的字。"
        "“下一站。”"
        "你愣了一下。只有三个字，没有“等”字，没有“见”字。"
        "你把硬币收进口袋，抬头看向窗外。"

        "车窗外是不断后退的田野。你不知道过了多久，也没看有没有到站。"
        "旁边有人坐了下来。"
        "你没有回头。你以为是新上车的乘客。"
        "那个人也没有说话。只是把一瓶冰水放在你面前的小桌板上。瓶壁凝着薄薄一层水雾。"
        "你低头看了一眼那瓶水。然后转过头。"

        scene bg train_one_q at bg_top
        "是牵绕。"
        "他靠在座椅上，一只手插在裤袋里，歪头看你。黑色外套，背包扔在脚边。"
        "跟第一次见面时一样，懒散随意的姿态。"

        q "……这么巧。"
        player_name "你怎么会在这里？"
        q "刚好也想出去走走。"
        "他挪了挪身子，靠得更舒服一点。"
        q "反正我也没有计划，你去哪里，我就顺路。"

        "他说这话的时候没有看你，目光落在窗外飞速后退的田野上。"
        "你拿起那瓶水。这个牌子，和大一报到那天他递给你的那瓶一模一样。"
        q "拿着，别渴着。"
        "你拧开瓶盖喝了一口。"
        
        scene bg train_two_q at bg_top
        "他背靠座椅，闭上眼睛，装作闭目休憩。但那抹浅浅的笑意，一直挂在他的嘴角，没有褪去。"
        "你举起相机想拍下他。他没有睁眼，抬手挡住镜头。"
        q "……别拍脸。"
        player_name "为什么？"
        q "没洗脸。"
        "你轻笑一声，把相机放下。可他挡在镜头前的那只手，没有收回去。"
        "你伸出手指，轻轻碰了碰他的指尖。他的手指猛地一顿。"

        scene bg train_three_q at bg_top
        "下一秒，反手稳稳握住你的手。眼睛依旧闭着，只是嘴角的笑意变得更深。"
        "窗外的田野一片一片向后退去。山丘的轮廓在暮色里慢慢模糊。"
        "你靠在他肩上，闭上眼睛。你忽然想起他说的那句话——“牵挂着，绕着走。”"
        "他绕了这么多年。绕过了桃溪村，绕过了陈二牛，绕过了老槐树，绕过了所有会让他想起过去的东西。"
        "最后绕到了你身边。"
    elif qianrao_admitted_identity:
        # 结局 各自远行 
        scene bg dorm_morning at bg_top
        "你没有把自己确切出发的日期告诉他。"
        "出发当日，你收拾背包的时候，才发现包里面多出一盒网球。盒面上贴着一张纸条。"
        "纸条上写着：路上无聊可以练练。别整天只拍别人。"
        "你翻开纸条背面。背面还有一行小字。"
        "“下次拍照，别拍手。这次算我欠你的。”"
        "你把网球收好，纸条折起来，放进相机包的内袋。"

        scene bg train_station at bg_top
        "抵达车站之后，你给他发了一条消息。"
        player_name "我走了。"
        "几分钟过去，收到回复。"
        q "嗯。"
        "紧接着又一条消息弹出来。"
        q "别忘了发朋友圈。"
        "你淡淡笑了笑，把手机锁屏收好。"
        
        scene bg train_internal at bg_top
        "火车开动之后，你靠在窗边，把那盒网球从包里拿出来。盒盖上用马克笔画了一个歪歪扭扭的圆，旁边写着两个字：'加油'。"
        "你翻来覆去看了几遍。那两个字写得很用力，马克笔在纸盒上洇开了一点。"
        "你忽然想起报到那天，他递给你冰水时，手指擦过你掌心。那时候他的手很凉。"
        "你想起网球场上，他手把手教你握拍，手指按在你的手腕上。他的手很热。"
        "你想起槐树下，他把相机拿过去反过来对着你。他的手指在快门上停了很久，最后没有按下去。"
        "你想起火车站检票口，如果那天他来了，他会说什么。但他没有来。"
        "你合上网球盒，放回包里。"

        scene bg road_dusk at bg_top
        "往后旅途，你们维持着线上点赞、偶尔回复朋友圈的普通关系。他始终把自己的过去封闭保护起来，不会主动向你袒露桃溪村的往事。"
        "你发新照片，他第一个点赞。你发路上遇到的陌生人，他也点赞。你发深夜的公路和空旷的车站，他不点赞。"
        "但第二天早上，你总会收到他发来的一条消息。有时候是四个字，有时候只有两个字。"
        "“注意安全。”"
        "“别熬夜。”"
        "“到了吗。”"
        "你从不回复太多。他也从不追问。"
        "你们曾经靠近过，但始终隔着一层无法捅破的距离。你在路上的见闻，只存在于朋友圈的公开动态，不会再有私下深度倾诉。"
        "但你知道，他一直在看。"
        "就像他说的那样——牵挂着，绕着走。"
        "他没有绕开你。只是他绕的圈子太大了，大到他自己都不知道该怎么停下来。"
    else:
        # 未出口的话
        scene bg desk_turn_on at bg_top
        "你回到宿舍，收拾行李的时候，才发现相机里那张槐树下的照片还停在屏幕上。"
        "照片里他站在花雨里，嘴角带着笑。但那双眼睛，看着的不是镜头。"
        "你没有发给他。"

        scene bg dorm_morning at bg_top
        "但第二天早上，他发来了一条消息。"
        q "那张照片，修好了吗。"
        "你看着这条消息，看了很久。"
        "你想回他。你想问他那天在槐树下到底想说什么。"
        "你想问他为什么每次说到桃溪村，都会把话题绕开。"
        "但最后，你只是把照片原图发了过去。"
        q "收到。"
        q "……拍得不错。"
        "你没有再回。他也没有再发。"

        scene bg road_dusk at bg_top
        "后来你在路上发过很多照片。他每一条都点赞。"
        "你发车站、发旧书店、发雨天撑伞的路人。他全点了。"
        "只有一张他没点。是你路过某个县城时拍下的一棵老槐树。"
        "那天晚上，你收到他的一条私信。"
        q "那棵树，在哪儿拍的。"
        "你回了地址。"
        "他没有再说别的。"
        "但你知道，他存下来了。"
        "有些话，他一直没有问。有些话，你也一直没有说。"
        "你们之间隔着一个没有问出口的问题，像隔着那半步的距离。"
        "谁也没有往前迈，但谁也没有走远。"

    jump common_epilogue

label limichen_ending:
    # 尼龙弦慢调.MP3
    play music "music/尼龙弦慢调.MP3" fadein 1.0
    scene bg piano_room_evening at bg_top
    "隔日傍晚，你去往教学楼的钢琴练习室找黎陌尘。"
    "练习室房门虚掩，里面流淌出钢琴的旋律。是那首他写了整整三年的曲子。"
    "你站在门外静静伫立，没有推门打扰。琴声一直持续，直到最后一个音符散尽。这一次，他没有在中途停下来。"
    "房间归于安静。"
    "他转过身，望向房门的方向，仿佛早就察觉到你的到来。"
    lm "站在外面的人，进来吧。"

    scene bg leave_taking_one_lm at bg_top
    "你推门走进去。射灯只照亮琴键和他的侧脸，其余大半房间沉在阴影里。他面前摊着谱纸，页角卷了边，显然被翻过很多次。"
    lm "什么时候动身？"
    player_name "下周三。"
    "他没有追问目的地，也没有询问归期。只是把谱纸合上，指尖在纸面上停了一下。"
    lm "这首曲子，你听过很多次了吧。"
    player_name "第一次是在楼下，隔着窗户。后来在门外，断断续续听了好几次。"
    "他点了点头，像是在确认什么。"
    lm "完整听过的人，只有你一个。"
    "你愣了一下。"
    player_name "黎妤也没听过？"
    lm "她听过的版本，都停在第二段。每次都一样。"
    "他说得很平，但你听懂了一件事——他从来没能把这首曲子完整地交给任何人。包括他自己。"

    scene bg leave_taking_two_lm at bg_top
    "他从琴凳一旁拿起一只密封信封，递到你的手上。"
    "你注意到，信封下面压着一本书。封面很旧，书名已经磨得看不清了。"
    "就是那天长椅上的那本诗集。"
    lm "路上听。"
    "你拆开信封，里面存放着一枚U盘。"
    player_name "这是什么？"
    lm "那首曲子，录好了。"
    player_name "它叫什么名字？"
    "他稍稍沉思片刻。"
    lm "还没想好。等你回来，我再告诉你名字。"

    scene bg leave_taking_three_lm at bg_top
    "你把U盘稳妥收好。他重新落回琴键，弹奏一小段简短轻柔的旋律，短短的乐句，仿佛一句没有说完的话语，便骤然停下。"
    lm "去到远方，找个安静的地方再播放它。"
    player_name "为什么？"
    lm "因为这首曲子，是写给一段路的。"
    "他顿了顿。"
    lm "不是写给终点，是写给路上。"
    "你看着他。他没有再解释，只是把手从琴键上收回来，放在膝盖上。那是他弹完一首曲子后惯有的姿势——安静，克制，像是把所有情绪都收回体内。"
    "你起身道别。走到门口的时候，他在背后开口。"
    lm "路上别只顾着拍别人。"
    "你回头。"
    lm "……也记得拍拍你自己。"

    if limichen_important_choice == "encourage" and limichen_affection >= 75:
        # 合奏    路上
        scene bg train_station at bg_top
        "出发这一天，他来车站送你。"
        "一路往前走，你们聊音乐、聊旅途、聊他对未来的设想。他说话的时候，手指偶尔会在身侧轻轻敲一下，像是在打拍子。"

        scene bg train_one_lm at bg_top
        "站在检票口之前，他认真开口。"
        lm "我写曲子，你拍照片。我们各自完成自己的东西，最后合在一起。"
        player_name "好，就这么说定。"
        "他朝你伸出手，你伸手与他相握。他的手掌温暖安稳，握了三秒才松开。"
        "松开手的时候，他忽然从口袋里取出一张折好的谱纸，递给你。"
        lm "这个也带着。"
        "你展开谱纸。上面是一段手写的旋律，只有八个小节。标题处空着，没有名字。"
        lm "这是《路上》的第二段。第一段在U盘里。"
        player_name "第一段是什么？"
        lm "第一段是你离开的那天。"
        "他把手插回外套口袋，微微偏开脸。"
        lm "第二段，等你回来的时候，我再写完。"
        "检票口开始放行。你拎起背包。"
        "他忽然伸手，按住你的背包带子。"
        "你回头。"
        lm "我送你上车。"

        scene bg train_two_lm at bg_top
        "你们一起穿过检票口，走过通道，走上站台。"
        "站台上风很大。火车还没来。"
        "他站在你旁边，把手插在口袋里，看着远处的铁轨。"
        "过了一会儿，他开口。"
        lm "……我也上车。"
        player_name "什么？"
        lm "陪你坐一段。坐到下一站。"
        player_name "你不用……"
        lm "我买票了。"
        "他说得很平，像是在说一件很普通的事。"
        "你没有再问。"

        # scene bg train_internal at bg_top
        "火车进站的时候，他走在你前面。"
        
        scene bg train_three_lm at bg_top
        "你们上了车，找到座位坐下。他坐在靠窗的位置，你坐在他旁边。"
        "他从背包里拿出一本书，翻开。但没有看。"
        "你看着窗外。他看着书。"
        "四十分钟后，广播报出下一站的名字。"
        "他合上书，站起来。"
        lm "……到了。"
        "你抬头看他。"
        lm "我在这里下车，坐回去。"
        "他背上背包，走到过道里。"
        "走了两步，停下来，没有回头。"
        lm "……路上小心。"
        "然后他下了车。"

        scene bg train_four_lm at bg_top
        "你透过车窗，看见他站在站台上，目送火车离开。"
        "他没有挥手。只是站在那里，看着火车驶出站台。"
        "你的手机震了一下。"
        lm "第二段，等你回来再写。"
        "你低头看着那条消息。"
        "忽然明白了。他不是来送你的。"
        "他是来陪你走一段路的。"
        "第一段。剩下的，等你回来，你们一起写。"
        
        scene bg road_dusk at bg_top
        "你踏上旅途之后，隔一段时间，你的手机就会收到他发来的音频片段。他写一小段，就发给你；你去到一处地方，就拍下一组照片。二人相隔遥远，不见面，却始终在合作一件属于彼此的作品。"
        "那首曲子，最后的定名叫做《路上》。第一段音频的备注写着：第一站，从你离开的那一天开始。"
    elif limichen_important_choice == "encourage":
        # 沉默    未完成
        scene bg train_station at bg_top
        "出发当日，他没有前来车站送别。"

        scene bg train_internal at bg_top
        "火车开动，你插上耳机打开U盘。除去那首完整的乐曲之外，里面还多出一个命名为《路上》的文件夹。"
        "文件夹里面存着十几段长短不一的音频，有钢琴，有小提琴，还有纯粹的环境录音：雨声、风声、市井街道的嘈杂。最后一段音频备注写着：到了再听。"
        "你按下播放。只有寥寥几声钢琴按键，轻而柔和。之后是一大段空白。"
        "反复聆听几遍，你才恍然醒悟，那寥寥几个音符对应的正是你的名字的笔画。"
        "你靠在车窗边，把这十几段音频从头到尾听了一遍。每一段都很短，最短的只有两个音符。"
        "你数了数，一共十八段。"
        "十八次。他弹了十八次。每一段都是同一个人写的，但你听不出他在想什么。"
        "你又听了一遍那首完整的曲子。这一次你听出来了——第二段，始终没有出现。"
        "他给你的，是一首没有写完的曲子。"
        "他把所有能给的都给了，只有那最后一段，他留给了自己。"

        scene bg road_dusk at bg_top
        "往后你们依旧会偶尔联系。他依旧热爱钢琴，但那层内心最深的创伤，不会再向你提起。音频成为一份安静的礼物，却不会再有持续的双向创作。你们停留在普通朋友，不会再往更深的关系走近。"
        "你偶尔会想，如果那天你多问一句，如果他多留一句，结局会不会不一样。"
        "但你没有问。他也没有留。"
        "有些曲子，写不完，就是写不完。"
    else:
        scene bg teaching_building_corridor_evening at bg_top
        "你把U盘收好。他没有多解释什么，只是重新把手放回琴键上。"
        "你起身道别，走到门口的时候，他在背后开口。"
        lm "路上注意安全。"
        "四个字。不轻不重，像一句普通的叮嘱。"
        "你回头看他。他坐在射灯下，视线落在琴键上，没有看你。"
        "你忽然想问那首曲子的来历。想问为什么他每一次弹到第二段都会停下来。"
        "但你没问。"
        "你只是点了点头。"
        player_name "好。"
        "然后你推开门，走进走廊。"

        scene bg train_station at bg_top
        "出发那天，他没有来车站送你。"
        
        scene bg train_internal at bg_top
        "火车开动之后，你把U盘插进耳机。"
        "里面只有一首完整的曲子。没有多余的音频，没有《路上》文件夹，没有那十几段短促的旋律。"
        "你从头听到尾。旋律很好听，情绪很满。但弹到第二段的时候，你听出了一些不一样的东西。"
        "他不是在弹一段旋律，他是在弹一段没说完的话。"
        "第二段停了。"
        "不是录坏了，也不是演奏失误。他就是停在那里，然后直接从第三段开始。"
        "你反复听了几遍。"
        "那一段空白不长，只有三秒。但三秒里什么也没有，只有琴房里非常轻的回声。"
        "你把耳机摘下来。"
        "窗外是不断后退的田野。"
        "你忽然明白，那首曲子不是写给你的。它写给他自己。"
        "他只是把它录了下来，交给了你。至于第二段为什么空着，他大概从一开始就没打算让你知道。"

        if limichen_affection >= 70:
            # 隔门·近    第二段
            scene bg road_dusk at bg_top
            "往后你们依旧会偶尔联系。"
            "他偶尔发来一段钢琴录音，没有文字，只有音频文件。你偶尔发几张旅行途中拍的照片。"
            "他会回复“收到”。有时候回复“这张构图不错”。"
            "从来没有多余的话。"
            "但你注意到，他发来的音频，越来越短。"
            "最短的一段，只有两个音符。"
            "你把它们一段一段存进同一个文件夹，按日期排好。"
            "你数过，一共十一段。"

            scene bg old_music_store at bg_top
            "某天上午，你路过一座老城区的琴行。"
            "门开着，里面有人在试琴。弹的是一首很简单的练习曲。"
            "你站在门口听了一会儿。"
            "弹琴的是个十几岁的孩子，弹错了一个音，又从头来过。"
            "你忽然想起黎陌尘。想起他弹琴前手指悬在琴键上方的那一下停顿。"
            "那是起手。"
            "你从来没有看他完成过一次完整的起手。"

            scene bg old_music_store_photograph at bg_top
            "你举起相机，对着琴行的门拍了一张。"
            "玻璃门上倒映着街对面的梧桐树，树下停着一辆旧自行车。"
            "你把这张照片发给了他。"
            "没有配文字。"
            "过了很久，他回了一条。"
            lm "……这是哪家琴行。"
            "你回了地址。"
            "他没有再说别的。"

            scene bg empty_music_room at bg_top
            "但那天晚上，你收到了一段新的音频。"
            "比之前所有的都长。整整一分钟。"
            "弹的是那首曲子的第二段。"
            "他弹完了。"
            "弹到最后，有一个很轻的杂音，像是手碰到了琴键边缘。"
            "音频的最后，他没有说话。"
            "但你听见琴房的门开了，又关了。"
            "你把那段音频听了很多遍。"
            "你没有问他为什么现在弹。"
            "他也没有说。"
            "但你知道，那扇门，他推开了一点。"
        else:
            # 隔门·远    三秒
            scene bg road_dusk at bg_top
            "往后你们依旧会偶尔联系。"
            "他偶尔发来一段钢琴录音，没有文字，只有音频文件。你偶尔发几张旅行途中拍的照片。"
            "他会回复“收到”。有时候回复“这张构图不错”。"
            "从来没有多余的话。"
            "你发得越来越少，他回得也越来越慢。"
            "后来你发一张照片，他隔了两天才回“收到”。"
            "你发下一张，他没有回。"
            "你把手机收起来，没有再发。"

            scene bg old_music_store at bg_top
            "某天上午，你路过一座老城区的琴行。"
            "门开着，里面有人在试琴。弹的是一首很简单的练习曲。"
            "你站在门口听了一会儿。"
            "弹琴的是个十几岁的孩子，弹错了一个音，又从头来过。"
            "你忽然想起黎陌尘。想起他弹琴前手指悬在琴键上方的那一下停顿。"
            "那是起手。"
            "你从来没有看他完成过一次完整的起手。"
            
            scene bg old_music_store_photograph at bg_top
            "你举起相机，对着琴行的门拍了一张。"
            "玻璃门上倒映着街对面的梧桐树，树下停着一辆旧自行车。"
            "你看着这张照片，想发给他。"
            "但你想起上一条没有回复的消息，手指停在发送键上。"

            scene bg street_lm at bg_top
            "最后你锁屏，把手机收进包里。"
            "这张照片，你没有发出去。"
            "你继续往前走。"
            "你路过很多家琴行，再没有停下来过。"
            "你偶尔会想起那首曲子。"
            "但你很少再打开那个U盘。"
            "第二段那三秒的空白，后来在记忆里也变得模糊了。"
            "你只知道，有一首曲子没有弹完。"
            "至于为什么没弹完，你大概永远不会知道了。"

    jump common_epilogue

label liyu_ending:
    # 只对你心动
    play music "music/只对你心动.MP3" fadein 1.0

    scene bg lakeside at bg_top
    "你去往校园湖边，黎妤正坐在熟悉的那张长椅上埋头画画。"

    scene bg leave_taking_one_ly at bg_top
    "你走到她身旁坐下。她没有立刻抬头，笔尖依旧在速写本上游走。画纸上，湖面落日，金光碎碎铺满水面。"
    ly "你要走了。"
    player_name "嗯。"
    ly "什么时候回来？"
    player_name "我不知道。"
    if ly_important_flag == "hold_idea":
        "她笔尖微微一顿，眼底掠过一丝遗憾，但已经可以坦然接受那份失败。"
    else:
        "她指尖轻轻摩挲速写本纸边，那一份理想与现实拉扯的郁结，已经被时间抚平大半。"

    scene bg leave_taking_two_ly at bg_top
    "她把笔搁在速写本边缘，抬头看了你一会儿。风从湖面吹来，把她额前的碎发掀起来，她没有去理。"
    ly "行吧。那你路上帮我多拍一点东西。"
    player_name "拍什么？"
    ly "各式各样好看的墙壁。我一直想尝试墙绘，但是去过的地方太少。你拍回来给我参考。"

    scene bg leave_taking_three_ly at bg_top
    "她把一本厚厚的速写本塞到你的手里。"
    ly "这个送给你。里面画了一些我见过的风景。路上路过相似的地方，你可以拿出来看一看。"
    "你翻开速写本。"
    "第一页：汴京大学湖边的长椅。第二页：食堂的长条餐桌。第三页：宿舍的窗台。"
    "翻到最后一页，是军训结束那晚烧烤店的拼桌长桌。纸上只画下空空荡荡的桌子，没有画任何一个人。"
    player_name "为什么这张桌子是空的？"
    ly "因为那时候还没画完。"
    "她伸手，把速写本从你手里轻轻合上。"
    ly "人的模样我画不好。拍照这件事，交给你。"
    "她说完这句话，忽然顿了一下。像是有什么话到了嘴边，又被她咽了回去。"
    ly "……算了，没什么。"

    if ly_important_flag == "hold_idea" and liyu_affection >= 70:
        # 守灯
        scene bg train_station at bg_top
        "她来车站送你。检票口前，她忽然拽住你的衣袖。"
        ly "我想去的地方，和你想去的，不完全一样。"
        player_name "那我们就各走各的，回来交换见闻。"

        scene bg train_one_ly at bg_top
        "她没接话，看着你，眼睛慢慢亮起来，然后松开手。"
        ly "不对。"
        player_name "什么不对？"
        ly "你说各走各的。不对。"
        "她把画包抱在怀里，像在认真想什么。"
        ly "绘本黄了之后，我一直没想好接下来干嘛。"
        ly "反正我现在没有甲方，没有截稿日，没有人等我交稿。"
        "她抬头看你。"
        ly "那我为什么不跟你走？"
        "她把一盒水彩塞进你的背包。"
        ly "你拍人，我画墙。刚好凑一本旅行绘本。"
        ly "封面就用我们七个人的合照。没有固定计划，那就一起上路。"
        ly "路上见到好看的墙记得拍。"
        "她说得很快，像怕自己反悔。然后甩上画包，走向检票口。"
        ly "愣着干什么，车快开了。"

        scene bg train_two_ly at bg_top
        "你跟上她。她坐在靠窗的位置，脑袋贴着玻璃，像第一次远行。"
        ly "快看！那朵云像小猫。"
        "你举起相机拍她。她伸手挡镜头。"
        ly "不许偷拍！我画画时表情很难看。"

        scene bg train_three_ly at bg_top
        "快门按下。照片里，她挡着半张脸，另一半笑得灿烂。"
        "她翻开速写本，摊开空白页。"
        ly "第一站。你拍一张，我画一张。"

        scene bg train_internal at bg_top
        "你拍窗外。她画的却是你。"
        "她没有打草稿，线条直接落下，一笔接一笔。"
        player_name "你今天画得很快。"
        ly "因为今天不用改。"
        "她低头继续画。"
        ly "以前落笔前，我总想甲方会不会喜欢。现在不用了。"

        scene bg train_draw_ly at bg_top
        "画完，她把速写本转过来给你看——是你举着相机的侧影，线条随意，神态却很像。"
        player_name "这个是我？"
        ly "嗯。"
        player_name "你不是说画人不行吗？"
        ly "以前不行。"
        "她把速写本收回去。"
        ly "以前画人，总想着别人会怎么看。现在画人，只想着这个人长什么样。"

        scene bg train_internal at bg_top
        "列车穿过田野。她翻页画窗外的山，轮廓很淡，留了一大片空白。"
        player_name "这里为什么空着？"
        ly "留着。"
        player_name "留什么？"
        ly "不知道。就觉得该留着。"
        ly "以前甲方老说空白太多不完整。但我喜欢留白。"
        "她看着那页，嘴角勾了一下。"
        ly "现在不用管甲方怎么想了。"

        scene bg train_internal_evening at bg_top
        "天色暗下来。她合上速写本。"
        ly "绘本黄了之后，我有三天没画画。"
        player_name "为什么？"
        ly "怕自己后悔。"
        ly "第四天，我翻出速写本，画了一面墙。画完发现还是想画。跟项目、甲方都没关系，就是单纯想画。"
        ly "所以后来我就不后悔了。"

        "列车鸣笛。远处有零星灯光。"
        ly "第一站快到了。"
        "她撕下那张画着你的侧影，对折，递给你。"
        ly "这个给你。"
        player_name "为什么？"
        ly "因为这是第一张。第一张画对的画。给你留着。"
        "你接过纸。边缘是手撕的毛边。"

        scene bg train_four_ly at bg_top
        "她把脸贴回玻璃上，看着窗外掠过的灯火。"
        ly "第二站，我画你拍的墙。第三站，你拍我画的墙。"
        ly "这样绘本就成了。"
        "她转头看你，眼睛亮亮的。"
        ly "对不对？"
        player_name "对。"
        "她笑了。窗外灯一盏一盏往后退，第一站快到了。"
    elif ly_important_flag == "compromise" and liyu_affection >= 70:
        # 周旋
        scene bg train_station at bg_top
        "她来到车站送你。"
        "检票口之前，她忽然伸手拽住你的衣袖。"
        ly "我想要去的地方，和你想去的，不完全一样。"
        player_name "那我们就各走各的，回来之后交换所见所闻。"

        "她松开手，低头看了一眼手机。屏幕上亮着一条未读消息，备注是甲方的名字。"
        "她没有点开。"
        "她把手机翻过来扣在手心，抬头看你。"
        ly "……你说，如果你路上多一个画墙的，会不会打扰到你？"
        player_name "不会。"
        ly "我可以远程接单。走到哪里就在哪里画。晚上画甲方的，白天画自己的。"
        "她说得有点犹豫，像是在说服自己，也像是在问你。"
        ly "就……半个旅行搭子。你拍你的，我画我的。碰到好看的墙我停下来画，你不用等我。"
        player_name "你说得这么详细，是怕我拒绝吗？"
        
        scene bg train_one_ly at bg_top
        "她被你说中了，笑了一下。"
        ly "是有一点。"

        "她把手机塞进外套口袋，像是做了某个决定。"
        ly "反正甲方也不会消失。走到哪里都得改稿。"
        "她把画包从肩上卸下来，拉开拉链，看了一眼里面。"
        ly "但我可以先陪你走一段。"
        "她把一盒水彩颜料塞进你的背包。"
        ly "路上见到好看的墙记得拍。"
        "她把画包甩上肩头，径直向着检票口迈步。"
        ly "愣着干什么，车快要开了。"
        "你站在原地片刻，连忙跟上她的脚步。"

        scene bg train_two_ly at bg_top
        "她坐到靠窗的座位，脑袋贴在玻璃上向外张望，像一个第一次远行的孩子。"
        ly "快看！那朵云长得像小猫！"
        "你举起相机拍下她扒住窗户的侧脸。她反应过来，伸手遮挡镜头。"
        ly "不许偷拍！我画画的时候表情很难看！"

        scene bg train_three_ly at bg_top
        "快门按下。照片之中，她的手掌挡住半张脸颊，剩下的半张脸，盛放着灿烂的笑意。"
        "你收起相机。"

        scene bg train_internal at bg_top
        "她翻开速写本，但没有立刻动笔。"
        "手机震了一下。她低头看了一眼，眉头皱了一下。"
        ly "……甲方。"
        "她把手机翻过来扣在膝盖上。过了一会儿，又拿起来，回了两条消息。"
        "回完之后，她把手机锁屏，塞进外套口袋。"
        ly "好了。今天不回了。"
        player_name "不回没关系吗？"
        ly "没关系。我说过，改稿和私稿分开。这趟车上，我先画自己的。"
        "她摊开一张崭新空白画纸。"
        ly "第一站。你拍一张，我画一张。"
        "你抬相机望向窗外景色。而她笔下，落笔描绘的，却是身旁的你。"
        "她画了一会儿，停下来，看着那一页。"
        ly "……你知道吗，我以前一直觉得，画人是我的弱项。"
        player_name "现在呢？"
        ly "现在我觉得，是以前没有画对的人。"
        "她合上速写本，靠在椅背上。"
        "窗外的田野一片一片向后退去。你看着窗外，她看着你。"
        "她把速写本放在膝盖上，没有合紧，留了一条缝。"
        "你看到那一页上画的，是你歪头举相机的侧脸。"
    else:
        # ————————————————————————————————————————————————
        # 低好感分支：触发了关键剧情，但好感不足 70
        # 按 hold_idea / compromise 分成两个未竟结局
        # ————————————————————————————————————————————————
        scene bg train_station at bg_top
        "你独自踏上旅途。"

        scene bg train_five_ly at bg_top
        "出发那天，她来车站送你，但只送到检票口外面。"
        "她抱着速写本，站在栏杆边，朝你挥了挥手。"
        ly "路上小心！记得多拍墙！"
        "你点头，走进检票口。"
        "回头的时候，她还站在那里。速写本合上了，夹在胳膊下面。"
        $ ly_ending_mood = "hold" if ly_important_flag == "hold_idea" else "compromise"

        scene bg train_internal at bg_top
        "你想起那天在湖边。"
        if ly_ending_mood == "hold":
            "她说项目黄了。她说她不后悔。但你知道，她其实很难过。"
            "她守住了自己的灯。只是那盏灯下，没有多站一个人。"
        else:
            "她说她做了一部分让步。她说她保住了内核。但你知道，她其实很累。"
            "她保住了那盏灯。只是灯已经不是你最初看到的样子。"
        "你没有问她。她也没有追上来。"

        scene bg road_dusk at bg_top
        "你走后，她继续画画。"
        if ly_ending_mood == "hold":
            "你偶尔会在社交平台上刷到她的新作。有些是私人速写，有些是短篇插画。"
            "没有了商业合作，她反而画得比以前更频繁。"
            "有一张你记得很清楚。"
            "画的是一个女孩，站在一盏灯下。灯很亮，暖黄色的光铺开一小片地面。"
            "女孩手里举着相机，镜头朝外。"
            "但镜头对面没有人。"
        else:
            "你偶尔会在社交平台上刷到她的新作。商业合作还在，私人速写也在更新。"
            "但她发得比以前少了。"
            "有一张你记得很清楚。"
            "画的是一个女孩，站在一盏灯下。灯还在，但光被调暗了一点。"
            "女孩手里没有拿相机。她只是站着，看着灯。"
        "你盯着那张画看了很久，没有点赞。"
        "你只是把它存进了相册。"

        scene bg youth_hostel_evening at bg_top
        "某天夜里，你在一座小镇的青旅落脚。"
        "背包里翻出那本她送你的速写本。你从第一页翻到最后一页。"
        "湖边、食堂、宿舍窗台、军训烧烤的空桌。"
        "最后一页那张空桌，从你们分开之后就再没有变过。"
        "你合上速写本。"
        "你忽然觉得，有些画，不是她画不完。"
        "是她不知道该怎么画完。"

        "你打开手机，点进和她的对话框。"
        "最后一条消息还停在出发那天。"
        ly "路上小心！记得多拍墙！"
        "你打了一行字。删掉。又打了一行。又删掉。"
        "最后你锁屏，把手机放在枕头旁边。"

        scene bg youth_hostel_window_evening at bg_top
        "窗外是陌生城市的夜色，远处有火车驶过的声音。"
        "你没有告诉她，你路过一座小镇的时候，看到了一面很漂亮的墙。"
        if ly_ending_mood == "hold":
            "墙上画着一个女孩，站在一盏灯下。灯很亮，但旁边没有人。"
        else:
            "墙上画着一盏灯。灯还亮着，但光只照到半面墙。"
        "你举起相机的时候，忽然想起她。"
        "但你没有发给她。"
    jump common_epilogue

label huaixiaoshi_ending:
    # 迷人的吻.MP3
    play music "music/迷人的吻.MP3" fadein 1.0

    scene bg desk_turn_on at bg_top
    "出发前的最后一个夜晚，寝室只剩下你和怀小柿两个人。其余室友都暂时不在宿舍。"

    scene bg leave_taking_one_hx at bg_top
    "怀小柿抱着膝盖坐在自己的床铺上，目光落在手机屏幕。你在书桌前，一件一件整理旅途的行李。房间安安静静，只有物品挪动的细碎声响。"
    "沉默蔓延了很久。你拉上背包拉链的时候，她忽然开口。"
    hx "……你明天就走了。"
    player_name "嗯。"
    hx "我写了新的一章。"
    player_name "章节叫什么？"
    hx "《远方》。"
    "手机屏幕亮起，她把这一章文档发送过来。"
    "你读完文字。小说写一个女孩孤身来到陌生城市，看人来人往。她不知道前路该去往何方，但她从来没有回头。"
    player_name "写得很好。"
    hx "……是哪里好？"
    player_name "她不知道往哪走，但没有回头。这句话写得很好。"
    
    scene bg leave_taking_two_hx at bg_top
    "怀小柿的脑袋低下去，沉默许久。她的手指在手机壳边缘反复刮了两下，忽然停住。"
    hx "……你知道吗。我一直在想一件事。"
    "她把手机翻过来扣在膝盖上，屏幕暗下去。房间里只剩台灯昏黄的光。"
    hx "校刊那件事之后，有人扒出了我的小说。校园里有人猜作者是谁。我一直躲，假装没看见。"
    hx "但躲着的时候，我一直在写。写了很多。比之前写得都多。"
    
    scene bg leave_taking_three_hx at bg_top
    "她抬起头，看着你。这是今晚她第一次真正看你。"
    hx "你明天就走了。你要去很多地方，见很多人。你会拍很多照片。"
    hx "我……"
    "她张了张嘴，又停住了。手指攥紧手机壳边缘。"

    if hx_shared_novel_origin:
        # 她鼓起勇气，把小说发给你
        hx "我想把小说发给你。"
        hx "不是片段。是全部。从头到尾。"
        player_name "为什么想发给我？"

        scene bg leave_taking_four_hx at bg_top
        "她沉默了几秒。台灯的光落在她的睫毛上，投下一小片阴影。"
        hx "因为你说过，你喜欢我的文字。"
        hx "你是第一个说‘喜欢’的人。"
        hx "我想……至少有一个读者，是知道我全部故事的人。哪怕只有一个人。"
        "你看着她。她的声音很轻，但没有躲。"
        hx "可以吗？"
    else:
        # 她没说出来，退缩了
        "她低下头，把手机翻过来扣在膝盖上。"
        hx "……算了。没什么。"
        player_name "你想说什么？"
        hx "……真的没什么。"
        "她把手机收进枕头底下，抱着膝盖，不再看你。"
        "你看着她。她没有再开口。"

        "房间里很安静。"
        "你继续收拾背包。拉链拉好，又打开，把充电线重新塞了一遍。"
        "过了一会儿，你听见她那边传来很轻的动静。"
        "她把手机从枕头底下拿了出来。"
        "但没有立刻解锁。只是握在手里，屏幕朝下。"
        "又过了几秒，她才按亮屏幕。"

    if hx_novel_delayed and huaixiaoshi_affection >= 60 and not hx_shared_novel_origin:
        "她低头看着屏幕，手指在边缘蹭了两下。"
        hx "……上次在阳台，我没说完。"
        hx "这本书的女主原型，是你。"
        "她停了一下，像是在等自己把话说完。"
        hx "……我想把小说发给你。"
        hx "不是片段。是全部。"
        player_name "为什么想发给我？"
        hx "因为你说过，你喜欢我的文字。"
        hx "你是第一个说‘喜欢’的人。"
        hx "我想……至少有一个读者，是知道我全部故事的人。"
        "你看着她。她的声音很轻，但没有躲。"
        hx "可以吗？"
        $ hx_shared_novel_origin = True
    # ————————————————————————————————————————————————
    # 正式分流：此时 hx_shared_novel_origin 可能为 True（阳台触发或补触发）
    # 也可能为 False（两次都拒绝）
    # ————————————————————————————————————————————————
    if hx_shared_novel_origin and huaixiaoshi_affection >= 60:
        # 结局 远方
        scene bg leave_taking_five_hx at bg_top
        "她把手机递向你的方向，屏幕停留在还没有定稿的新段落。"
        hx "我写不好真正的远方。"
        player_name "那我走到远方，拍下来给你看。"
        "她的脸颊泛起淡淡的红，把头微微低下。但手机依旧朝着你的方向递过来，没有收回。"
        hx "……你路上每到一个地方，就给我发一张照片。"
        hx "我看到了，就写一段。"
        "你接过手机，文档里是密密麻麻的文字。你粗略翻了翻，发现其中有一整章，标题是《她的相机》。"
        player_name "这一章……"
        hx "……别现在看。"
        "她伸手把手机拿回去，锁屏，塞进枕头底下。"
        hx "等你回来再看。"

        "你点了点头，继续收拾背包。"

        scene bg leave_taking_one_hx at bg_top
        "她坐在床上，抱着膝盖，手指攥着被角。"
        "过了一会儿，她忽然开口。声音很小。"
        hx "……小说里，女主等了那个人很多年。"
        hx "但那个人走的时候，她什么都没有说。"
        "你停下动作，回头看她。"
        hx "……我不想等那么久。"
        player_name "那你想怎么办？"
        "她张了张嘴，没有发出声音。最后把脸埋进膝盖里。"
        hx "……等你回来。我就告诉你。"
        "她的耳根红透了。"
        "你没有再追问。你伸出手，轻轻碰了一下她的发顶。"
        "她没有躲。"

        scene bg train_station at bg_top
        "第二天，她来车站送你。"
        "检票口前，她把速写本往你怀里一塞。"
        hx "……路上看。"
        "你低头翻开。最后一页写着一行字。"
        "“等你回来。”"
        "你抬头看她。她已经别过脸去，耳根红着。"
        hx "……快走吧。车要开了。"
        "你合上速写本，走向检票口。走了几步，你回头。"
        "她还站在原地。没有挥手，也没有走。只是看着你。"

        scene bg train_internal at bg_top
        "火车开动之后，你靠在窗边，把速写本重新翻开。"
        "你在那行“等你回来”下面补了一行小字。"
        "“已经在路上了。”"

        scene bg road_dusk at bg_top
        "后来的旅途里，你每到一个地方就拍一张照片发给她。"
        "她回你一段文字。有时只有一句，有时是一整段。"
        "你从不评价。她从不解释。"
        "第三个月，她问：“你什么时候回来。”"
        "你回：“还没想好。”"
        "她回：“好。”"

        scene bg hotel_north at bg_top
        "半年后，你在一座北方小镇的旅馆里，点开了《桃溪村的夏天》的最后一章。"
        "标题是《车站》。"
        "写的是一年后，你返校归来，她站在车站出口。"
        "她手里拿着手机，屏幕亮着。对话框里停着一条没发出去的消息。"
        "她等了一班又一班车。"
        "最后一段只有一句话——"
        "“远方从来不是终点。远方，是有人等着你归来。”"
        "你合上手机，看向窗外。"
        "雪还在下。"
        "你忽然很想回去。"
    else:
        # 无声（共享了小说，但好感不足60）
        scene bg leave_taking_five_hx at bg_top
        "她把手机递过来。屏幕上是一个小说平台的作品主页，目录很长。"
        "你往下翻，翻到最新一章。你看见了那个女主。你知道她是谁。你也知道，那个名字，和你一样。"
        "你没有点破。她也没有再解释。你把手机还给她。"
        player_name "写得很好。"
        hx "……谢谢。"
        "她把手机收回去，锁屏，放在枕头旁边。"

        scene bg leave_taking_one_hx at bg_top
        "台灯还亮着。她抱着膝盖坐在床上，没有躺下。你也没有躺下。"
        "两个人都很安静。"
        "你继续整理背包，把充电线、备用电池、一本路上要看的书一件件塞进去。"
        "她坐在床上，手指一下一下抠着被角的线头。"
        "你注意到她的手机屏幕还亮着，停在小说主页那一页。她没有再点开，但也没有按灭。"
        "过了一会儿，她忽然说了一句。"
        hx "……有些东西，我写不进去。"
        player_name "为什么？"
        hx "……写进去就不一样了。"
        "她的声音很轻，轻到你几乎以为她只是在自言自语。"

        scene bg desk_turn_off at bg_top
        "你没有再问。"
        "你把整理到一半的背包拉上拉链，靠在桌边。"
        "窗外很安静。初夏的夜风从阳台门缝里吹进来，把台灯的光晃了一下。"
        "她坐在床上，没有动。你坐在桌边，也没有动。"
        "那本书里到底藏了什么，她没有讲。你也没有翻。"
        "但你大概知道。"
        "有些话，写下来是故事。说出来，就是另一回事了。"
        "你看了她一眼。她低着头，指尖还在被角上。"
        "你想起她递手机给你的时候，手指在屏幕上停了一瞬。"
        "那一刻她大概想说什么。"
        "但最后，她只是把手机递了过来。"

        scene bg dorm_morning at bg_top
        "第二天早上，你出门的时候，她还在睡。"
        "你留了一张纸条在她桌上。上面写着：走了，等你写完。"
        "你没有署名。"

        scene bg train_station at bg_top
        "你到车站的时候，离发车还有二十分钟。"
        "检票口前排着队。你回头看了一眼大厅入口。"
        "没有人。"
        "你站了两秒，转身走进队伍。"
        "广播报了一次车次。你低头看了一眼手机。"
        "没有新消息。"

        scene bg train_internal at bg_top
        "火车开动之后，你收到她发来的一条消息。"
        hx "一路顺风。"
        "你回复：“好。”"
        "对面没有再回。"

        scene bg road_dusk at bg_top
        "旅途中，你偶尔会收到她发来的片段。"
        "有时是一段风景描写，有时只是一句零碎的独白，有时是几个字：“今天写不下去。”"
        "你把这些文字全部保存，标记日期。"
        "你回她：“慢慢写。”"
        "她回你一个句号。"
        "她从来没有问过你什么时候回来。"
        "你也没有主动说过。"

        scene bg hotel_north at bg_top
        "半年后，你在旅馆里收到她发来的一段文字。"
        "写的是一个女孩，站在车站出口，等一个再也不会回来的人。"
        "她等了一班又一班车。"
        "但那段文字没有标题，也没有结尾。"
        "你翻到小说的评论区。最高赞的一条写着："
        "“总觉得女主身边那个沉默的女孩，作者写得太真实了，像是真的存在过。”"
        "你盯着那条评论看了很久。"
        "你忽然想起她说的那句话——“有些东西，写不进去。”"
        "你现在大概明白了。"
        "那些写不进去的东西，不是不能写。"
        "是她写了一半，发现写下去就会变成真的。"
        "所以她停下来了。"

    jump common_epilogue

label friendship_ending:
    # 夏日Romantic Night.MP3
    play music "music/夏日Romantic Night.MP3" fadein 1.0
    scene bg train_internal at bg_top
    "火车缓缓驶出站台。你靠在窗边，把相机从包里取出来，放在膝上。"
    "出发前三天见过的那些人，一个个在脑子里过了一遍。"
    "小莱在图书馆给你的牛皮纸信封，还压在背包最底层。你抽出来，翻开第一页。上面写着汴京往南的第一座小城，旁边标注了当地一座废弃书院的年份。"
    "第二页，是桃溪村隔壁的镇子。她在页脚写了一行极小的字：陈婆婆年轻时在那里住过。"
    "你把信封收好。"
    "手机里，江枫发来的音频文件还在。你戴上耳机，点开那首《路上小心》。前奏响起的时候，你想起琴房里她没有唱完的最后一句。"
    "谢旻的私信夹在消息列表中间，只有一行字：“到地方了发照片。我姐想看。”"
    "你回复：“好。”"
    "凌晨的网站你还没有打开。你退出聊天界面，点进那个叫「不想忘」的主页。"
    "首页，是桃溪村那棵老槐树。页面一行小字：记录开始。"
    "向下翻阅：汴大的湖、食堂的餐桌、宿舍窗台。一张张，全都是你们共同经历过的画面。每一张照片下面，标注日期、地点。"
    "翻到页面最底端。那张军训之后，七个人一起拍下的合照。照片里面，你站在人群中间，抬着头看向镜头。备注文字：第一章。"
    "你退出浏览器。窗外的景物缓缓向后移动。"
    "你心里清楚，这个网站，会一直不断更新下去。"
    "你独自坐在窗边，把相机相册从头翻到尾。"
    "第一张：香樟树下的牵绕，攥紧行李箱，指节泛白。"
    "第二张：琴房射灯之下，独坐的黎陌尘。"
    "第三张：湖边写生，马尾高高束起的黎妤。"
    "第四张：怀小柿低头系鞋带，动作轻轻缓缓。"
    "第五张：凌晨网站上面，桃溪村的老槐树。"
    "第六张：窗边埋首书卷的小莱。"
    "第七张：舞台之上遥遥相望的江枫与谢旻。"
    "第八张：七个人聚在一起的那张合照。照片里面，你也身在其中。"

    "你在这张合照上停了很久。手指无意识地放大了画面。"
    "江枫在笑，谢旻在闹，黎妤拽着黎陌尘的袖子，黎陌尘嘴角有一个很浅的弧度。凌晨站在最外侧，往前挪了半步。怀小柿站在你旁边，抬着头。"
    "你看着照片里那个站在中间的自己。你记得那天你站在镜头前，不知道该看哪里。是怀小柿碰了碰你的胳膊，你才顺着她的视线抬起头。"
    "那是你第一次把自己也拍进了照片里。"
    "你把这张合照设置为相机的屏幕保护。"

    scene bg black at bg_top
    "合上相机，背靠座椅，闭上眼睛。"
    "你不知道前路会遇见怎样的人与故事。但这两年少年岁月里面遇见的所有人，你都牢牢记住。"
    "如同父亲八岁那年对你说过的那句话——"
    fq "你以后会遇到很多人。能记住一个，便是一个。"
    
    scene bg train_internal_evening at bg_top
    "不知道行驶了多久，你睁开双眼。夜幕已经完全落下，车窗外是一座灯火璀璨的陌生城市，站台人来人往。"
    "你把相机挎上肩膀，起身走下火车。"
    
    scene bg train_station_evening at bg_top
    "站台上人潮涌动。有人拥抱重逢，有人含泪告别，有人拿着手机轻声通话。"
    "你举起相机，取景框捕捉到一个女孩，一边打电话，一边笑着，眼泪顺着脸颊滑落。"
    "快门清脆的响声，被晚风带走。"
    "你低头预览照片，嘴角不自觉浮起浅浅笑意。抬起头，向着车站出口迈步。"
    "你的旅途，才刚刚正式开启。"
    "所有人各自走在自己的人生轨道。你们曾拥有一段珍贵的大学回忆，彼此成为过客，遥遥相望，祝福对方前路安好。"
    "没有亲密相伴，但那些共同经历，不会被抹去。"

    scene bg new_city at bg_top
    "你走出车站，站在陌生的街头。路灯亮着，晚风带着这座城市的气味扑面而来。"
    "你低头看了一眼相机屏幕。那张合照还在。照片里七个人，一个不缺。"
    "你笑了一下，把相机收进包里。"
    "然后迈开步子，走向人群深处。"

    scene bg black at bg_top
    "……………………………………"

    "一年后。"

    scene bg train_internal at bg_top
    "火车驶入汴京站之前，你给小莱发了一条消息。"
    player_name "到了。"
    "几分钟后，她回复。"
    xl "出站口右边。人有点多，你慢慢走。"

    scene bg train_station at bg_top
    "火车驶入汴京站的时候，是傍晚。"
    "你背着包，拖着行李箱，随着人流走出出站口。站台上有人拥抱重逢，有人含泪告别，有人举着手机大声通话。你穿过人群，走向出口。"
    "你本来以为，出站口外面会是陌生的空气，和一年前离开时一样。"
    "但你错了。"

    scene bg exit_gate at bg_top
    "出站口右侧的栏杆旁，站着一排人。"

    scene bg exit_gate_jf at bg_top
    "江枫最先看见你。她把手里的纸袋举起来，朝你挥了挥。纸袋上画着一只歪歪扭扭的纸鹤。"

    scene bg exit_gate_xm at bg_top
    "谢旻站在她旁边，双手插兜，看见你之后没有立刻走过来，只是朝你抬了抬下巴。"

    scene bg exit_gate_lc at bg_top
    "凌晨站在最外侧，手里没有拿书。他手里拿着一张打印出来的照片——是你离开那天，火车窗外的那片天空。那是他网站里的第一张照片。"

    scene bg exit_gate_xl at bg_top
    "小莱站在人群靠后的位置，手里只拿着一本薄薄的软面笔记本。看见你之后，她把本子合上，朝你轻轻点头。"
    "你走过去。"
    player_name "槐安那个地方，我路过了。"
    xl "……你去了？"
    player_name "去了。镇子很小，但书院还在。"
    "她把手里那本软面笔记本翻开。里面夹着一张对折的便签，她把它抽出来，递给你。"
    xl "那你帮我补一句。"
    "便签上写着一行字：槐安书院，始建年份待考。下面留了空白。"
    "你接过笔，在空白处写了一句：院墙已修，门匾尚存，当地老人说建于光绪年间。"
    "她把便签收回去，低头看了一眼，夹回笔记本里。没有多说什么，但你把笔记本还回去的时候，看见她的嘴角动了一下。"

    scene bg exit_gate_hx at bg_top
    "怀小柿缩在江枫身后，手指攥着背包带子。她没有说话，但她抬起头，看向了你。"
    
    scene bg exit_gate_ly at bg_top
    "黎妤站在栏杆另一边，手里举着速写本，翻到其中一页给你看。画面上是火车站的人潮，和一个背着相机、拖着行李箱走出站台的人。"
    
    scene bg exit_gate_lm at bg_top
    "黎陌尘站在她旁边，没有说话。但你的目光扫过去的时候，他的手指在身侧轻轻敲了一下——那是他弹琴前的起手动作。"
    
    scene bg exit_gate at bg_top
    "牵绕没有来。"
    "但你低头看了一眼手机。"
    "一分钟前，你收到了一条消息。发信人的头像还是那张香樟树下的旧照。"
    q "出站了没有。"
    "没有问号。也没有多余的话。"
    player_name "出了。"
    "你收起手机，抬头看着面前的这群人，忽然笑了。"
    "你把行李箱立在脚边，从背包里取出相机。"
    "你举起相机，对准面前这群人。镜头里，是他们。"
    "取景框里，江枫在挥手，谢旻别过脸去，凌晨把照片举高了一点，小莱站在人群后面安静地笑，怀小柿从江枫身后探出半个头，黎妤举着速写本，黎陌尘站在原地，嘴角有一个很浅的弧度。"
    "你按下快门。"
    "照片定格。"
    "你低头看了一眼预览。七个人，一个不缺。照片里没有你。"
    "你看了两秒，忽然笑了一下。"
    "你拍过那么多人，唯独很少把自己拍进去。但这一次你发现，你在不在照片里，好像已经不那么重要了。"
    "你知道自己在哪儿。你在他们中间。在镜头后面，也在他们中间。"
    "你收起相机，朝他们走过去。"

    scene bg exit_gate_jf at bg_top
    jf "你这一年拍了多少张照片啊？"
    player_name "数不清了，反正很多。"
    jf "那回去后全给我看看。"
    player_name "好。"
    
    scene bg exit_gate_xm at bg_top
    "谢旻从江枫背后探出来。"
    xm "那张合照还在吗？"
    player_name "在。"
    
    scene bg exit_gate_lc at bg_top
    "凌晨没有说话，只是把你离开那天拍的天空照片递给你，背面写了一行小字：记录继续。"
    "你接过照片，放进相机包的内袋。"
    
    scene bg exit_gate_ly at bg_top
    "黎妤把速写本塞回画包。"
    ly "什么时候开始下一段旅行？"
    player_name "还没想好。"
    ly "那正好，我墙绘的活儿还没接完，你等我一起。"

    scene bg exit_gate at bg_top
    "怀小柿走在人群最后面，安安静静。你回头看她的时候，她朝你轻轻点了点头。"
    "黎陌尘走在队伍侧边，手里没有乐器，但手指依然在身侧轻轻敲着。你听不见节奏，但你知道，那是一首还没写完的曲子。"
    "你走在他们中间，肩上挎着相机，行李箱轮子在地面上滚出细碎的声响。"
    
    scene bg office_fd at bg_top
    "你忽然想起，出发前辅导员问你的那句话——"
    fd "你回来的时候，还是想继续读文学系吗？"

    scene bg exit_gate at bg_top
    "你想了想，觉得答案没变。"
    "文学和摄影，都不冲突。你只想记住更多的人，拍下更多的瞬间。"
    "而眼前这群人，是你最早记住的那一批。"

    scene bg black at bg_top
    "——结局提示——"
    "你打出了【友情---同行一程】结局。"
    "——后记——"

    scene bg dorm_evening at bg_top
    "你休学回来，重新读大二。"
    "原来的室友已经升上大三，搬去了不同的宿舍楼。你被分到新的寝室，和三个陌生的学妹住在一起。"
    "但你并没有觉得孤单。"
    "因为你的手机里，一直很热闹。"

    # ————————————————————————————————————————感谢游玩————————————————————————————————————————
    scene bg black at bg_top
    "——————————————"
    "故事到这里，就真的结束了。"
    "你没有和谁走到一起，但你也没有和谁走散。"
    "有些关系，不需要成为恋人，也能一直留在身边。"
    "你曾用镜头记录过别人，也曾在别人的画里、曲子里、故事里被记录。"
    "你不再只是那个站在镜头后面的人，你也在照片里。"
    "愿你也能像主角一样——"
    "在去往未知远方的路上，勇敢地举起属于自己的“相机”，记录下每一个认真活着的瞬间，也别忘了，把你自己，也装进风景里。"
    "——完——"
    
    return

label common_epilogue:
    # ————————————————————————————————————————后记————————————————————————————————————————
    if max_value >= 60:
        if max_char == "牵绕":
            if qianrao_admitted_identity and qianrao_affection >= 70:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【牵绕---顺路】结局。"
                "——后记——"

                scene bg southern_town at bg_top
                "一年后的春天。"
                "你们在一个南方小城的汽车站下车。"

                scene bg southern_town_q at bg_top
                "他走在前面，背包带子松松垮垮挂在一边肩上。你拖着行李箱，跟在他后面半步。"
                "站外有人卖冰水。他顺手买了两瓶，一瓶拧开自己喝，一瓶塞给你。"
                q "拿着。"
                "你接过来。瓶身是凉的，跟他第一次递给你的那瓶一模一样。"
                "他别过脸去，没有看你。但你知道，他是故意的。"

                scene bg southern_town at bg_top
                "你没有问他下一站去哪。他也没有问你。"
                "不重要。"
                "反正你们顺路。"

                "你们在南方走走停停，一路拍一路画。"

                scene bg village at bg_top
                "槐花开的时候，你们正好回到桃溪村。"
                "他走在前面，脚步比平时慢。你举着相机，走在他后面半步。"
                "走到村东那棵老槐树底下，他停下来。"
                "树冠浓绿，白花簌簌落下来。树下那把石竹椅还在，被谁擦过了，没有灰尘。"

                scene bg village_q at bg_top
                "他站在树下，没有捡落在肩头的花瓣，也没有说话。"
                "你举起相机，对准他和那棵树。"
                "他没有躲镜头。"
                "快门按下。"

                scene bg village_photograph_q at bg_top
                "照片里，他站在老槐树下，阳光从叶缝漏下来。他的手没有插在裤袋里。"
                "他就那样站着，看着镜头，看着你。"

                "你翻到照片背面。"
                "那里原本刻着一行极小的字。是你离开那天，他在硬币上刻的那三个字——“下一站”。"
                "你把照片翻过来，在那一行字下面，用笔补了一句。"
                "——“树还在。我也在。”"
            elif qianrao_admitted_identity:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【牵绕---绕行】结局。"
                "——后记——"

                "一年后。"
                scene bg another_city_morning at bg_top
                "你在另一个城市的街头，举起相机。"
                "取景框里，一个穿黑色外套的男生正从对面走过来。"
                "你下意识按下快门。"
                "然后低头看预览。"
                "照片里的人是陌生人。"
                "你把相机放下，转身继续往前走。"
                "手机震了一下。是朋友圈的点赞提示。"
                "ID 是那个熟悉的名字。"
                "你发了一张异乡的天空，他第一个点了赞。"
                "没有评论。没有消息。但你注意到，他的头像还是那张香樟树下的旧照。"
                "你把手机收好，继续走。"

                scene bg another_city_evening at bg_top
                "某天晚上，你打开凌晨的网站。"
                "首页还是那棵桃溪村的老槐树。往下翻，是一张张熟悉的照片。汴大的湖、食堂的餐桌、宿舍窗台。"
                "你翻到页面最底端。那一张七人合照下面，多了一行新的访问记录。"
                "访问者头像很小，但你认得出来——那是香樟树下的旧照。"
                "他来过。"
                "访问时间显示：三天前。"
                "他看了很久。从第一张看到最后一张。"
                "但他什么也没有留下。没有评论，没有标记，没有点赞。"
                "他只是来过。然后又走了。"
                "你忽然明白，他一直都在绕着走。"
                "只是他绕得越来越近了。"
                "近到他站到了门口，还是没敲门。"
                "但你已经看见了。"
            else:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【牵绕---未出口的话】结局。"
                "——后记——"

                "一年后。"
                scene bg jiuzhen_evening at bg_top
                "你在一座旧镇落脚。"
                "小镇不大，青石板路两边开着杂货铺。你走到街尾的时候，看见一棵老槐树。"
                "槐树不高，但枝干很老，像在哪里见过。你举起相机，对着它按了一张。"
                "快门卡了一下，声音很闷。你低头看了一眼预览，照片有点糊，但树影还在。"
                "你站在那里看了很久。"
                "身后的杂货铺老板走出来关灯，看了你一眼。"
                lb "这棵树啊，有些年头了。每年槐花开的时候，都有人来这儿拍照。"
                "你点了点头。"
                player_name "拍得不好，但想留着。"
                "老板笑了一声，把门关上了。"
                "街灯亮起来，把老槐树的影子投在青石板上。"
                "你低头翻了一遍相册，最后停在那张槐树下的旧照上。他站在花雨里，嘴角带着笑。"
                "那张照片你一直没删，也一直没有发给他。"
                "你合上相机，放回包里。"

                scene bg jiuzhen_morning at bg_top
                "第二天早上，你退房，坐上下一班车。"
                "车窗外，那棵老槐树慢慢往后退。"
                "你低头看了一眼手机。"
                "昨天晚上那张模糊的槐树照片下面，多了一个赞。"
                "是他。"
                "你盯着那个赞看了很久。"
                "他没有评论。但他点了。"
                "你把手机锁屏，塞进口袋。"
                "车窗外的田野一片一片往后退。"
                "你忽然想起他说的那句话——“牵挂着，绕着走。”"
                "他一直都在绕着走。"
                "但有些东西，他绕不过去。"
                "比如那棵老槐树。比如你。"

        elif max_char == "黎陌尘":
            if limichen_important_choice == "encourage" and limichen_affection >= 75:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎陌尘---合奏】结局。"
                "——后记——"

                "一年后。"
                scene bg coastal_city at bg_top
                "你在海边的一座城市，戴上耳机。"
                "U盘里的《路上》已经存了十几段。每一段都很短，最短的只有两个音符。"
                "你数过，一共十八段。"
                "十八次他想你的时候，他就弹一段。"
                "而你每到一个地方，就拍一组照片发给他。海边、车站、旧书店、傍晚的巷子。你没有问他有没有看，但他每一组都回了。有时候是一段新写的旋律，有时候只有两个字。"
                "“收到。”"

                scene bg exit_gate_one_lm at bg_top
                "你回汴京的那天，他站在车站出口等你。手里拿着一沓新的谱纸，封面写着《路上·第二部》。"
                lm "……回来了？"
                player_name "嗯。"
                "他把谱纸递给你。"
                lm "这首是给你的。"
                player_name "叫什么名字？"
                "他想了想。"
                lm "……还没想好。"

                scene bg exit_gate_two_lm at bg_top
                "但他嘴角有一个很浅的弧度。"
                "你打开谱纸，第一页的第一行写着两个大字。"
                "《归期》。"
                "你翻到第二页。上面除了旋律，还有一行极小的批注。字迹工整，是他的笔迹。"
                "“第一段，从你离开的那天开始。”"
                "你继续往后翻。每一页的页脚，都贴着一张很小的照片。是你旅途中发给他的那些。他一张一张洗出来，剪成方寸大小，贴在谱纸的角落里。"
                "你翻到最后一页。最后一页的旋律停在半空中，没有写完。页脚贴着一张空白的相纸，什么都没有。"
                "旁边写了一行小字。"
                "“等你回来，把这张补上。”"
            elif limichen_important_choice == "encourage":
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎陌尘---十八段】结局。"
                "——后记——"

                "一年后。"
                scene bg piano_room_morning at bg_top
                "你回到汴京大学，路过琴房。门虚掩着，里面传出钢琴声。"
                "你没有推门。站在门口听了一会儿。"
                "是那首曲子。很慢，很轻。"
                "弹到一半，琴声停了。"
                "你听到里面的人轻轻叹了口气。"
                "然后重新开始弹。"
                "还是那首曲子。弹到同一个地方，又停了。"
                "第三次。他从头开始，指尖落在琴键上的声音很轻。弹到第二段的时候，他的左手停住了，右手还悬在半空。"
                "没有落下去。"
                "沉默了很久。然后琴盖合上。"
                "你听见他站起来，琴凳往后挪了一下。脚步声朝门口走过来。"
                "你的手放在门上。"
                "他停在门后。"
                "你们之间隔着一道虚掩的门，谁也没有动。"
                "过了几秒，脚步声退了回去。"
                "琴盖重新打开。他没有再弹。"

                scene bg teaching_building_corridor at bg_top
                "你放下准备敲门的手，转身离开。"
                "有些人，你走近过。"
                "但最终，还是隔着一道门。"
                "那首曲子，第二段始终没有出现。"
            elif limichen_affection >= 70:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎陌尘---推门】结局。"
                "——后记——"

                "一年后。"
                scene bg teaching_building_morning at bg_top
                "你回到汴京大学，重新读大二。"
                "原来的室友已经升上大三，搬去了不同的宿舍楼。你被分到新的寝室，和三个陌生的学妹住在一起。"
                "但你有一件事没有变。"
                "你每天路过教学楼，还是会往二楼看一眼。"
                "琴房的灯有时候亮着，有时候不亮。"

                scene bg piano_room_evening at bg_top
                "有一天晚上，灯亮着。"
                "你走上去，站在门口。"
                "门虚掩着。里面有人在弹琴。"
                "是那首曲子。第二段。"
                "他弹完了。"
                "弹完之后，琴房安静了几秒。"
                "你听见他站起来，琴凳往后挪了一下。脚步声朝门口走过来。"
                "你的手放在门上。"
                "他停在门后。"
                "这一次，他没有退回去。"

                scene bg piano_one_lm at bg_top
                "他推开门。"
                "看到你，他没有意外。"
                lm "……回来了？"
                player_name "嗯。"

                scene bg piano_two_lm at bg_top
                "他没有再说话。他把琴凳挪回原位，坐回去，把手放回琴键上。"
                "他弹了一小段新的旋律。"
                "你没有听过。"
                "弹完之后，他转头看你。"
                lm "这首还没名字。"
                player_name "什么时候有名字？"
                lm "……等你听完。"
            else:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎陌尘---门外】结局。"
                "——后记——"

                "一年后。"
                scene bg teaching_building_morning at bg_top
                "你回到汴京大学，重新读大二。"
                "原来的室友已经升上大三，搬去了不同的宿舍楼。你被分到新的寝室，和三个陌生的学妹住在一起。"
                "你偶尔会路过教学楼。"
                "二楼的琴房有时候亮着灯，有时候不亮。"
                "你没有上去过。"

                scene bg piano_room_evening at bg_top
                "有一回，你路过的时候，琴房的门开着。"
                "里面没有人。"
                "钢琴盖合着。谱架上放着一沓谱纸。"
                "你站在门口，没有进去。"
                "你想起那首曲子。想起第二段那三秒的空白。"
                "你不知道他后来有没有弹完。"
                "你也没有问。"
                "你转身走了。"
                "后来你再路过那里，琴房的门关着。"
                "灯也不亮了。"

        elif max_char == "黎妤":
            if ly_important_flag == "hold_idea" and liyu_affection >= 70:
                scene bg black at bg_top
                # 守灯
                "——结局提示——"
                "你打出了【黎妤---守灯】结局。"
                "——后记——"

                "一年后。"
                scene bg road_dusk at bg_top
                "你们的旅行绘本出版了。"
                "封面是那张七人合照。扉页写着一行小字。"
                "——“献给所有在路上的朋友。”"
                "翻开内页，左边是你的摄影，右边是她的插画。每一页记录一座城市、一面墙、一个路人。"
                "你拍下的人，她画成线条。她画下的墙，你拍成光影。"
                "样书寄到的那天，你和黎妤坐在宿舍里，一页一页翻。"
                "翻到中间某一页，你忽然停下来。"
                "那一页，左边是你拍的火车站长椅，空无一人；右边是她画的同一张长椅，长椅上坐着一个举着相机的人。"
                "你愣了一下。那张照片里，长椅确实是空的。你记得很清楚。"

                scene bg leave_taking_one_ly at bg_top
                "黎妤坐在旁边，头也不抬地翻着下一页。"
                ly "我画的人一直不太行。但是那一个，画得还行。"
                "你忽然想起她塞给你的那张速写，第一张画对的画，现在她画了第二张。"
                "你没有说话。你翻到最后一页。"
                "最后一页，是那张军训结束那晚的拼桌长桌。"
                "这一次，桌上坐满了人。七个人，一个不缺。"
                "而桌子的最角落，有一个小小的、举着相机的侧影。"
                "那是她画的你。"
                "而这一次，画的旁边贴着一张照片。是你拍的同一张桌子。照片里，那七个人在笑，桌上摆着烤串，炭火还没灭。"
                "两张画放在一起。左边是她的笔，右边是你的镜头。"
                "同一个场景，同一个人间。"

                scene bg art_exhibition_ly at bg_top
                "签售会那天，黎妤站在展台后面，被一群小朋友围着签名。你站在角落里，举起相机。"
                "她抬头看到了你，对着镜头比了个手势。"
                "快门按下。"

                scene bg art_exhibition_photograph_ly at bg_top
                "照片里，她身后是一整面墙，墙上画满了你们走过的城市。"
                "每一幅画下面都标着日期。"
                "从第一站，到最后一站。"
                "但你知道，那不是最后一站。"
                "因为回家的路上，她又开始计划下一段旅程了。"
            elif ly_important_flag == "compromise" and liyu_affection >= 70:
                scene bg black at bg_top
                # 周旋
                "——结局提示——"
                "你打出了【黎妤---画墙】结局。"
                "——后记——"

                "一年后。"
                scene bg road_dusk at bg_top
                "你们的旅行绘本出版了。"
                "封面是那张七人合照。扉页写着一行小字。"
                "——'献给所有在路上的朋友。'"
                "翻开内页，左边是你的摄影，右边是她的插画。"
                "你拍下的人，她画成线条。她画下的墙，你拍成光影。"
                "有一页，左边是你拍的废弃工厂外墙，右边是她画的那面墙。"
                "墙上多了一幅壁画。画的是一个女孩站在灯下，手里举着相机。"
                "你在那面墙前面站过。当时墙上什么都没有。"
                "你翻到最后一页。"
                "最后一页是那张拼桌长桌。七个人，一个不缺。"
                "桌子上多了一盏灯。灯放在正中间，亮着。"
                "那是《灯》。"
                "她在画里把那盏灯留下来了。"

                scene bg art_exhibition_ly at bg_top
                "签售会那天，你站在角落里，举起相机。"
                "她没有朝你比手势。"

                scene bg art_exhibition_photograph_one_ly at bg_top
                "她翻开速写本，翻到某一页，朝你举了举。"
                "那一页上画的是车站。"
                "你和她的背影，并排坐在候车椅上。"
                "旁边写着一行小字。"
                "——“这一版，是我改过之后的样子。”"
                "你想起出发那天，她在火车上说过的话。"
                "她说改稿和私稿分开，这趟车上先画自己的。"
                "你把相机放下，朝她笑了一下。"
                "她合上速写本，转过身去给下一个读者签名。"
                "但你知道，那一页她留了很久。"
            elif ly_important_flag == "hold_idea":
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎妤---灯下无人】结局。"
                "——后记——"

                "一年后。"
                scene bg bookstore at bg_top
                "你在南方一座小城的旧书店里翻一本旧杂志。"
                "杂志中间有一页插画专栏，介绍了几位青年插画师。"
                "你翻到其中一页。作者名字是黎妤。"

                scene bg photo_ly at bg_top
                "照片上她扎着马尾，手里举着一本速写本，笑得自然。"
                "旁边配了一段访谈。记者问她，最近在画什么。"
                "她回答。"
                "——“在画一盏灯。灯很亮，但旁边没有人。”"
                "记者又问，为什么不画人。"
                "——“因为那个人还没有走到灯下。”"
                
                scene bg bookstore at bg_top
                "你合上杂志，放回书架。"
                "书店老板问你要不要买，你摇了摇头。"

                scene bg southern_town at bg_top
                "你走出书店的时候，外面的天色很好。你举起相机，朝街对面按了一张。"
                "取景框里没有人。只有一盏路灯。"
                "你低头看了一眼照片。你没有删。"
                "你把相机挂回肩上，继续往前走。"
            elif ly_important_flag == "compromise":
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【黎妤---半面墙】结局。"
                "——后记——"

                "一年后。"
                scene bg bookstore at bg_top
                "你在南方一座小城的旧书店里翻一本旧杂志。"
                "杂志中间有一页插画专栏，介绍了几位青年插画师。"
                "你翻到其中一页。作者名字是黎妤。"

                scene bg photo_ly at bg_top
                "照片上她扎着马尾，手里举着一本速写本，笑得自然。"
                "旁边配了一段访谈。记者问她，最近在画什么。"
                "她回答。"
                "——“在画一盏灯。灯还在，但光调暗了一点。”"
                "记者又问，为什么不调亮。"
                "——“因为调亮的话，就会照到不该照的地方。”"

                scene bg bookstore at bg_top
                "你合上杂志，放回书架。"
                "书店老板问你要不要买，你摇了摇头。"

                scene bg southern_town at bg_top
                "你走出书店的时候，外面的天色很好。你举起相机，朝街对面按了一张。"
                "取景框里没有人。只有一盏路灯，灯罩上蒙了一层灰。"
                "你低头看了一眼照片。你没有删。"
                "你把相机挂回肩上，继续往前走。"

        elif max_char == "怀小柿":
            if hx_shared_novel_origin and huaixiaoshi_affection >= 60:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【怀小柿---远方】结局。"
                "——后记——"

                "一年后。"
                scene bg road_dusk at bg_top
                "小说《你拍过的那些地方》上市了。"
                "你收到作者寄来的样书。扉页上有一行手写。"
                "“致那个替我走到远方的人。”"
                "你翻开目录。第一章《桃溪村的夏天》，第二章《车站》，第三章《她拍过的那些人》，第四章《她的相机》。"
                "你翻到第四章，标题叫《她的相机》。"
                "你记得这个标题。出发前夜，她在宿舍里把手机递给你的时候，目录里就有这一章。她当时伸手把手机拿了回去，说：“别现在看。等你回来再看。”"
                "现在你回来了。你翻到那一页。"
                "这一章写的是一个人举着相机走在路上的故事。她去了很多地方，拍了很多陌生人。她拍下早班车站里打瞌睡的上班族，拍下巷口抱着猫晒太阳的老人，拍下雨天撑着伞在路边等车的学生。"
                "她拍了很多很多人。但她很少把自己拍进去。"
                "写到最后一节的时候，笔锋忽然转了一下。"
                "“有一天，她遇到一个人。那个人说，你拍过那么多人，为什么从来不拍自己。她想了想，说，因为看不见自己。那个人说，那我帮你拍一张吧。然后，那个人把相机拿过去，反手按下了快门。”"
                "你翻到下一页。这一页上只有一张图。是出版社配的黑白插画。画的是一个人举着相机，镜头朝外。窗外站着另一个人，手里也举着一台相机，镜头朝着她。"
                "两个人互相拍着对方。"
                "而这一章的最后一句话，只有几个字。"
                "“她说，我终于在别人的镜头里看见自己了。”"
                "你合上书。"
                "手机弹出一条消息。"
                hx "……看完了吗？"
                player_name "看完了。"
                hx "……觉得怎么样？"
                player_name "比初稿好。"
                hx "……你以前也是这么说的。"
                player_name "因为是真的。"
                "对面沉默了几秒。"
                "然后发来一个句号。"
                "你笑了。"
                "有些人，你不必说什么。她也能读懂。"
                "你翻到最后一页。空白页右下角，有一行铅笔小字，很淡：“你回来的时候，故事就写完了。”"
            else:
                scene bg black at bg_top
                "——结局提示——"
                "你打出了【怀小柿---无声】结局。"
                "——后记——"

                "一年后。"
                scene bg bookstore at bg_top
                "你在书店看到一本小说。书名是《桃溪村的夏天》。"
                "你翻到作者简介页。照片上是一个头发很长的女生，编着一根细辫子，坐在窗边。"
                "你看了很久。然后你把书放回书架，没有买。"

                scene bg southern_town at bg_top
                "走出书店时，手机弹出消息。"
                hx "……你看到我的书了吗？"
                "你想了想，回复。"
                player_name "看到了。"
                hx "……"
                hx "……那就好。"
                "你把手机收好。"

                scene bg new_city at bg_top
                "可是当天晚上，你还是在网上买了那本书。等书送到的时候，你翻到最后一章。那一章的标题叫《车站》。"
                "写的是一个女孩，站在一个南方小城的车站出口。天快黑了，站台上没什么人。她手里拿着手机，屏幕亮着，对话框里停着一条没发出去的消息。"
                "她没有等到那个人。但她也没有走。她就站在那里，等了一班又一班车进站、出站、进站、出站。"
                "章节的最后一句话是——"
                "“她忽然想起，曾经有一个人跟她说过，远方是有人等着你归来。她那时候不懂。现在她懂了。只是她等的那个人，已经去了很远的地方。”"
                "你翻到下一页。这一页空白。再下一页，是版权页。没有你们之间的结局。"
                "她写完了所有人的故事，也写了以你为原型的女主。只是她没有写你们之间的结局。"
                "你合上书，把它放在书架上。"
                "有些话，她写在了书里。有些话，她永远都不会说出口。而你终于明白了，那句话是什么意思。"
                hx "至少有一个读者，是知道我全部故事的人。"
                "那个读者，她选的就是你。只是她没有把最后一章发给你。"   

    # ————————————————————————————————————————感谢游玩————————————————————————————————————————
    scene bg black at bg_top
    "……………………………………"
    "故事到这里，就真的结束了。"
    "九个少年少女，一年的大学时光，一段关于镜头、梦想与相遇的旅程。"
    "你陪他们走过了无数个黄昏与深夜，见证了他们每一次按下快门时的犹豫与坚定。"
    "还记得那句话吗？"
    "“你以后会遇到很多人。能记住一个是一个。”"
    "你曾用镜头记录过别人，也曾在别人的画里、曲子里、故事里被记录。"
    "你不再只是那个站在镜头后面的人，你也在照片里。"
    "愿你也能像主角一样——"
    "在去往未知远方的路上，勇敢地举起属于自己的“相机”，记录下每一个认真活着的瞬间，也别忘了，把你自己，也装进风景里。"
    "——完——"
    
    return